const fs = require('fs');

const p = 'C:\\crochet_app\\index.html';
let html = fs.readFileSync(p, 'utf8');

// Replace langCss with high-visibility, ultra-clear styling
const oldCss = `  .lang-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px !important;
    border-radius: 9999px !important;
    font-size: 0.8rem !important;
    font-weight: 700 !important;
    cursor: pointer;
    background: var(--bg-card);
    border: 1px solid var(--border-color);
    color: var(--text-main);
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    transition: all 0.2s ease;
  }`;

const newCss = `  .lang-btn {
    display: inline-flex !important;
    align-items: center !important;
    gap: 6px !important;
    padding: 6px 14px !important;
    border-radius: 9999px !important;
    font-size: 0.82rem !important;
    font-weight: 800 !important;
    cursor: pointer !important;
    background: rgba(255, 255, 255, 0.25) !important;
    border: 1.5px solid rgba(255, 255, 255, 0.55) !important;
    color: #ffffff !important;
    box-shadow: 0 3px 12px rgba(0, 0, 0, 0.22) !important;
    transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
  }
  .lang-btn:hover {
    background: rgba(255, 255, 255, 0.38) !important;
    border-color: #ffffff !important;
    transform: translateY(-1px) scale(1.03);
  }
  .lang-btn i.fa-globe {
    font-size: 1.05rem !important;
    color: #fde047 !important; /* Vibrant golden globe */
    filter: drop-shadow(0 0 4px rgba(250, 204, 21, 0.6));
  }`;

if (html.includes(oldCss)) {
  html = html.replace(oldCss, newCss);
  console.log('Replaced old langCss with new high-visibility CSS');
} else {
  console.log('Old langCss exact match not found, looking for .lang-btn');
}

fs.writeFileSync(p, html, 'utf8');

