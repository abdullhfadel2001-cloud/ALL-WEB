const https = require('https');

https.get('https://abdullhfadel2001-cloud.github.io/ALL-WEB/crochet/index.html', (res) => {
  console.log('GitHub Pages Status Code:', res.statusCode);
  let data = '';
  res.on('data', chunk => data += chunk);
  res.on('end', () => {
    console.log('Page size fetched:', data.length);
    console.log('Contains langDropdownContainer:', data.includes('id="langDropdownContainer"'));
    console.log('Contains I18N_DICT:', data.includes('const I18N_DICT ='));
  });
}).on('error', (err) => {
  console.error('Request error:', err.message);
});

