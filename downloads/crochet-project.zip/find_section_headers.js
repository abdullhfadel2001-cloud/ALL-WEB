const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');

const matches = html.match(/\/\/\s*═+[\s\S]*?\n\/\/\s*[^\n]+/g);
console.log('Section headers found:');
matches.forEach((m, i) => {
  if (i < 20) console.log(m.replace(/\n/g, ' '));
});
