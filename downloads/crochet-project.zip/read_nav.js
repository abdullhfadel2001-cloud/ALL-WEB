const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');
const lines = html.split('\n');

console.log('--- Lines 2120 to 2190 ---');
console.log(lines.slice(2120, 2190).join('\n'));

console.log('--- Search mobile-bottom-nav ---');
lines.forEach((l, i) => {
  if (l.includes('mobile-bottom-nav') || l.includes('tab-btn')) {
    if (i > 5000) console.log(`Line ${i + 1}: ${l.trim()}`);
  }
});

