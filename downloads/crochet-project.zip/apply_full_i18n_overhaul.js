// Full Comprehensive Internationalization Engine (7 Languages: AR, EN, DE, JA, TR, RU, ES)
const fs = require('fs');

const p = 'C:\\crochet_app\\index.html';
let html = fs.readFileSync(p, 'utf8');

// 1. ADD GERMAN TO THE HEADER DROPDOWN
const germanOpt = `          <div class="lang-opt" data-lang="de" onclick="setAppLanguage('de')">
            <span class="lang-flag">🇩🇪</span>
            <div class="lang-text">
              <span class="lang-name">Deutsch</span>
              <span class="lang-country">Deutschland / DACH</span>
            </div>
          </div>\n`;

if (!html.includes('data-lang="de"')) {
  html = html.replace('data-lang="en"', 'data-lang="en"');
  html = html.replace(
    `<div class="lang-opt" data-lang="en" onclick="setAppLanguage('en')">`,
    `${germanOpt}          <div class="lang-opt" data-lang="en" onclick="setAppLanguage('en')">`
  );
  console.log('Injected German option into header dropdown');
}

// 2. PREPARE THE MASTER TRANSLATION DICTIONARIES
const masterI18nScript = `
// ═══════════════════════════════════════════════════════
//  MASTER 7-LANGUAGE DICTIONARY & COMPONENT TRANSLATIONS
// ═══════════════════════════════════════════════════════
const I18N_DICT = {
  ar: {
    langCode: 'ar-IQ', dir: 'rtl', label: 'العربية',
    brandTitle: 'خيوط وغرز', brandSubtitle: 'الرفيق الذكي للكروشيه',
    screenWl: 'الشاشة', wlBanner: 'خاصية عدم إطفاء الشاشة قيد التشغيل (لن تنطفئ شاشتك أثناء قراءة الباترون)',
    nav: {
      search: 'سؤال ذكي', patterns: 'الباترونات المصورة', patternsShort: 'الباترونات',
      counter: 'العداد السحري', counterShort: 'العداد', calc: 'حاسبة الخيوط', calcShort: 'الحاسبة',
      glossary: 'المصطلحات المصورة', glossaryShort: 'المصطلحات', studio: 'استوديو الباترونات', studioShort: 'الاستوديو',
      notes: 'ملاحظاتي الذكية', notesShort: 'ملاحظاتي'
    },
    chat: {
      title: 'SAMAR — خبيرتكِ الذكية للكروشيه', status: 'متصلة ومستعدة للإجابة فوراً 🟢',
      welcome: 'أهلاً بكِ يا غالية! أنا **SAMAR**، خبيرتكِ ومساعدتكِ الشخصية في فنون الكروشيه والحياكة وشغل الصوف والأبر 🧶✨. اسأليني عن أي غرزة، باترونة، أو مشكلة تواجهكِ في شغلكِ وسأجيبكِ في نفس اللحظة!',
      placeholder: 'اكتبي سؤالكِ لـ SAMAR هنا...', clear: 'مسح المحادثة', thinking: 'SAMAR تفكر وتكتب لكِ الآن... 🧶',
      chips: { ring: '🪄 سر الدائرة السحرية', curling: '⚠️ حل التواء القطعة', compare: '📐 الحشو vs العمود', blanket: '🍼 حساب خيط البطانية' }
    },
    patterns: {
      title: 'مكتبة الباترونات المصورة خطوة بخطوة', subtitle: 'مجموعة مختارة ومجانية من أرقى تصاميم الكروشيه مع خطوات العمل والرسوم التوضيحية',
      searchPh: 'ابحثي في الباترونات (مثال: شال، لعبة، سلة، حقيبة)...',
      levels: { all: 'الكل (المستويات)', beg: '🟢 مبتدئ', int: '🟡 متوسط', adv: '🟣 محترف' },
      cats: { all: 'الكل', ami: 'دمى وألعاب', shawls: 'شالات وملابس', home: 'ديكور ومنزل', bags: 'حقائب وإكسسوار' },
      balls: 'شلة', hook: 'سنارة', time: 'الوقت', steps: 'خطوة', progress: 'الإنجاز',
      modalBack: 'رجوع للباترونات', secMaterials: 'الأدوات والمقاسات', secSymbols: 'جدول الرموز والاختصارات المعتمدة في هذا الباترون',
      secTips: 'نصائح احترافية للتشطيب والتنظيف', secSteps: 'خطوات العمل المفصلة غرزة بغرزة', stepPrefix: 'الخطوة',
      symColSym: 'الرمز', symColName: 'اسم الغرزة', symColEn: 'المصطلح الإنجليزي'
    },
    counter: {
      title: 'العداد الصوتي واليدوي للأسطر والغرز', desc: 'عدّاد ذكي مصمم لراحتكِ أثناء إمساك السنارة، مع تحكم صوتي بدون لمس ومؤقت جلسة وتنبيهات صحية',
      voiceTitle: 'التحكم الصوتي بدون لمس (Hands-Free)', voicePrompt: 'قولي بصوتك: <b>"زيد"</b> للزيادة، <b>"نقص"</b> للنقصان، أو <b>"تصفير"</b> لإعادة الضبط!',
      voiceReady: 'الميكروفون جاهز للعمل', btnVoiceStart: 'تشغيل التحكم الصوتي 🎙️', btnVoiceStop: 'إيقاف الاستماع 🛑',
      mchTag: 'عداد الحياكة السحري المطور', mchLabel: 'السطر / الدور الحالي (يحفظ تلقائياً في جهازك 100%)',
      btnReset: 'تصفير العداد', stopwatchTitle: 'مؤقت جلسة العمل وحساب الساعات', btnStartSession: 'بدء الجلسة', btnPauseSession: 'إيقاف مؤقت'
    },
    calc: {
      title: 'منصة الحاسبات الذكية والتسعير بالدينار العراقي (د.ع)', subtitle: 'أدوات رياضية وهندسية دقيقة لتقدير الخيوط، عينة القياس، وحساب الأرباح بدقة.',
      currency: 'العملة المعتمدة: د.ع (دينار عراقي)',
      tabs: {
        est: '1. تقدير كمية الخيوط ومقاس السنارة', gauge: '2. حاسبة عينة القياس (Gauge 10×10 سم)',
        rem: '3. حاسبة بقايا الخيوط (غرام إلى متر)', pricing: '4. حاسبة التسعير والربح بالدينار العراقي'
      },
      calcBtn: 'احسبي الآن ✨', cardBtn: 'توليد بطاقة العناية والسعر 🏷️'
    },
    studio: {
      title: 'استوديو ومولّد الباترونات الاحترافي', subtitle: 'مخططات هندسية متكاملة، شبكة بكسلات ورموز تفاعلية، وتحويل الصور إلى باترونات كروشيه بالخيوط الحقيقية.',
      btnPdf: 'طباعة / تصدير PDF', btnNotes: 'حفظ في ملاحظاتي',
      tabStarry: 'باترون بلوزة "ليلة النجوم" (Starry Night)', tabCustom: 'مولّد الباترون من أي صورة خاصة بكِ',
      specsHeader: '🧶 مقاس البلوزة (L) والمواصفات الفنية', specsCost: 'التكلفة المقدرة: ~28,000 د.ع خيوط قطن/أكريليك',
      chest: 'محيط الصدر: 104 - 112 سم', width: 'عرض البلوزة: 52 - 56 سم', length: 'الطول الكلي: 60 سم (120 صف)',
      sleeve: 'طول الكم: 48 سم (96 صف)', hook: 'السنارة الموصى بها: 3.5 - 4.0 مم',
      blueprints: 'المخططات الهندسية لقطع البلوزة الثلاث',
      partFront: 'مخطط الأمام', partBack: 'مخطط الخلف', partSleeves: 'مخطط الكم (يُعمل مرتين)',
      exportGrid: 'تصدير وحفظ شبكة الغرز 📥'
    },
    glossary: {
      title: 'قاموس غرز وسنارات الكروشيه المصور', masterGuideBtn: 'دليل مقاسات السنارات والخيوط الشامل 📐',
      searchPh: 'ابحثي عن أي غرزة أو رمز (مثال: sc, عمود, سلسلة, T)...', emptySearch: 'لا توجد مصطلحات مطابقة للبحث',
      tagDiagram: '📐 حركة السنارة (رسم)', tagTexture: '🧶 نسيج الخيط الحقيقي'
    },
    notes: {
      title: 'ملاحظاتي ومشاريعي الذكية', btnAdd: 'ملاحظة جديدة', searchPh: 'ابحثي في الملاحظات...',
      emptyTitle: 'لا توجد ملاحظات مسجلة بعد', emptyDesc: 'اضغطي على "+ ملاحظة جديدة" لتدوين خيوطك ومشاريعك وقوائم مهامك'
    }
  },

  en: {
    langCode: 'en-US', dir: 'ltr', label: 'English',
    brandTitle: 'Yarn & Stitches', brandSubtitle: 'Smart Crochet Companion',
    screenWl: 'Screen', wlBanner: 'Screen keep-awake is active (screen will not sleep while crocheting)',
    nav: {
      search: 'AI Expert', patterns: 'Illustrated Patterns', patternsShort: 'Patterns',
      counter: 'Smart Counter', counterShort: 'Counter', calc: 'Yarn Calculators', calcShort: 'Calculators',
      glossary: 'Stitch Glossary', glossaryShort: 'Glossary', studio: 'Pattern Studio', studioShort: 'Studio',
      notes: 'Smart Notes', notesShort: 'Notes'
    },
    chat: {
      title: 'SAMAR — Smart Crochet Expert', status: 'Online & ready to answer instantly 🟢',
      welcome: 'Welcome! I am **SAMAR**, your personal expert crochet & knitting companion 🧶✨. Ask me about any stitch, pattern, gauge calculation, or yarn tension issue, and I will assist you right away!',
      placeholder: 'Ask SAMAR anything about crochet...', clear: 'Clear Chat', thinking: 'SAMAR is thinking and typing... 🧶',
      chips: { ring: '🪄 Magic Ring Secret', curling: '⚠️ Fixing Yarn Curling', compare: '📐 Single vs Double Crochet', blanket: '🍼 Blanket Yarn Calc' }
    },
    patterns: {
      title: 'Step-by-Step Illustrated Patterns Library', subtitle: 'Curated free crochet patterns with clear step-by-step instructions and vector diagrams',
      searchPh: 'Search patterns (e.g. shawl, kitten, basket, bag)...',
      levels: { all: 'All Levels', beg: '🟢 Beginner', int: '🟡 Intermediate', adv: '🟣 Advanced' },
      cats: { all: 'All', ami: 'Amigurumi', shawls: 'Shawls & Wearables', home: 'Home & Decor', bags: 'Bags & Accessories' },
      balls: 'balls', hook: 'Hook', time: 'Time', steps: 'steps', progress: 'Progress',
      modalBack: 'Back to Patterns', secMaterials: 'Tools & Materials', secSymbols: 'Pattern Symbols & Abbreviations Key',
      secTips: 'Finishing & Blocking Professional Tips', secSteps: 'Step-by-Step Stitch Instructions', stepPrefix: 'Step',
      symColSym: 'Symbol', symColName: 'Stitch Name', symColEn: 'Standard US/UK Term'
    },
    counter: {
      title: 'Hands-Free Voice & Touch Counter', desc: 'Craft hands-free while holding your hook with voice control, session timer, and wrist stretch alerts',
      voiceTitle: 'Hands-Free Voice Control', voicePrompt: 'Say: <b>"Next"</b> or <b>"Plus"</b> to increase, <b>"Back"</b> or <b>"Minus"</b> to decrease, <b>"Reset"</b> to zero!',
      voiceReady: 'Microphone is active and ready', btnVoiceStart: 'Start Voice Control 🎙️', btnVoiceStop: 'Stop Listening 🛑',
      mchTag: 'Smart Advanced Crochet Counter', mchLabel: 'Current Row / Round (auto-saved 100% locally)',
      btnReset: 'Reset Counter', stopwatchTitle: 'Work Session Timer & Hour Tracker', btnStartSession: 'Start Session', btnPauseSession: 'Pause'
    },
    calc: {
      title: 'Smart Calculators & Accurate Pricing Suite', subtitle: 'Accurate mathematical tools for estimating yarn, swatch gauge, and profit margins.',
      currency: 'Currency: IQD / Universal Units',
      tabs: {
        est: '1. Yarn Quantity & Hook Estimator', gauge: '2. Gauge Swatch Calculator (10×10 cm)',
        rem: '3. Remaining Yarn by Weight (g to m)', pricing: '4. Project Pricing & Profit Calculator'
      },
      calcBtn: 'Calculate Now ✨', cardBtn: 'Generate Care & Price Tag 🏷️'
    },
    studio: {
      title: 'Bespoke Pattern Studio & Grid Generator', subtitle: 'Complete vector blueprints, interactive pixel grids, and photo-to-crochet converter with real yarns.',
      btnPdf: 'Print / Export PDF', btnNotes: 'Save to My Notes',
      tabStarry: 'Starry Night Bespoke Sweater Pattern', tabCustom: 'Convert Any Photo to Crochet Grid',
      specsHeader: '🧶 Sweater Size (L) & Technical Specs', specsCost: 'Estimated Cost: ~28,000 IQD Cotton/Acrylic Yarn',
      chest: 'Chest Circumference: 104 - 112 cm', width: 'Sweater Width: 52 - 56 cm', length: 'Total Length: 60 cm (120 rows)',
      sleeve: 'Sleeve Length: 48 cm (96 rows)', hook: 'Recommended Hook: 3.5 - 4.0 mm',
      blueprints: 'Technical Schematics for All 3 Pieces',
      partFront: 'Front Panel Chart', partBack: 'Back Panel Chart', partSleeves: 'Sleeve Chart (Make 2)',
      exportGrid: 'Export Pattern Grid 📥'
    },
    glossary: {
      title: 'Illustrated Crochet Stitches & Hooks Glossary', masterGuideBtn: 'Master Hook & Yarn Size Guide 📐',
      searchPh: 'Search stitches or symbols (e.g. sc, dc, ch, slip stitch)...', emptySearch: 'No matching stitches found',
      tagDiagram: '📐 Stitch Motion Diagram (Vector)', tagTexture: '🧶 Real Yarn Texture Swatch'
    },
    notes: {
      title: 'My Smart Crochet Notes & Projects', btnAdd: 'New Note', searchPh: 'Search in notes...',
      emptyTitle: 'No notes logged yet', emptyDesc: 'Tap "+ New Note" to record your yarn stash, current WIPs, and checklists'
    }
  },

  de: {
    langCode: 'de-DE', dir: 'ltr', label: 'Deutsch',
    brandTitle: 'Garn & Maschen', brandSubtitle: 'Smarter Häkel-Assistent',
    screenWl: 'Bildschirm', wlBanner: 'Bildschirm bleibt eingeschaltet (kein Ruhezustand beim Häkeln)',
    nav: {
      search: 'KI-Berater', patterns: 'Häkelanleitungen', patternsShort: 'Anleitungen',
      counter: 'Smarter Zähler', counterShort: 'Zähler', calc: 'Garnrechner', calcShort: 'Rechner',
      glossary: 'Maschen-Glossar', glossaryShort: 'Glossar', studio: 'Muster-Studio', studioShort: 'Studio',
      notes: 'Meine Notizen', notesShort: 'Notizen'
    },
    chat: {
      title: 'SAMAR — Deine smarte Häkel-Expertin', status: 'Online & sofort hilfsbereit 🟢',
      welcome: 'Herzlich willkommen! Ich bin **SAMAR**, deine persönliche Expertin für Häkeln, Stricken und Garne 🧶✨. Frage mich nach Maschen, Anleitungen, Maschenproben oder Spannungs-Problemen!',
      placeholder: 'Frage SAMAR alles ums Häkeln...', clear: 'Chat löschen', thinking: 'SAMAR denkt nach und tippt... 🧶',
      chips: { ring: '🪄 Geheimnis Fadenring', curling: '⚠️ Einrollen verhindern', compare: '📐 Feste Masche vs Stäbchen', blanket: '🍼 Decken-Garn berechnen' }
    },
    patterns: {
      title: 'Schritt-für-Schritt Illustrierte Anleitungen', subtitle: 'Kuratierte kostenlose Häkelanleitungen mit präzisen Rundenanweisungen und Vektordiagrammen',
      searchPh: 'Anleitungen durchsuchen (z. B. Tuch, Kätzchen, Korb, Tasche)...',
      levels: { all: 'Alle Level', beg: '🟢 Anfänger', int: '🟡 Mittel', adv: '🟣 Fortgeschritten' },
      cats: { all: 'Alle', ami: 'Amigurumi', shawls: 'Tücher & Kleidung', home: 'Wohnen & Deko', bags: 'Taschen & Zubehör' },
      balls: 'Knäuel', hook: 'Häkelnadel', time: 'Dauer', steps: 'Schritte', progress: 'Fortschritt',
      modalBack: 'Zurück zu Anleitungen', secMaterials: 'Werkzeug & Materialien', secSymbols: 'Verwendete Maschensymbole & Abkürzungen',
      secTips: 'Tipps zum Vernähen und Spannen', secSteps: 'Detaillierte Maschen-für-Maschen Anleitung', stepPrefix: 'Schritt',
      symColSym: 'Symbol', symColName: 'Maschenart', symColEn: 'Internationale Bezeichnung'
    },
    counter: {
      title: 'Freihändiger Sprach- & Touch-Reihenzähler', desc: 'Häkle freihändig mit Sprachsteuerung, Session-Timer und gesunden Handgelenk-Erinnerungen',
      voiceTitle: 'Freihändige Sprachsteuerung', voicePrompt: 'Sage: <b>"Weiter"</b> zum Vorzählen, <b>"Zurück"</b> zum Abziehen, oder <b>"Zurücksetzen"</b>!',
      voiceReady: 'Mikrofon ist aufnahmebereit', btnVoiceStart: 'Sprachzählung starten 🎙️', btnVoiceStop: 'Zuhören beenden 🛑',
      mchTag: 'Erweiterter Häkelzähler', mchLabel: 'Aktuelle Reihe / Runde (wird zu 100% lokal gespeichert)',
      btnReset: 'Zähler auf Null', stopwatchTitle: 'Häkel-Session-Timer & Stundenerfassung', btnStartSession: 'Starten', btnPauseSession: 'Pause'
    },
    calc: {
      title: 'Smarte Garnrechner & Exakte Preiskalkulation', subtitle: 'Präzise mathematische Werkzeuge für Garnverbrauch, Maschenprobe und Gewinnspannen.',
      currency: 'Währung: IQD / Universelle Einheiten',
      tabs: {
        est: '1. Garnbedarf & Nadelstärken-Schätzer', gauge: '2. Maschenproben-Rechner (10×10 cm)',
        rem: '3. Restgarn-Rechner (Gramm zu Meter)', pricing: '4. Preis- & Gewinnkalkulation'
      },
      calcBtn: 'Jetzt berechnen ✨', cardBtn: 'Pflege- & Preisschild erstellen 🏷️'
    },
    studio: {
      title: 'Professionelles Muster-Studio & Zählmuster', subtitle: 'Vollständige technische Baupläne, interaktives Pixelgitter und Foto-in-Häkelmuster-Generator.',
      btnPdf: 'PDF drucken / exportieren', btnNotes: 'In Notizen speichern',
      tabStarry: 'Pullover "Sternennacht" (Starry Night)', tabCustom: 'Eigenes Foto in Häkelraster umwandeln',
      specsHeader: '🧶 Pullover-Größe (L) & Technische Daten', specsCost: 'Geschätzte Kosten: ~28.000 IQD Baumwoll-/Acrylgarn',
      chest: 'Brustumfang: 104 - 112 cm', width: 'Pullover-Breite: 52 - 56 cm', length: 'Gesamtlänge: 60 cm (120 Reihen)',
      sleeve: 'Ärmellänge: 48 cm (96 Reihen)', hook: 'Empfohlene Nadel: 3.5 - 4.0 mm',
      blueprints: 'Schnittmuster für alle 3 Teile',
      partFront: 'Vorderteil-Schema', partBack: 'Rückenteil-Schema', partSleeves: 'Ärmel-Schema (2x arbeiten)',
      exportGrid: 'Zählraster exportieren 📥'
    },
    glossary: {
      title: 'Illustriertes Häkelmaschen- & Nadelglossar', masterGuideBtn: 'Große Nadel- & Garntabelle 📐',
      searchPh: 'Maschen oder Symbole suchen (z. B. feste Masche, Stäbchen, LM)...', emptySearch: 'Keine passenden Maschen gefunden',
      tagDiagram: '📐 Maschendiagramm (Vektor)', tagTexture: '🧶 Echtes Maschenbild'
    },
    notes: {
      title: 'Meine smarten Häkelnotizen & Projekte', btnAdd: 'Neue Notiz', searchPh: 'Notizen durchsuchen...',
      emptyTitle: 'Noch keine Notizen vorhanden', emptyDesc: 'Klicke auf "+ Neue Notiz", um Garnvorräte, aktuelle Projekte und Checklisten festzuhalten'
    }
  },

  ja: {
    langCode: 'ja-JP', dir: 'ltr', label: '日本語',
    brandTitle: '糸と編み目', brandSubtitle: 'スマート・かぎ針編みアシスタント',
    screenWl: '画面常時', wlBanner: '画面常時点灯が有効です（編み作業中も画面がスリープしません）',
    nav: {
      search: 'AI相談', patterns: '編み図・パターン', patternsShort: '編み図',
      counter: '編み目カウンター', counterShort: 'カウンター', calc: '糸量計算機', calcShort: '計算機',
      glossary: '編み目記号・用語', glossaryShort: '用語集', studio: 'パターンスタジオ', studioShort: 'スタジオ',
      notes: 'マイノート', notesShort: 'ノート'
    },
    chat: {
      title: 'SAMAR — かぎ針編み専属AIエキスパート', status: 'オンライン・いつでも質問にお答えします 🟢',
      welcome: 'ようこそ！私は **SAMAR**、あなたのかぎ針編み＆あみぐるみ専属AIパートナーです 🧶✨。編み目記号、糸の選び方、編み図の悩みなど何でも気軽にお尋ねください！',
      placeholder: 'SAMARにかぎ針編みの質問をする...', clear: 'チャット消去', thinking: 'SAMARが考えながら入力中... 🧶',
      chips: { ring: '🪄 わの作り目のコツ', curling: '⚠️ 編み地の丸まり解消', compare: '📐 細編み vs 長編み', blanket: '🍼 ブランケット糸量計算' }
    },
    patterns: {
      title: 'ステップバイステップ図解パターン集', subtitle: '丁寧な手順と鮮明な図解が付いた、厳選かぎ針編みパターン',
      searchPh: 'パターンを検索 (例: ショール、あみぐるみ、かご、バッグ)...',
      levels: { all: 'すべてのレベル', beg: '🟢 初級', int: '🟡 中級', adv: '🟣 上級' },
      cats: { all: 'すべて', ami: 'あみぐるみ', shawls: 'ショール・ウェア', home: 'インテリア・雑貨', bags: 'バッグ・小物' },
      balls: '玉', hook: 'かぎ針', time: '所要時間', steps: 'ステップ', progress: '進捗',
      modalBack: '一覧に戻る', secMaterials: '使用針と材料', secSymbols: '使用記号と略語一覧',
      secTips: '仕上げとお手入れのコツ', secSteps: 'ステップ別・編み順詳細', stepPrefix: 'ステップ',
      symColSym: '記号', symColName: '編み目名称', symColEn: '英語表記'
    },
    counter: {
      title: '音声＆タッチ式 編み目カウンター', desc: '針を持ったまま手ぶらでカウント。音声認識・タイマー・健康ストレッチ機能付き',
      voiceTitle: '手ぶら音声操作カウンター', voicePrompt: '「<b>次</b>」でプラス、「<b>戻る</b>」でマイナス、「<b>リセット</b>」で初期化！',
      voiceReady: 'マイク準備完了', btnVoiceStart: '音声認識を開始 🎙️', btnVoiceStop: '音声認識を停止 🛑',
      mchTag: '多機能スマートカウンター', mchLabel: '現在の段 / 目数（端末に100%自動保存）',
      btnReset: 'カウンター初期化', stopwatchTitle: '作業セッションタイマー＆時間記録', btnStartSession: 'セッション開始', btnPauseSession: '一時停止'
    },
    calc: {
      title: 'スマート糸量計算＆価格設定プラットフォーム', subtitle: '糸の必要量、ゲージ換算、販売適正価格を割り出す計算ツール。',
      currency: '通貨単位: IQD / 各国通貨対応',
      tabs: {
        est: '1. 糸量見積もり＆適正針サイズ', gauge: '2. ゲージ計算機 (10×10 cm)',
        rem: '3. 残り糸の長さ計算 (gからmへ)', pricing: '4. 販売価格＆利益計算'
      },
      calcBtn: '計算する ✨', cardBtn: '品質表示＆値札タグを生成 🏷️'
    },
    studio: {
      title: '本格パターンスタジオ＆方眼チャート生成', subtitle: '設計図、インタラクティブ目数チャート、お好みの画像をかぎ針編みチャートに変換。',
      btnPdf: 'PDF印刷 / 出力', btnNotes: 'マイノートに保存',
      tabStarry: '「星月夜」セーター本格編み図', tabCustom: '画像をかぎ針編みチャートに変換',
      specsHeader: '🧶 セーターサイズ (L) ＆ 仕様', specsCost: '概算材料費: 約28,000 IQD（コットン/アクリル糸）',
      chest: '胸囲: 104 - 112 cm', width: '身幅: 52 - 56 cm', length: '着丈: 60 cm (120段)',
      sleeve: '袖丈: 48 cm (96段)', hook: '推奨かぎ針: 3.5 - 4.0 mm',
      blueprints: 'パーツ別 構造製図（全3面）',
      partFront: '前身頃チャート', partBack: '後身頃チャート', partSleeves: '袖チャート（2枚作成）',
      exportGrid: 'チャート画像を保存 📥'
    },
    glossary: {
      title: 'かぎ針編み 記号と針の図解辞典', masterGuideBtn: 'かぎ針と糸の規格対応表 📐',
      searchPh: '編み目記号や用語を検索 (例: 細編み, 長編み, 鎖編み, sc)...', emptySearch: '該当する編み目が見つかりません',
      tagDiagram: '📐 編み目記号図（ベクター）', tagTexture: '🧶 実際の編み地テクスチャ'
    },
    notes: {
      title: 'マイ編み物ノート＆作品記録', btnAdd: '新規ノート', searchPh: 'ノートを検索...',
      emptyTitle: 'ノートはまだありません', emptyDesc: '「+ 新規ノート」を押して、糸の在庫や制作記録を書き留めましょう'
    }
  },

  tr: {
    langCode: 'tr-TR', dir: 'ltr', label: 'Türkçe',
    brandTitle: 'İplik ve İlmekler', brandSubtitle: 'Akıllı Tığ İşi Asistanı',
    screenWl: 'Ekran', wlBanner: 'Ekran açık kalma modu aktif (örgü sırasında ekranınız kapanmaz)',
    nav: {
      search: 'Akıllı Soru', patterns: 'Resimli Örnekler', patternsShort: 'Örnekler',
      counter: 'Akıllı Sayaç', counterShort: 'Sayaç', calc: 'İplik Hesaplama', calcShort: 'Hesaplayıcı',
      glossary: 'Terimler & Kancalar', glossaryShort: 'Terimler', studio: 'Şablon Stüdyosu', studioShort: 'Stüdyo',
      notes: 'Notlarım', notesShort: 'Notlar'
    },
    chat: {
      title: 'SAMAR — Akıllı Tığ İşi Uzmanınız', status: 'Çevrimiçi & anında cevaplamaya hazır 🟢',
      welcome: 'Hoş geldiniz! Ben **SAMAR**, tığ işi ve örgü sanatındaki kişisel uzman asistanınızım 🧶✨. İlmekler, motifler, ip hesabı veya takıldığınız yerler hakkında her şeyi sorabilirsiniz!',
      placeholder: 'SAMAR\\'a tığ işi hakkında bir soru sorun...', clear: 'Sohbeti Temizle', thinking: 'SAMAR düşünüyor ve yazıyor... 🧶',
      chips: { ring: '🪄 Sihirli Halka Sırrı', curling: '⚠️ Kıvrılmayı Düzelt', compare: '📐 Sık İğne vs Trabzan', blanket: '🍼 Battaniye İp Hesabı' }
    },
    patterns: {
      title: 'Adım Adım Resimli Örnek Kütüphanesi', subtitle: 'Detaylı çalışma adımları ve vektör çizimleriyle özenle seçilmiş ücretsiz şablonlar',
      searchPh: 'Şablonlarda ara (ör: şal, kedi, sepet, çanta)...',
      levels: { all: 'Tüm Seviyeler', beg: '🟢 Başlangıç', int: '🟡 Orta', adv: '🟣 İleri Düzey' },
      cats: { all: 'Tümü', ami: 'Amigurumi', shawls: 'Şallar & Giysiler', home: 'Ev & Dekor', bags: 'Çantalar & Aksesuar' },
      balls: 'yumak', hook: 'Tığ', time: 'Süre', steps: 'adım', progress: 'İlerleme',
      modalBack: 'Şablonlara Dön', secMaterials: 'Malzemeler & Ölçüler', secSymbols: 'Şablonda Kullanılan Semboller ve Kısaltmalar',
      secTips: 'Bitiş & Temizleme İpuçları', secSteps: 'Adım Adım İlmek Talimatları', stepPrefix: 'Adım',
      symColSym: 'Sembol', symColName: 'İlmek Adı', symColEn: 'İngilizce Karşılığı'
    },
    counter: {
      title: 'Sesli ve Dokunmatik İlmek Sayacı', desc: 'Tığ elinizdeyken sesli komutla temassız sayın, seans sürenizi takip edin ve mola verin',
      voiceTitle: 'Temassız Sesli Kontrol', voicePrompt: 'Sesle söyleyin: <b>"İleri"</b> (+1), <b>"Geri"</b> (-1) veya <b>"Sıfırla"</b>!',
      voiceReady: 'Mikrofon hazır', btnVoiceStart: 'Sesli Komutu Başlat 🎙️', btnVoiceStop: 'Dinlemeyi Durdur 🛑',
      mchTag: 'Gelişmiş Sihirli Sayaç', mchLabel: 'Geçerli Sıra / Tur (cihazınıza %100 otomatik kaydedilir)',
      btnReset: 'Sayacı Sıfırla', stopwatchTitle: 'Örgü Seans Zamanlayıcısı', btnStartSession: 'Başlat', btnPauseSession: 'Duraklat'
    },
    calc: {
      title: 'Akıllı İplik & Doğru Fiyatlandırma Hesaplayıcıları', subtitle: 'İplik tüketimi, örgü numunesi ve kâr marjlarını hesaplayan matematiksel araçlar.',
      currency: 'Para Birimi: IQD / Evrensel',
      tabs: {
        est: '1. İplik İhtiyacı & Tığ Numarası', gauge: '2. Örgü Numunesi Hesabı (10×10 cm)',
        rem: '3. Kalan İp Hesabı (Gramdan Metreye)', pricing: '4. Fiyatlandırma & Kâr Hesaplayıcı'
      },
      calcBtn: 'Şimdi Hesapla ✨', cardBtn: 'Bakım ve Fiyat Kartı Oluştur 🏷️'
    },
    studio: {
      title: 'Profesyonel Şablon Stüdyosu & Izgara Oluşturucu', subtitle: 'Teknik şemalar, interaktif piksel ızgarası ve resimleri tığ işine dönüştürme aracı.',
      btnPdf: 'Yazdır / PDF İndir', btnNotes: 'Notlarıma Kaydet',
      tabStarry: 'Yıldızlı Gece Özel Kazak Şablonu', tabCustom: 'Kendi Resminizi Tığ İşi Izgarasına Dönüştürün',
      specsHeader: '🧶 Kazak Ölçüsü (L) & Teknik Özellikler', specsCost: 'Tahmini Maliyet: ~28.000 IQD Pamuk/Akrilik İplik',
      chest: 'Göğüs Çevresi: 104 - 112 cm', width: 'Gövde Genişliği: 52 - 56 cm', length: 'Toplam Boy: 60 cm (120 sıra)',
      sleeve: 'Kol Boyu: 48 cm (96 sıra)', hook: 'Önerilen Tığ: 3.5 - 4.0 mm',
      blueprints: 'Kazak Parçalarının Teknik Çizimleri',
      partFront: 'Ön Panel Şeması', partBack: 'Arka Panel Şeması', partSleeves: 'Kol Şeması (2 adet örülür)',
      exportGrid: 'Izgarayı Dışa Aktar 📥'
    },
    glossary: {
      title: 'Resimli Tığ İşi İlmek & Kanca Sözlüğü', masterGuideBtn: 'Kapsamlı Tığ ve İplik Ölçü Rehberi 📐',
      searchPh: 'İlmek veya sembol ara (ör: sık iğne, trabzan, zincir, sc)...', emptySearch: 'Eşleşen terim bulunamadı',
      tagDiagram: '📐 Tığ Hareketi Çizimi (Vektör)', tagTexture: '🧶 Gerçek İplik Dokusu'
    },
    notes: {
      title: 'Akıllı Notlarım & Projelerim', btnAdd: 'Yeni Not', searchPh: 'Notlarda ara...',
      emptyTitle: 'Henüz kayıtlı not yok', emptyDesc: 'İplerinizi, devam eden işlerinizi kaydetmek için "+ Yeni Not" butonuna basın'
    }
  },

  ru: {
    langCode: 'ru-RU', dir: 'ltr', label: 'Русский',
    brandTitle: 'Нити и Петли', brandSubtitle: 'Умный помощник по вязанию',
    screenWl: 'Экран', wlBanner: 'Режим постоянной подсветки активен (экран не погаснет во время вязания)',
    nav: {
      search: 'Умный вопрос', patterns: 'Схемы вязания', patternsShort: 'Схемы',
      counter: 'Умный счетчик', counterShort: 'Счетчик', calc: 'Калькулятор пряжи', calcShort: 'Калькулятор',
      glossary: 'Словарь петель', glossaryShort: 'Словарь', studio: 'Студия схем', studioShort: 'Студия',
      notes: 'Мои заметки', notesShort: 'Заметки'
    },
    chat: {
      title: 'SAMAR — Ваш умный эксперт по вязанию', status: 'В сети & готова ответить мгновенно 🟢',
      welcome: 'Добро пожаловать! Я **SAMAR**, ваш личный эксперт по вязанию крючком и пряже 🧶✨. Спросите меня о любой петле, схеме, расчете нити или натяжении!',
      placeholder: 'Напишите ваш вопрос для SAMAR...', clear: 'Очистить чат', thinking: 'SAMAR думает и печатает... 🧶',
      chips: { ring: '🪄 Секрет волшебного кольца', curling: '⚠️ Устранить закручивание', compare: '📐 Столбик б/н vs с накидом', blanket: '🍼 Расчет пряжи на плед' }
    },
    patterns: {
      title: 'Библиотека пошаговых иллюстрированных схем', subtitle: 'Тщательно отобранные бесплатные схемы с пошаговыми инструкциями и векторными схемами',
      searchPh: 'Поиск по схемам (напр: шаль, котенок, корзина, сумка)...',
      levels: { all: 'Все уровни', beg: '🟢 Начинающий', int: '🟡 Средний', adv: '🟣 Продвинутый' },
      cats: { all: 'Все', ami: 'Амигуруми', shawls: 'Шали и одежда', home: 'Дом и декор', bags: 'Сумки и аксессуары' },
      balls: 'мотка', hook: 'Крючок', time: 'Время', steps: 'шагов', progress: 'Прогресс',
      modalBack: 'Назад к схемам', secMaterials: 'Материалы и размеры', secSymbols: 'Таблица условных обозначений схемы',
      secTips: 'Советы по отделке и влажно-тепловой обработке', secSteps: 'Пошаговые инструкции петля за петлей', stepPrefix: 'Шаг',
      symColSym: 'Символ', symColName: 'Название петли', symColEn: 'Международное обозначение'
    },
    counter: {
      title: 'Голосовой и ручной счетчик рядов', desc: 'Вяжите без помощи рук благодаря голосовому управлению, таймеру и разминке для запястий',
      voiceTitle: 'Бесконтактное голосовое управление', voicePrompt: 'Скажите: <b>"Дальше"</b> (+1), <b>"Назад"</b> (-1) или <b>"Сброс"</b>!',
      voiceReady: 'Микрофон готов к работе', btnVoiceStart: 'Включить голосовой счет 🎙️', btnVoiceStop: 'Остановить микрофон 🛑',
      mchTag: 'Продвинутый счетчик вязания', mchLabel: 'Текущий ряд / круговой ряд (сохраняется автоматически)',
      btnReset: 'Сбросить счетчик', stopwatchTitle: 'Таймер сессии вязания', btnStartSession: 'Старт', btnPauseSession: 'Пауза'
    },
    calc: {
      title: 'Умные калькуляторы пряжи и расчета цены', subtitle: 'Точные инструменты для расчета расхода пряжи, плотности вязания и себестоимости.',
      currency: 'Валюта: IQD / Универсальный расчет',
      tabs: {
        est: '1. Расчет расхода пряжи и крючка', gauge: '2. Калькулятор плотности (образец 10×10 см)',
        rem: '3. Расчет остатка нити (из граммов в метры)', pricing: '4. Расчет цены и прибыли изделия'
      },
      calcBtn: 'Рассчитать ✨', cardBtn: 'Создать бирку с ценой и уходом 🏷️'
    },
    studio: {
      title: 'Студия схем и генератор пиксельной сетки', subtitle: 'Технические выкройки, интерактивная пиксельная сетка и преобразование картинок в схемы.',
      btnPdf: 'Печать / Экспорт PDF', btnNotes: 'Сохранить в заметки',
      tabStarry: 'Схема свитера "Звездная ночь"', tabCustom: 'Преобразовать свое фото в схему вязания',
      specsHeader: '🧶 Размер свитера (L) и технические характеристики', specsCost: 'Примерная стоимость: ~28.000 IQD (хлопок/акрил)',
      chest: 'Обхват груди: 104 - 112 см', width: 'Ширина изделия: 52 - 56 см', length: 'Общая длина: 60 см (120 рядов)',
      sleeve: 'Длина рукава: 48 см (96 рядов)', hook: 'Рекомендуемый крючок: 3.5 - 4.0 мм',
      blueprints: 'Технические выкройки всех 3 деталей',
      partFront: 'Схема переда', partBack: 'Схема спинки', partSleeves: 'Схема рукава (вязать 2 шт.)',
      exportGrid: 'Экспортировать схему 📥'
    },
    glossary: {
      title: 'Иллюстрированный словарь петель и крючков', masterGuideBtn: 'Таблица соответствия крючков и пряжи 📐',
      searchPh: 'Поиск петли или символа (напр: сбн, ссн, возд. петля)...', emptySearch: 'Ничего не найдено',
      tagDiagram: '📐 Схема движения крючка (Вектор)', tagTexture: '🧶 Реальная текстура полотна'
    },
    notes: {
      title: 'Мои умные заметки и проекты', btnAdd: 'Новая заметка', searchPh: 'Поиск по заметкам...',
      emptyTitle: 'Заметок пока нет', emptyDesc: 'Нажмите "+ Новая заметка", чтобы записать остатки пряжи и текущие проекты'
    }
  },

  es: {
    langCode: 'es-ES', dir: 'ltr', label: 'Español',
    brandTitle: 'Hilos y Puntos', brandSubtitle: 'Compañero Inteligente de Crochet',
    screenWl: 'Pantalla', wlBanner: 'Pantalla siempre encendida activa (la pantalla no se apagará mientras tejes)',
    nav: {
      search: 'Consulta IA', patterns: 'Patrones Ilustrados', patternsShort: 'Patrones',
      counter: 'Contador Mágico', counterShort: 'Contador', calc: 'Calculadoras de Hilo', calcShort: 'Calculadora',
      glossary: 'Glosario de Puntos', glossaryShort: 'Glosario', studio: 'Estudio de Patrones', studioShort: 'Estudio',
      notes: 'Mis Notas', notesShort: 'Notas'
    },
    chat: {
      title: 'SAMAR — Tu Experta Inteligente en Crochet', status: 'En línea y lista para ayudarte al instante 🟢',
      welcome: '¡Bienvenida! Soy **SAMAR**, tu experta y compañera personal en el arte del crochet y tejido 🧶✨. ¡Pregúntame sobre cualquier punto, patrón, cálculo de hilo o duda y te responderé al instante!',
      placeholder: 'Escribe tu pregunta para SAMAR aquí...', clear: 'Borrar Chat', thinking: 'SAMAR está pensando y escribiendo... 🧶',
      chips: { ring: '🪄 Secreto del Anillo Mágico', curling: '⚠️ Solución al Enrollamiento', compare: '📐 Punto Bajo vs Punto Alto', blanket: '🍼 Cálculo de Manta' }
    },
    patterns: {
      title: 'Biblioteca de Patrones Ilustrados Paso a Paso', subtitle: 'Colección seleccionada de patrones gratuitos con instrucciones paso a paso y diagramas vectoriales',
      searchPh: 'Buscar patrones (ej: chal, gatito, cesta, bolso)...',
      levels: { all: 'Todos los Niveles', beg: '🟢 Principiante', int: '🟡 Intermedio', adv: '🟣 Avanzado' },
      cats: { all: 'Todos', ami: 'Amigurumi', shawls: 'Chales y Ropa', home: 'Hogar y Decoración', bags: 'Bolsos y Accesorios' },
      balls: 'ovillos', hook: 'Ganchillo', time: 'Tiempo', steps: 'pasos', progress: 'Progreso',
      modalBack: 'Volver a Patrones', secMaterials: 'Herramientas y Materiales', secSymbols: 'Tabla de Símbolos y Abreviaturas del Patrón',
      secTips: 'Consejos de Acabado y Bloqueo', secSteps: 'Instrucciones Detalladas Punto por Punto', stepPrefix: 'Paso',
      symColSym: 'Símbolo', symColName: 'Nombre del Punto', symColEn: 'Término Internacional'
    },
    counter: {
      title: 'Contador de Filas por Voz y Táctil', desc: 'Teje con manos libres usando control por voz, cronómetro de sesión y alertas de estiramiento',
      voiceTitle: 'Control por Voz Manos Libres', voicePrompt: 'Di con tu voz: <b>"Siguiente"</b> (+1), <b>"Atrás"</b> (-1) o <b>"Reiniciar"</b>!',
      voiceReady: 'Micrófono listo para escuchar', btnVoiceStart: 'Activar Control por Voz 🎙️', btnVoiceStop: 'Detener Voz 🛑',
      mchTag: 'Contador Inteligente de Tejido', mchLabel: 'Fila / Vuelta Actual (guardado automático en tu dispositivo)',
      btnReset: 'Reiniciar Contador', stopwatchTitle: 'Cronómetro de Sesión de Tejido', btnStartSession: 'Iniciar', btnPauseSession: 'Pausar'
    },
    calc: {
      title: 'Plataforma Inteligente de Cálculo y Precios', subtitle: 'Herramientas matemáticas precisas para calcular consumo de hilo, muestra de tensión y márgenes de ganancia.',
      currency: 'Moneda: IQD / Unidades Universales',
      tabs: {
        est: '1. Estimador de Hilo y Ganchillo', gauge: '2. Calculadora de Muestra (Gauge 10×10 cm)',
        rem: '3. Hilo Restante por Peso (g a m)', pricing: '4. Calculadora de Precios y Ganancia'
      },
      calcBtn: 'Calcular Ahora ✨', cardBtn: 'Generar Tarjeta de Cuidado y Precio 🏷️'
    },
    studio: {
      title: 'Estudio Profesional de Patrones y Cuadrícula', subtitle: 'Planos técnicos, cuadrícula interactiva de píxeles y conversor de fotos a patrones de crochet.',
      btnPdf: 'Imprimir / Exportar PDF', btnNotes: 'Guardar en Mis Notas',
      tabStarry: 'Patrón Suéter "Noche Estrellada" (Starry Night)', tabCustom: 'Convertir Cualquier Foto a Cuadrícula',
      specsHeader: '🧶 Talla del Suéter (L) y Ficha Técnica', specsCost: 'Coste Estimado: ~28.000 IQD Hilo Algodón/Acrílico',
      chest: 'Contorno de Pecho: 104 - 112 cm', width: 'Ancho del Suéter: 52 - 56 cm', length: 'Largo Total: 60 cm (120 filas)',
      sleeve: 'Largo de Manga: 48 cm (96 filas)', hook: 'Ganchillo Recomendado: 3.5 - 4.0 mm',
      blueprints: 'Esquemas Técnicos de las 3 Piezas',
      partFront: 'Gráfico Delantero', partBack: 'Gráfico Espalda', partSleeves: 'Gráfico Mangas (tejer 2)',
      exportGrid: 'Exportar Cuadrícula 📥'
    },
    glossary: {
      title: 'Glosario Ilustrado de Puntos y Ganchillos', masterGuideBtn: 'Guía Completa de Medidas de Ganchillos e Hilos 📐',
      searchPh: 'Buscar punto o símbolo (ej: punto bajo, punto alto, cadeneta)...', emptySearch: 'No se encontraron puntos coincidentes',
      tagDiagram: '📐 Diagrama de Movimiento del Ganchillo (Vector)', tagTexture: '🧶 Muestra de Textura Real de Hilo'
    },
    notes: {
      title: 'Mis Notas y Proyectos Inteligentes', btnAdd: 'Nueva Nota', searchPh: 'Buscar en notas...',
      emptyTitle: 'No hay notas registradas', emptyDesc: 'Toca "+ Nueva Nota" para anotar tus lanas, proyectos en curso y listas de tareas'
    }
  }
};
`;

// 3. GLOSSARY MULTI-LANGUAGE DATA
const glossaryI18nScript = `
const GLOSSARY_I18N = {
  ch: {
    ar: { name: 'غرزة السلسلة', desc: 'الأساس في كل مشروع كروشيه — حبل من العقد المتناسقة لتأسيس أول سطر.' },
    en: { name: 'Chain Stitch', desc: 'The foundation of all crochet — a neat interlocking loop chain to start row 1.' },
    de: { name: 'Luftmasche', desc: 'Die Basis jedes Häkelprojekts — eine Kette gleichmäßiger Maschen für die Anschlagreihe.' },
    ja: { name: '鎖編み', desc: 'すべてのかぎ針編みの土台 — 1段目を編み始めるための均一な輪の鎖。' },
    tr: { name: 'Zincir İlmeği', desc: 'Tüm tığ işlerinin temeli — ilk sırayı başlatmak için örülen düzenli ilmek zinciri.' },
    ru: { name: 'Воздушная петля', desc: 'Основа любого вязания крючком — цепочка аккуратных петель для наборного ряда.' },
    es: { name: 'Punto Cadeneta', desc: 'La base de todo proyecto de crochet — una cadena de bucles uniformes para iniciar la labor.' }
  },
  sc: {
    ar: { name: 'غرزة الحشو', desc: 'الغرزة الأساسية لصنع الدمى والألعاب — نسيج متماسك ومحكم يمنع خروج الحشو.' },
    en: { name: 'Single Crochet', desc: 'The essential dense stitch for Amigurumi and sturdy bags — tight fabric that keeps stuffing inside.' },
    de: { name: 'Feste Masche', desc: 'Die Grundmasche für Amigurumis und Taschen — ein dichtes Maschenbild, das die Füllung festhält.' },
    ja: { name: '細編み（こまあみ）', desc: 'あみぐるみやバッグの基本 — 隙間なくしっかり編み上がり、綿の飛び出しを防ぎます。' },
    tr: { name: 'Sık İğne', desc: 'Amigurumi ve çantaların temel ilmeği — elyafın çıkmasını önleyen sıkı ve sağlam doku.' },
    ru: { name: 'Столбик без накида', desc: 'Главная петля для амигуруми и сумок — плотное полотно, надежно удерживающее наполнитель.' },
    es: { name: 'Punto Bajo', desc: 'El punto imprescindible para Amigurumis y cestas — tejido denso y firme que retiene el relleno.' }
  },
  dc: {
    ar: { name: 'غرزة العمود بلفة', desc: 'أطول من الحشو بضعفين وسريعة الإنجاز — تعطي نسيجاً انسيابياً للشالات والملابس.' },
    en: { name: 'Double Crochet', desc: 'Twice the height of single crochet and fast to work — creates supple drape for shawls and cardigans.' },
    de: { name: 'Stäbchen', desc: 'Doppelt so hoch wie feste Maschen und zügig gehäkelt — weicher, fließender Fall für Tücher und Kleidung.' },
    ja: { name: '長編み（ながあみ）', desc: '細編みの約2倍の高さでサクサク進む — ショールやウェアにしなやかなドレープを生み出します。' },
    tr: { name: 'İkili Trabzan', desc: 'Sık iğnenin iki katı uzunluğunda ve hızlı ilerleyen ilmek — şal ve kıyafetlere dökümlü yumuşaklık verir.' },
    ru: { name: 'Столбик с накидом', desc: 'Вдвое выше столбика б/н и вяжется быстро — создает мягкое пластичное полотно для шалей и свитеров.' },
    es: { name: 'Punto Alto', desc: 'El doble de alto que el punto bajo y de avance rápido — crea una caída suave para chales y prendas.' }
  },
  'sl st': {
    ar: { name: 'غرزة المنزلقة (الانزلاق)', desc: 'لإغلاق الأدوار الدائرية برقة أو الانتقال بين الغرز بدون إضافة أي ارتفاع للسطر.' },
    en: { name: 'Slip Stitch', desc: 'Used to join rounds seamlessly or travel across stitches with zero added height.' },
    de: { name: 'Kettmasche', desc: 'Dient zum unsichtbaren Schließen von Runden oder zum Weiterwandern ohne zusätzliche Höhe.' },
    ja: { name: '引き抜き編み', desc: '段のつなぎ目を平らに閉じたり、高さを出さずに糸を渡す際に使用します。' },
    tr: { name: 'İlmek Kaydırma', desc: 'Yuvarlak sıraları pürüzsüzce kapatmak veya ilmekler arasında yükseklik eklemeden geçmek için kullanılır.' },
    ru: { name: 'Соединительный столбик', desc: 'Служит для незаметного замыкания круговых рядов или перемещения без добавления высоты.' },
    es: { name: 'Punto Deslizado / Raso', desc: 'Se usa para cerrar vueltas de forma invisible o avanzar entre puntos sin añadir altura.' }
  },
  inc: {
    ar: { name: 'الزيادة (التوسيع)', desc: 'حياكة غرزتين كاملتين داخل نفس العين الواحدة لتوسيع محيط القطعة وتكبيرها.' },
    en: { name: 'Increase (2 in 1)', desc: 'Working two stitches into the exact same loop to expand circumference and shape pieces.' },
    de: { name: 'Zunahme (Verdoppeln)', desc: 'Zwei Maschen in dieselbe Einstichstelle häkeln, um das Werkstück zu erweitern.' },
    ja: { name: '増やし目', desc: '同じ目に2目編み入れ、円周を広げたりパーツを大きく立体成型します。' },
    tr: { name: 'Artırma (2 ilmek)', desc: 'Parçayı genişletmek için aynı ilmeğin içine iki kez batarak ilmek sayısını çoğaltma.' },
    ru: { name: 'Прибавка (2 в 1)', desc: 'Провязывание двух петель в одно основание для расширения полотна и формирования объема.' },
    es: { name: 'Aumento (2 en 1)', desc: 'Tejer dos puntos en el mismo punto base para ensanchar el contorno y moldear la pieza.' }
  },
  dec: {
    ar: { name: 'النقصان (التضييق)', desc: 'دمج غرزتين متجاورتين لتصبحا غرزة واحدة، مما يقلص حجم القطعة لتشكيل الرأس أو الأطراف.' },
    en: { name: 'Invisible Decrease', desc: 'Merging two adjacent stitches into one to narrow piece shaping for amigurumi heads and limbs.' },
    de: { name: 'Unsichtbare Abnahme', desc: 'Zwei Maschen zusammenhäkeln, um die Maschenanzahl für Köpfe und Gliedmaßen zu reduzieren.' },
    ja: { name: '減らし目（インビジブル）', desc: '隣り合う2目を1目にまとめ、頭や手足などの立体パーツをきれいにすぼめます。' },
    tr: { name: 'Görünmez Azaltma', desc: 'Kafa ve kol kısımlarını daraltmak için yan yana iki ilmeği birlikte alarak teke düşürme.' },
    ru: { name: 'Убавка (Невидимая)', desc: 'Объединение двух соседних петель в одну для аккуратного сужения деталей игрушек.' },
    es: { name: 'Disminución Invisible', desc: 'Unir dos puntos contiguos en uno solo para estrechar cabezas y extremidades en amigurumi.' }
  },
  MR: {
    ar: { name: 'الدائرة السحرية', desc: 'بداية الحياكة الدائرية للأميغورومي — تضمن إغلاق مركز الدائرة 100% بدون أي ثقب.' },
    en: { name: 'Magic Ring / Loop', desc: 'The starting technique for circular amigurumi — pulls tightly shut leaving zero center hole.' },
    de: { name: 'Fadenring (Magic Ring)', desc: 'Der ideale Rundenstart für Amigurumis — zieht sich lückenlos zu, ohne Mittelloch.' },
    ja: { name: 'わの作り目（マジックリング）', desc: 'あみぐるみ円編みの基本スタート — 糸端を引くだけで中心の穴が完全に閉まります。' },
    tr: { name: 'Sihirli Halka', desc: 'Dairesel amigurumilerin başlangıç tekniği — ortadaki deliği tamamen kapatır ve sıfır boşluk bırakır.' },
    ru: { name: 'Волшебное кольцо (Амигуруми)', desc: 'Начало кругового вязания игрушек — стягивается намертво, не оставляя центрального отверстия.' },
    es: { name: 'Anillo Mágico', desc: 'La técnica de inicio para amigurumi en redondo — se cierra herméticamente sin dejar hueco central.' }
  },
  BLO: {
    ar: { name: 'الحلقة الخلفية فقط', desc: 'إدخال السنارة في الخيط الخلفي فقط من السلسلة لتوليد خط بارز وتأثير مضلع مرن.' },
    en: { name: 'Back Loop Only (BLO)', desc: 'Inserting hook under the back bar only to produce neat ridges and stretchy ribbed texture.' },
    de: { name: 'Nur ins hintere Maschenglied', desc: 'Einstechen nur in das hintere Glied für schöne Querrippen und elastische Bündchen.' },
    ja: { name: 'すじ編み（奥の半目のみ）', desc: '鎖の奥側の糸だけを拾って編み、リブ編みのような伸縮性のある筋模様を作ります。' },
    tr: { name: 'Yalnızca Arka İlmek (BLO)', desc: 'Yalnızca arka ilmeğe batarak kabartmalı çizgiler ve esnek lastik dokusu oluşturma tekniği.' },
    ru: { name: 'За заднюю полупетлю (ЗСП)', desc: 'Введение крючка только за заднюю дужку петли для создания рельефных полос и резинки.' },
    es: { name: 'Solo Bucle Trasero (BLO)', desc: 'Tomar únicamente la hebra trasera para lograr un relieve acanalado y elástico.' }
  },
  FLO: {
    ar: { name: 'الحلقة الأمامية فقط', desc: 'إدخال السنارة في الخيط الأمامي فقط لعمل طبقات وكشاكش ناعمة.' },
    en: { name: 'Front Loop Only (FLO)', desc: 'Working into front bar only leaving the back loop accessible for layered ruffles or clothing.' },
    de: { name: 'Nur ins vordere Maschenglied', desc: 'Einstechen nur in das vordere Glied für zarte Rüschen oder mehrlagige Kleidungsstücke.' },
    ja: { name: '手前の半目のみ（FLO）', desc: '手前の糸だけを拾って編み、フリルや重ね着パーツを作る際に活用します。' },
    tr: { name: 'Yalnızca Ön İlmek (FLO)', desc: 'Ön ilmeğe batarak katmanlı fırfırlar veya giysi detayları örme tekniği.' },
    ru: { name: 'За переднюю полупетлю (ПСП)', desc: 'Вязание за переднюю стенку петли для рюшей, оборок и многослойных деталей.' },
    es: { name: 'Solo Bucle Delantero (FLO)', desc: 'Tejer solo en la hebra delantera para crear volantes, capas dobles o vestidos.' }
  }
};
`;

// 4. PATTERNS MULTI-LANGUAGE TRANSLATION MAP (covering key patterns)
const patternsI18nScript = `
const PATTERN_I18N = {
  'ami-kitten': {
    ar: { title: 'دمية قطة مشمشية كيو أميغورومي', desc: 'دمية قطة لطيفة ومكتنزة بأذنين مثلثتين وخدود وردية، مصممة بخطوات سطرية دقيقة مع أعداد الغرز الإلزامية.', level: 'مبتدئ', time: '3-4 ساعات' },
    en: { title: 'Apricot Kitten Cute Amigurumi', desc: 'Adorable plush kitten with pointed ears and rosy cheeks, crafted with round-by-round stitch counts.', level: 'Beginner', time: '3-4 hrs' },
    de: { title: 'Süßes Aprikosen-Kätzchen Amigurumi', desc: 'Kompaktes Plüschkätzchen mit Dreiecksohren und rosa Bäckchen, mit präzisen Rundenangaben.', level: 'Anfänger', time: '3-4 Std.' },
    ja: { title: 'アプリコット子猫のあみぐるみ', desc: '三角お耳とピンクのほっぺが愛らしい、段ごとの目数指示が付いた初心者向け子猫ちゃん。', level: '初級', time: '3-4時間' },
    tr: { title: 'Kayısı Yavru Kedi Amigurumi', desc: 'Üçgen kulakları ve pembe yanaklarıyla sevimli, adım adım ilmek sayıları belirtilmiş yavru kedi.', level: 'Başlangıç', time: '3-4 saat' },
    ru: { title: 'Абрикосовый котенок амигуруми', desc: 'Очаровательный плюшевый котенок с треугольными ушками и розовыми щечками, с точным расчетом петель.', level: 'Начинающий', time: '3-4 часа' },
    es: { title: 'Gatito Albaricoque Tierno Amigurumi', desc: 'Adorable gatito con orejas triangulares y mejillas sonrosadas, con instrucciones paso a paso.', level: 'Principiante', time: '3-4 horas' }
  },
  'royal-lotus-shawl': {
    ar: { title: 'شال زهرة اللوتس الملكي الدانتيل', desc: 'شال مثلثي فاخر مستوحى من بتلات زهرة اللوتس وأمواج البحر، بتدرج لوني انسيابي وغرز دانتيل مفتوحة خفيفة الوزن.', level: 'متوسط', time: '8-10 ساعات' },
    en: { title: 'Royal Lotus Lace Triangle Shawl', desc: 'Breathtaking openwork lace shawl inspired by blooming lotus petals with elegant color ombre gradient.', level: 'Intermediate', time: '8-10 hrs' },
    de: { title: 'Königliches Lotus-Spitzentuch', desc: 'Elegantes Dreieckstuch mit kunstvollem Ajourmuster, inspiriert von Lotusblüten mit sanftem Farbverlauf.', level: 'Mittel', time: '8-10 Std.' },
    ja: { title: 'ロイヤル・ロータス レースショール', desc: '蓮の花びらと波をモチーフにした透かし編み三角ショール。グラデーションが優雅に広がります。', level: '中級', time: '8-10時間' },
    tr: { title: 'Kraliyet Lotus Dantel Şalı', desc: 'Lotus çiçeklerinden ilham alan, dökümlü ve zarif renk geçişli lüks dantel üçgen şal.', level: 'Orta', time: '8-10 saat' },
    ru: { title: 'Царская шаль "Цветок Лотоса"', desc: 'Роскошная ажурная треугольная шаль с мотивами лепестков лотоса и плавным градиентом.', level: 'Средний', time: '8-10 часов' },
    es: { title: 'Chal Triangular Encaje Loto Real', desc: 'Majestuoso chal calado inspirado en pétalos de loto con degradado de color ligero y elegante.', level: 'Intermedio', time: '8-10 horas' }
  },
  'boho-basket': {
    ar: { title: 'سلة الخيوط البوهيمية المعقودة بخيط الكليم', desc: 'سلة تنظيم دائرية عصرية ومتماسكة جداً لجلسات الكروشيه وترتيب الخيوط، مصنوعة بقاعدة صلبة بدون ثقوب ومقبضين.', level: 'مبتدئ', time: '2-3 ساعات' },
    en: { title: 'Boho T-Shirt Yarn Storage Basket', desc: 'Sturdy circular organizing basket for crochet sessions and yarn skeins, featuring thick handles and seamless base.', level: 'Beginner', time: '2-3 hrs' },
    de: { title: 'Boho Textilgarn-Aufbewahrungskorb', desc: 'Formstabiler runder Utensilienkorb aus Textilgarn mit integrierten Tragegriffen für Wollknäuel.', level: 'Anfänger', time: '2-3 Std.' },
    ja: { title: 'ズパゲッティ・ボヘミアン収納バスケット', desc: 'Tシャツヤーンで編むしっかりとした自立型バスケット。毛糸の整理や小物入れに最適です。', level: '初級', time: '2-3時間' },
    tr: { title: 'Bohem Penye İp Düzenleyici Sepet', desc: 'Tığ işi iplerini düzenlemek için kulplu, sağlam tabanlı ve dik duran modern penye ip sepeti.', level: 'Başlangıç', time: '2-3 saat' },
    ru: { title: 'Бохо-корзина из трикотажной пряжи', desc: 'Устойчивая круглая корзинка с ручками для хранения клубков и рукоделия с плотным дном.', level: 'Начинающий', time: '2-3 часа' },
    es: { title: 'Cesta Organizadora Boho de Trapillo', desc: 'Cesta circular resistente con asas integradas, ideal para guardar ovillos y labores de tejido.', level: 'Principiante', time: '2-3 horas' }
  },
  'retro-granny-tote': {
    ar: { title: 'حقيبة مربعات الجدة الكلاسيكية بالأقحوان', desc: 'حقيبة كتف عصرية مكونة من 13 مربع جراني كلاسيكي بقلب زهرة الأقحوان المجسم، مبطنة بحواف متينة وحزامين مريحين.', level: 'متوسط', time: '6-8 ساعات' },
    en: { title: 'Retro Daisy Granny Square Tote Bag', desc: 'Chic shoulder bag crafted from 13 classic floral granny squares with textured 3D daisies and sturdy straps.', level: 'Intermediate', time: '6-8 hrs' },
    de: { title: 'Retro Granny-Square Schultertasche', desc: 'Trendige Tasche aus 13 traditionellen Granny Squares mit erhabenem Gänseblümchen-Muster und Tragegurten.', level: 'Mittel', time: '6-8 Std.' },
    ja: { title: 'レトロ・デイジー グラニースクエアバッグ', desc: '13枚のデイジーモチーフをつなぎ合わせた大人気トートバッグ。肩掛けしやすい丈夫な持ち手付き。', level: '中級', time: '6-8時間' },
    tr: { title: 'Retro Papatyalı Hanım Dilendi Çantası', desc: '13 adet kabartmalı papatya motifinin birleşiminden oluşan, sağlam askılı şık omuz çantası.', level: 'Orta', time: '6-8 saat' },
    ru: { title: 'Ретро-сумка из бабушкиных квадратов с ромашками', desc: 'Стильный шоппер из 13 цветочных мотивов с объемными ромашками и прочными ручками.', level: 'Средний', time: '6-8 часов' },
    es: { title: 'Bolso Retro de Cuadrados de la Abuela con Margaritas', desc: 'Bolso de hombro moderno compuesto por 13 granny squares florales en 3D con asas reforzadas.', level: 'Intermedio', time: '6-8 horas' }
  }
};
`;

// Combine into new file
const newI18nEngine = `${masterI18nScript}\n${glossaryI18nScript}\n${patternsI18nScript}`;

// Replace the old I18N_DICT block with the master engine
const oldDictStart = '//  MULTI-LANGUAGE INTERNATIONALIZATION (i18n) ENGINE';
const oldDictEnd = '// ═══════════════════════════════════════════════════════\n//  APP STATE & 100% PRIVATE LOCAL STORAGE';

const startIdx = html.indexOf(oldDictStart);
const endIdx = html.indexOf(oldDictEnd);

if (startIdx !== -1 && endIdx !== -1) {
  html = html.substring(0, startIdx) + newI18nEngine + '\n' + html.substring(endIdx);
  console.log('Replaced old I18N_DICT with complete master 7-language engine');
} else {
  console.warn('Could not locate exact oldDict start/end indices');
}

fs.writeFileSync(p, html, 'utf8');
console.log('Saved index.html with master 7-language dictionaries');
