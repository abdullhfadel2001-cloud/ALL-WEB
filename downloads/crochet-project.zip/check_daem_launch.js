const fs = require('fs');
const js = fs.readFileSync('C:\\Users\\dell\\OneDrive\\Desktop\\DAEM\\script.js', 'utf8');

const idx = js.indexOf('crochet-app');
console.log(js.substring(idx - 100, idx + 400));

const modalIdx = js.indexOf('openAppModal') !== -1 ? js.indexOf('openAppModal') : js.indexOf('demoUrl');
console.log('--- demoUrl usage ---');
const lines = js.split('\n');
lines.forEach((l, i) => {
  if (l.includes('demoUrl') || l.includes('openApp') || l.includes('location.href')) {
    console.log(`${i+1}: ${l}`);
  }
});

