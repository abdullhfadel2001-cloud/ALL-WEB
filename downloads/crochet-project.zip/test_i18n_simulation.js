const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');

const scriptRegex = /<script(?![^>]*\bsrc\b)[^>]*>([\s\S]*?)<\/script>/gi;
const blocks = [];
let m;
while ((m = scriptRegex.exec(html)) !== null) {
  blocks.push(m[1]);
}

const createMockElem = () => ({
  innerHTML: '', textContent: '',
  classList: { add(){}, remove(){}, toggle(){} },
  style: {},
  querySelector() { return createMockElem(); },
  querySelectorAll() { return [createMockElem()]; }
});

const fakeDom = {
  elements: {},
  getElementById(id) {
    if (!this.elements[id]) {
      this.elements[id] = createMockElem();
    }
    return this.elements[id];
  },
  querySelectorAll(sel) { return [createMockElem(), createMockElem(), createMockElem(), createMockElem()]; },
  querySelector(sel) { return createMockElem(); },
  addEventListener() {},
  documentElement: { lang: 'ar', dir: 'rtl', setAttribute(){} }
};

const context = {
  window: { addEventListener() {} },
  document: fakeDom,
  navigator: { serviceWorker: {} },
  location: { protocol: 'http:' },
  localStorage: { getItem(){ return null; }, setItem(){} },
  console: { log(){}, warn(){}, error(){} },
  Math, parseInt, parseFloat, Array, Object, String, JSON
};
vm.createContext(context);

vm.runInContext(blocks[0], context);
vm.runInContext(blocks[1], context);

console.log('--- Testing Language Switching in Memory ---');

// Test Arabic
context.setAppLanguage('ar');
console.log('App language set to AR. Dir:', context.document.documentElement.dir);
context.renderPatternsCatalogFiltered();
const arCardHtml = fakeDom.getElementById('patternsGridList').innerHTML;
console.log('AR Card includes "دمية قطة":', arCardHtml.includes('دمية قطة'));

// Test English
context.setAppLanguage('en');
console.log('App language set to EN. Dir:', context.document.documentElement.dir);
context.renderPatternsCatalogFiltered();
const enCardHtml = fakeDom.getElementById('patternsGridList').innerHTML;
console.log('EN Card includes "Apricot Kitten":', enCardHtml.includes('Apricot Kitten'));
console.log('EN Card includes "balls":', enCardHtml.includes('balls'));
console.log('EN Card includes "steps":', enCardHtml.includes('steps'));
console.log('EN Card includes "Progress":', enCardHtml.includes('Progress'));

// Test German (de)
context.setAppLanguage('de');
console.log('App language set to DE. Dir:', context.document.documentElement.dir);
context.renderPatternsCatalogFiltered();
const deCardHtml = fakeDom.getElementById('patternsGridList').innerHTML;
console.log('DE Card includes "Kätzchen":', deCardHtml.includes('Kätzchen'));
console.log('DE Card includes "Knäuel":', deCardHtml.includes('Knäuel'));
console.log('DE Card includes "Schritte":', deCardHtml.includes('Schritte'));

// Test Japanese (ja)
context.setAppLanguage('ja');
console.log('App language set to JA. Dir:', context.document.documentElement.dir);
context.renderPatternsCatalogFiltered();
const jaCardHtml = fakeDom.getElementById('patternsGridList').innerHTML;
console.log('JA Card includes "子猫":', jaCardHtml.includes('子猫'));
console.log('JA Card includes "玉":', jaCardHtml.includes('玉'));
console.log('JA Card includes "ステップ":', jaCardHtml.includes('ステップ'));

// Test Glossary in German
context.setAppLanguage('de');
context.renderGlossaryCatalog();
const deGlossary = fakeDom.getElementById('glossaryGridWrap').innerHTML;
console.log('DE Glossary includes "Feste Masche":', deGlossary.includes('Feste Masche'));
console.log('DE Glossary includes "Luftmasche":', deGlossary.includes('Luftmasche'));
console.log('DE Glossary includes "Maschendiagramm":', deGlossary.includes('Maschendiagramm'));

console.log('ALL IN-MEMORY TRANSLATION TESTS PASSED!');
