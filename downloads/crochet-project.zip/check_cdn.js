const https = require('https');

https.get('https://abdullhfadel2001-cloud.github.io/ALL-WEB/crochet/index.html?' + Date.now(), (res) => {
  console.log('Status:', res.statusCode);
  console.log('Cache-Control:', res.headers['cache-control']);
  console.log('ETag:', res.headers['etag']);
  console.log('Age:', res.headers['age']);
  let body = '';
  res.on('data', c => body += c);
  res.on('end', () => {
    console.log('Has langToggleBtn:', body.includes('id="langToggleBtn"'));
    console.log('Has langMenu:', body.includes('id="langMenu"'));
  });
});

