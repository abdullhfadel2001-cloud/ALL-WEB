const fs = require('fs');

const p = 'C:\\crochet_app\\index.html';
let html = fs.readFileSync(p, 'utf8');

const allPatternsI18n = `
const PATTERN_I18N = {
  'ami-kitten': {
    ar: { title: 'دمية قطة مشمشية كيو أميغورومي', desc: 'دمية قطة لطيفة ومكتنزة بأذنين مثلثتين وخدود وردية، مصممة بخطوات سطرية دقيقة مع أعداد الغرز الإلزامية.', level: 'مبتدئ', time: '3-4 ساعات' },
    en: { title: 'Apricot Kitten Cute Amigurumi', desc: 'Adorable plush kitten with pointed ears and rosy cheeks, crafted with round-by-round stitch counts.', level: 'Beginner', time: '3-4 hrs' },
    de: { title: 'Süßes Aprikosen-Kätzchen Amigurumi', desc: 'Kompaktes Plüschkätzchen mit Dreiecksohren und rosa Bäckchen, mit präzisen Rundenangaben.', level: 'Anfänger', time: '3-4 Std.' },
    ja: { title: 'アプリコット子猫のあみぐるみ', desc: '三角お耳とピンクのほっぺが愛らしい、段ごとの目数指示が付いた初心者向け子猫ちゃん。', level: '初級', time: '3-4時間' },
    tr: { title: 'Kayısı Yavru Kedi Amigurumi', desc: 'Üçgen kulakları ve pembe yanaklarıyla sevimli, adım adım ilmek sayıları belirtilmiş yavru kedi.', level: 'Başlangıç', time: '3-4 saat' },
    ru: { title: 'Абрикосовый котенок амигуруми', desc: 'Очаровательный плюшевый котенок с треугольными ушками и розовыми щечками, с точным расчетом петель.', level: 'Начинающий', time: '3-4 часа' },
    es: { title: 'Gatito Albaricoque Tierno Amigurumi', desc: 'Adorable gatito con orejas triangulares y mejillas sonrosadas, con instrucciones paso a paso.', level: 'Principiante', time: '3-4 horas' }
  },
  'royal-lotus-shawl': {
    ar: { title: 'شال زهرة اللوتس الملكي الدانتيل', desc: 'شال مثلثي فاخر مستوحى من بتلات زهرة اللوتس وأمواج البحر، بتدرج لوني انسيابي وغرز دانتيل مفتوحة خفيفة الوزن.', level: 'متوسط', time: '8-10 ساعات' },
    en: { title: 'Royal Lotus Lace Triangle Shawl', desc: 'Breathtaking openwork lace shawl inspired by blooming lotus petals with elegant color ombre gradient.', level: 'Intermediate', time: '8-10 hrs' },
    de: { title: 'Königliches Lotus-Spitzentuch', desc: 'Elegantes Dreieckstuch mit kunstvollem Ajourmuster, inspiriert von Lotusblüten mit sanftem Farbverlauf.', level: 'Mittel', time: '8-10 Std.' },
    ja: { title: 'ロイヤル・ロータス レースショール', desc: '蓮の花びらと波をモチーフにした透かし編み三角ショール。グラデーションが優雅に広がります。', level: '中級', time: '8-10時間' },
    tr: { title: 'Kraliyet Lotus Dantel Şalı', desc: 'Lotus çiçeklerinden ilham alan, dökümlü ve zarif renk geçişli lüks dantel üçgen şal.', level: 'Orta', time: '8-10 saat' },
    ru: { title: 'Царская шаль "Цветок Лотоса"', desc: 'Роскошная ажурная треугольная шаль с мотивами лепестков лотоса и плавным градиентом.', level: 'Средний', time: '8-10 часов' },
    es: { title: 'Chal Triangular Encaje Loto Real', desc: 'Majestuoso chal calado inspirado en pétalos de loto con degradado de color ligero y elegante.', level: 'Intermedio', time: '8-10 horas' }
  },
  'boho-basket': {
    ar: { title: 'سلة الخيوط البوهيمية المعقودة بخيط الكليم', desc: 'سلة تنظيم دائرية عصرية ومتماسكة جداً لجلسات الكروشيه وترتيب الخيوط، مصنوعة بقاعدة صلبة بدون ثقوب ومقبضين.', level: 'مبتدئ', time: '2-3 ساعات' },
    en: { title: 'Boho T-Shirt Yarn Storage Basket', desc: 'Sturdy circular organizing basket for crochet sessions and yarn skeins, featuring thick handles and seamless base.', level: 'Beginner', time: '2-3 hrs' },
    de: { title: 'Boho Textilgarn-Aufbewahrungskorb', desc: 'Formstabiler runder Utensilienkorb aus Textilgarn mit integrierten Tragegriffen für Wollknäuel.', level: 'Anfänger', time: '2-3 Std.' },
    ja: { title: 'ズパゲッティ・ボヘミアン収納バスケット', desc: 'Tシャツヤーンで編むしっかりとした自立型バスケット。毛糸の整理や小物入れに最適です。', level: '初級', time: '2-3時間' },
    tr: { title: 'Bohem Penye İp Düzenleyici Sepet', desc: 'Tığ işi iplerini düzenlemek için kulplu, sağlam tabanlı ve dik duran modern penye ip sepeti.', level: 'Başlangıç', time: '2-3 saat' },
    ru: { title: 'Бохо-корзина из трикотажной пряжи', desc: 'Устойчивая круглая корзинка с ручками для хранения клубков и рукоделия с плотным дном.', level: 'Начинающий', time: '2-3 часа' },
    es: { title: 'Cesta Organizadora Boho de Trapillo', desc: 'Cesta circular resistente con asas integradas, ideal para guardar ovillos y labores de tejido.', level: 'Principiante', time: '2-3 horas' }
  },
  'retro-granny-tote': {
    ar: { title: 'حقيبة مربعات الجدة الكلاسيكية بالأقحوان', desc: 'حقيبة كتف عصرية مكونة من 13 مربع جراني كلاسيكي بقلب زهرة الأقحوان المجسم، مبطنة بحواف متينة وحزامين مريحين.', level: 'متوسط', time: '6-8 ساعات' },
    en: { title: 'Retro Daisy Granny Square Tote Bag', desc: 'Chic shoulder bag crafted from 13 classic floral granny squares with textured 3D daisies and sturdy straps.', level: 'Intermediate', time: '6-8 hrs' },
    de: { title: 'Retro Granny-Square Schultertasche', desc: 'Trendige Tasche aus 13 traditionellen Granny Squares mit erhabenem Gänseblümchen-Muster und Tragegurten.', level: 'Mittel', time: '6-8 Std.' },
    ja: { title: 'レトロ・デイジー グラニースクエアバッグ', desc: '13枚のデイジーモチーフをつなぎ合わせた大人気トートバッグ。肩掛けしやすい丈夫な持ち手付き。', level: '中級', time: '6-8時間' },
    tr: { title: 'Retro Papatyalı Hanım Dilendi Çantası', desc: '13 adet kabartmalı papatya motifinin birleşiminden oluşan, sağlam askılı şık omuz çantası.', level: 'Orta', time: '6-8 saat' },
    ru: { title: 'Ретро-сумка из бабушкиных квадратов с ромашками', desc: 'Стильный шоппер из 13 цветочных мотивов с объемными ромашками и прочными ручками.', level: 'Средний', time: '6-8 часов' },
    es: { title: 'Bolso Retro de Cuadrados de la Abuela con Margaritas', desc: 'Bolso de hombro moderno compuesto por 13 granny squares florales en 3D con asas reforzadas.', level: 'Intermedio', time: '6-8 horas' }
  },
  'ami-bear': {
    ar: { title: 'دمية دب أميغورومي كيوت', desc: 'دمية كلاسيكية محبوبة للأطفال، محبوكة بغرزة الحشو اللولبية مع أطراف ناعمة وتطريز ملامح لطيفة.', level: 'مبتدئ', time: '3-4 ساعات' },
    en: { title: 'Cute Teddy Bear Amigurumi', desc: 'Beloved classic nursery bear crocheted in continuous spiral single crochet with soft paws.', level: 'Beginner', time: '3-4 hrs' },
    de: { title: 'Klassischer Teddybär Amigurumi', desc: 'Beliebter Spielzeugbär in Spiralrunden mit festen Maschen gehäkelt, mit weichen Pfötchen.', level: 'Anfänger', time: '3-4 Std.' },
    ja: { title: 'くまのテディベア あみぐるみ', desc: 'らせん編みで作る大人気の定番くまちゃん。手足のバランスが良くプレゼントにも大好評。', level: '初級', time: '3-4時間' },
    tr: { title: 'Sevimli Oyuncak Ayıcık Amigurumi', desc: 'Sürekli spiral sık iğne tekniğiyle örülen, yumuşak patili klasik çocuk ayıcığı.', level: 'Başlangıç', time: '3-4 saat' },
    ru: { title: 'Милый мишка амигуруми', desc: 'Классический плюшевый мишка, связанный по спирали столбиками без накида с мягкими лапками.', level: 'Начинающий', time: '3-4 часа' },
    es: { title: 'Osito de Peluche Tierno Amigurumi', desc: 'Clásico osito infantil tejido en espiral continua con punto bajo y extremidades suaves.', level: 'Principiante', time: '3-4 horas' }
  },
  'ami-bunny': {
    ar: { title: 'أرنب أميغورومي بأذنين طويلتين', desc: 'أرنب رقيق جداً بأذنين متدليتين طويلتين وفستان ناعم، هدية مثالية للمواليد والأطفال.', level: 'مبتدئ', time: '4-5 ساعات' },
    en: { title: 'Long-Eared Lop Bunny Amigurumi', desc: 'Gentle plush bunny with charming floppy ears, perfect baby shower handcrafted gift.', level: 'Beginner', time: '4-5 hrs' },
    de: { title: 'Schlappohr-Häschen Amigurumi', desc: 'Zartes Häschen mit langen Schlappohren, ein perfektes Geschenk zur Geburt und Taufe.', level: 'Anfänger', time: '4-5 Std.' },
    ja: { title: 'たれ耳うさぎのあみぐるみ', desc: '長い耳が愛らしいたれ耳うさぎ。出産祝いやお子様へのプレゼントに大人気です。', level: '初級', time: '4-5時間' },
    tr: { title: 'Uzun Kulaklı Tavşan Amigurumi', desc: 'Uzun sarkık kulakları ve sevimli tasarımıyla yeni doğan bebekler için harika bir hediye.', level: 'Başlangıç', time: '4-5 saat' },
    ru: { title: 'Зайка с длинными ушками амигуруми', desc: 'Нежный зайчик с длинными висячими ушками, прекрасный подарок для малышей.', level: 'Начинающий', time: '4-5 часов' },
    es: { title: 'Conejito de Orejas Caídas Amigurumi', desc: 'Tierno conejito de largas orejas caídas, un regalo artesanal ideal para recién nacidos.', level: 'Principiante', time: '4-5 horas' }
  },
  'ami-elephant': {
    ar: { title: 'فيل ميني بخرطوم لطيف', desc: 'مجسم فيل صغير ومكتنز بأذنين عريضتين وخرطوم مرفوع للأعلى رمزاً للبهجة والحظ.', level: 'مبتدئ', time: '2-3 ساعات' },
    en: { title: 'Mini Lucky Elephant Amigurumi', desc: 'Chubby pocket elephant with wide flapping ears and upturned trunk symbolizing happiness.', level: 'Beginner', time: '2-3 hrs' },
    de: { title: 'Kleiner Glückselefant Amigurumi', desc: 'Putziger kleiner Elefant mit großen Ohren und aufgerichtetem Rüssel als Glücksbringer.', level: 'Anfänger', time: '2-3 Std.' },
    ja: { title: '幸運のミニ子象あみぐるみ', desc: '大きなお耳と上に上がったお鼻が幸運を呼ぶ、手のひらサイズのころころ子象。', level: '初級', time: '2-3時間' },
    tr: { title: 'Uğurlu Minik Fil Amigurumi', desc: 'Geniş kulakları ve havaya kalkık hortumuyla şans ve neşe getiren tombik minik fil.', level: 'Başlangıç', time: '2-3 saat' },
    ru: { title: 'Маленький слоненок на счастье', desc: 'Забавный пухлый слоник с большими ушками и поднятым хоботком, символ уюта и удачи.', level: 'Начинающий', time: '2-3 часа' },
    es: { title: 'Elefantito de la Suerte Amigurumi', desc: 'Regordete elefante de bolsillo con orejas amplias y trompa hacia arriba, símbolo de alegría.', level: 'Principiante', time: '2-3 horas' }
  },
  'shawl-granny': {
    ar: { title: 'شال مربعات الجدة الكلاسيكي الفاخر', desc: 'شال مثلثي مريح بغرز العناقيد ومربعات الجدة التراثية مع شراشيب فخمة عند الأطراف.', level: 'متوسط', time: '10-12 ساعة' },
    en: { title: 'Classic Granny Triangle Shawl', desc: 'Heritage cluster stitches forming a warm triangular wrap finished with luxurious tasseled edging.', level: 'Intermediate', time: '10-12 hrs' },
    de: { title: 'Traditionelles Granny-Dreieckstuch', desc: 'Zeitlose Büschelmaschen formen ein kuscheliges Wolltuch mit Fransenabschluss.', level: 'Mittel', time: '10-12 Std.' },
    ja: { title: 'クラシック・グラニートライアングルショール', desc: '伝統のグラニーステッチで編み進める大判三角ショール。フリンジ仕上げで暖か。', level: '中級', time: '10-12時間' },
    tr: { title: 'Klasik Hanım Dilendi Üçgen Şal', desc: 'Geleneksel küme trabzanlarla örülen ve uçlarında püsküller bulunan sıcak üçgen şal.', level: 'Orta', time: '10-12 saat' },
    ru: { title: 'Шаль из бабушкиных мотивов', desc: 'Уютная теплая шаль с традиционным узором и роскошной отделкой бахромой.', level: 'Средний', time: '10-12 часов' },
    es: { title: 'Chal Clásico de Cuadros Granny', desc: 'Patrón tradicional de grupos de puntos altos formando un chal cálido con flecos elegantes.', level: 'Intermedio', time: '10-12 horas' }
  },
  'shawl-triangle': {
    ar: { title: 'شال بوهو المثلثي الشتوي', desc: 'شال كروشيه سميك ودافئ بتدرجات شتوية وغرز مضلعة تحمي من البرد بأناقة.', level: 'متوسط', time: '8-10 ساعات' },
    en: { title: 'Winter Cozy Boho Triangle Shawl', desc: 'Warm textured ribbed shawl made with chunky yarn to keep cozy in chic bohemian style.', level: 'Intermediate', time: '8-10 hrs' },
    de: { title: 'Kuscheliges Winter-Boho-Dreieckstuch', desc: 'Dickes wärmendes Tuch mit plastischem Rippenmuster im angesagten Bohème-Look.', level: 'Mittel', time: '8-10 Std.' },
    ja: { title: '冬の暖かボヘミアン三角ショール', desc: '太めの毛糸で編む立体リブ模様のショール。寒い季節を暖かくスタイリッシュに彩ります。', level: '中級', time: '8-10時間' },
    tr: { title: 'Kışlık Sıcak Bohem Üçgen Şal', desc: 'Kış soğuklarından koruyan, kalın yünle örülen kabartmalı ve dokulu bohem şal.', level: 'Orta', time: '8-10 saat' },
    ru: { title: 'Зимняя теплая треугольная бохо-шаль', desc: 'Объемная фактурная шаль из мягкой полушерсти для стильных и теплых зимних прогулок.', level: 'Средний', time: '8-10 часов' },
    es: { title: 'Chal Boho Triangular de Invierno', desc: 'Chal grueso y cálido tejido con relieves acanalados que protegen del frío con gran estilo.', level: 'Intermedio', time: '8-10 horas' }
  },
  'mandala-doily': {
    ar: { title: 'مفرش مانديلا دانتيل دائري', desc: 'لوحة فنية دائرية من الغرز المزخرفة والبيكو لتزيين طاولات القهوة والصالونات الراقية.', level: 'متوسط', time: '5-6 ساعات' },
    en: { title: 'Circular Lace Mandala Doily', desc: 'Intricate concentric circles of picots and shells forming a breathtaking centerpiece.', level: 'Intermediate', time: '5-6 hrs' },
    de: { title: 'Rundes Spitzen-Mandala Deckchen', desc: 'Filigrane konzentrische Runden mit Muscheln und Picots als edler Tischschmuck.', level: 'Mittel', time: '5-6 Std.' },
    ja: { title: '円形レース編み マンダラドイリー', desc: 'ピコットとシェル編みが同心円状に広がる美しいドイリー。テーブルのアクセントに。', level: '中級', time: '5-6時間' },
    tr: { title: 'Dairesel Dantel Mandala Sehpa Örtüsü', desc: 'Sehpalar ve salonlar için pikot ve midye motifleriyle bezenmiş sanatsal yuvarlak örtü.', level: 'Orta', time: '5-6 saat' },
    ru: { title: 'Круглая салфетка-мандала', desc: 'Изящный концентрический узор с пико и ракушками, изысканное украшение для интерьера.', level: 'Средний', time: '5-6 часов' },
    es: { title: 'Tapete Circular Mandala de Encaje', desc: 'Elegante diseño concéntrico de conchas y picots para decorar mesas de centro con distinción.', level: 'Intermedio', time: '5-6 horas' }
  },
  'basket-home': {
    ar: { title: 'سلة كروشيه لتنظيم المنزل', desc: 'سلة أسطوانية متماسكة بخيط قطني مزدوج لتخزين أدوات المكياج أو مفاتيح المدخل.', level: 'مبتدئ', time: '2-3 ساعات' },
    en: { title: 'Home Storage Organizer Basket', desc: 'Cylindrical sturdy basket crocheted with held-together cotton yarn for home vanity items.', level: 'Beginner', time: '2-3 hrs' },
    de: { title: 'Praktischer Utensilienkorb fürs Zuhause', desc: 'Stabiler Zylinderkorb aus zweifädigem Baumwollgarn für Bad, Make-up oder Schlüssel.', level: 'Anfänger', time: '2-3 Std.' },
    ja: { title: 'ナチュラル整理整頓バスケット', desc: '極太コットン糸で編む自立型シリンダーバスケット。コスメや小物整理に重宝します。', level: '初級', time: '2-3時間' },
    tr: { title: 'Ev Düzenleme Sepeti', desc: 'Çift kat pamuk iple örülen, makyaj ve anahtarlık eşyalarını düzenlemek için dik duran sepet.', level: 'Başlangıç', time: '2-3 saat' },
    ru: { title: 'Интерьерная корзинка для дома', desc: 'Плотная корзина цилиндрической формы из хлопкового шнура для косметики и мелочей.', level: 'Начинающий', time: '2-3 часа' },
    es: { title: 'Cesta Organizadora para el Hogar', desc: 'Cesta cilíndrica firme tejida con hilo doble de algodón para organizar maquillaje o recibidor.', level: 'Principiante', time: '2-3 horas' }
  },
  'bag-raffia': {
    ar: { title: 'حقيبة رافيا صيفية عصرية', desc: 'حقيبة كروشيه خفيفة من خيوط الرافيا الطبيعية بنقشة مخرمة تناسب نزهات الشاطئ والصيف.', level: 'متوسط', time: '6-8 ساعات' },
    en: { title: 'Chic Summer Raffia Tote Bag', desc: 'Lightweight summer bag crocheted from natural raffia straw with open breezy texture.', level: 'Intermediate', time: '6-8 hrs' },
    de: { title: 'Sommerliche Bastgarn-Tasche', desc: 'Leichte Sommertasche aus natürlichem Bast mit luftigem Muster, ideal für Strand und Stadt.', level: 'Mittel', time: '6-8 Std.' },
    ja: { title: 'サマー・ラフィア トートバッグ', desc: '天然ラフィア風ヤーンで編む軽やかな透かし模様バッグ。夏のお出かけにぴったりです。', level: '中級', time: '6-8時間' },
    tr: { title: 'Yazlık Şık Hasır Rafya Çanta', desc: 'Doğal rafya iple örülen, yaz tatilleri ve sahil gezintileri için ideal hafif delikli çanta.', level: 'Orta', time: '6-8 saat' },
    ru: { title: 'Летняя сумка из рафии', desc: 'Легкая фактурная сумка из натуральной рафии с воздушным узором для пляжа и города.', level: 'Средний', time: '6-8 часов' },
    es: { title: 'Bolso de Verano en Rafia Natural', desc: 'Bolso ligero de fibra vegetal con calados veraniegos, perfecto para paseos y playa.', level: 'Intermedio', time: '6-8 horas' }
  },
  'bag-market': {
    ar: { title: 'حقيبة تسوق شبكية متمددة', desc: 'حقيبة صديقة للبيئة مرنة تتمدد لتحمل الخضار والفواكه وقابلة للطي في الجيب.', level: 'مبتدئ', time: '3-4 ساعات' },
    en: { title: 'Eco French Market Net Bag', desc: 'Zero-waste expandable mesh tote that stretches to carry produce and folds into a pocket.', level: 'Beginner', time: '3-4 hrs' },
    de: { title: 'Französische Markt-Netztasche', desc: 'Nachhaltiger Einkaufsbeutel aus Baumwoll-Netzmaschen, dehnbar und extrem platzsparend faltbar.', level: 'Anfänger', time: '3-4 Std.' },
    ja: { title: '伸縮フレンチ・マーケットバッグ', desc: '果物や野菜を入れてもぐんぐん伸びるエコネットバッグ。小さく畳めて携帯性抜群。', level: '初級', time: '3-4時間' },
    tr: { title: 'Esnek File Pazar Çantası', desc: 'Meyve ve sebze taşımak için esneyen, cebe sığacak kadar katlanabilen çevre dostu file çanta.', level: 'Başlangıç', time: '3-4 saat' },
    ru: { title: 'Французская эко-авоська', desc: 'Вместительная растягивающаяся сетчатая сумка для покупок, легко складывается в карман.', level: 'Начинающий', time: '3-4 часа' },
    es: { title: 'Bolsa de Malla Ecológica para Compras', desc: 'Bolsa francesa expandible de red que se estira para llevar compras y cabe en el bolsillo.', level: 'Principiante', time: '3-4 horas' }
  },
  'beanie-hat': {
    ar: { title: 'قبعة بيني شتوية مضلعة', desc: 'قبعة دافئة محبوكة بغرزة النصف عمود في الحلقة الخلفية مع كشكشة لطيفة في الأعلى.', level: 'مبتدئ', time: '2-3 ساعات' },
    en: { title: 'Classic Ribbed Winter Beanie', desc: 'Stretchy ribbed toque crocheted flat using half-double crochet BLO and gathered at the crown.', level: 'Beginner', time: '2-3 hrs' },
    de: { title: 'Warme Rippenstrick-Beaniemütze', desc: 'Elastische Rippenmütze aus halben Stäbchen ins hintere Maschenglied, oben zusammengezogen.', level: 'Anfänger', time: '2-3 Std.' },
    ja: { title: 'リブ編みあったかニット帽（ビーニー）', desc: 'すじ編みで編む伸縮性抜群のニット帽。すっきりとしたシルエットで防寒性も最高。', level: '初級', time: '2-3時間' },
    tr: { title: 'Fitilli Sıcak Kışlık Bere', desc: 'Yarım trabzanın arka ilmeğine batılarak esnek fitil dokusuyla örülen şık kış beresi.', level: 'Başlangıç', time: '2-3 saat' },
    ru: { title: 'Теплая рельефная шапка-бини', desc: 'Эластичная шапка узором "резинка" из полустолбиков за заднюю стенку петли.', level: 'Начинающий', time: '2-3 часа' },
    es: { title: 'Gorro Beanie de Invierno Acanalado', desc: 'Gorro elástico tejido en punto medio alto en hebra trasera, con cierre fruncido en la coronilla.', level: 'Principiante', time: '2-3 horas' }
  },
  'socks-warm': {
    ar: { title: 'جوارب منزلية ناعمة', desc: 'جوارب كروشيه مريحة للقدمين للأمسيات الباردة بنعل سميك ومقاس مرن يناسب الجميع.', level: 'متوسط', time: '4-5 ساعات' },
    en: { title: 'Cozy Slipper Socks', desc: 'Snug home foot warmers designed with cushioned reinforced soles for chilly evenings.', level: 'Intermediate', time: '4-5 hrs' },
    de: { title: 'Gemütliche Kuschel-Haussocken', desc: 'Warme Bettsocken mit verstärkter Sohle und elastischem Schaft für kalte Abende.', level: 'Mittel', time: '4-5 Std.' },
    ja: { title: 'ふんわりルームソックス（靴下）', desc: 'クッション性のある二重底で冷えから足元を守る、おうち時間に快適な手編みソックス。', level: '中級', time: '4-5時間' },
    tr: { title: 'Yumuşacık Ev Patik Çorabı', desc: 'Soğuk akşamlar için ayakları sıcacık tutan, dolgulu tabanlı konforlu ev çorabı.', level: 'Orta', time: '4-5 saat' },
    ru: { title: 'Уютные домашние носочки-следочки', desc: 'Мягкие теплые носки для дома с уплотненной подошвой и комфортной посадкой по ноге.', level: 'Средний', time: '4-5 часов' },
    es: { title: 'Calcetines Pantufla Acolchados', desc: 'Cómodos calcetines de estar por casa con suela reforzada para mantener los pies calientes.', level: 'Intermedio', time: '4-5 horas' }
  },
  'headband': {
    ar: { title: 'عصابة رأس تويست عريضة', desc: 'ربطة شعر شتوية أنيقة بلفة أمامية متقاطعة (Twist) تغطي الأذنين وتمنحكِ مظهراً عصرياً.', level: 'مبتدئ', time: '1-2 ساعة' },
    en: { title: 'Chic Twist Knot Headband', desc: 'Stylish wide ear warmer featuring an easy folded front knot for trendy hair days.', level: 'Beginner', time: '1-2 hrs' },
    de: { title: 'Elegantes Stirnband mit Twist-Knoten', desc: 'Modischer Ohrenwärmer mit gekreuztem Knoten auf der Stirn, schnell an einem Abend gehäkelt.', level: 'Anfänger', time: '1-2 Std.' },
    ja: { title: 'フロントツイスト・ヘアバンド', desc: '前中心でクロスさせた立体デザインが可愛い、耳まですっぽり暖かいヘアバンド。', level: '初級', time: '1-2時間' },
    tr: { title: 'Şık Burgulu Kışlık Saç Bandı', desc: 'Kulakları ısıtan ve önden çapraz bükümlü şık tasarımıyla 1-2 saatte örülen saç bandı.', level: 'Başlangıç', time: '1-2 saat' },
    ru: { title: 'Стильная повязка на голову с узлом', desc: 'Теплая широкая повязка для ушей с красивым перекрестным узлом спереди, вяжется за час.', level: 'Начинающий', time: '1-2 часа' },
    es: { title: 'Diadema Turbante con Nudo Frontal', desc: 'Elegante calentador de orejas con diseño cruzado tipo turbante, rápido y favorecedor.', level: 'Principiante', time: '1-2 horas' }
  },
  'baby-shoes': {
    ar: { title: 'حذاء بيبي كروشيه للمواليد', desc: 'لكلوك بيبي ناعم جداً من خيوط قطنية لا تسبب أي حساسية مع شريط إغلاق بحبة لؤلؤ.', level: 'مبتدئ', time: '2-3 ساعات' },
    en: { title: 'Sweet Newborn Baby Booties', desc: 'Ultra-soft allergen-free cotton booties finished with a sweet strap and button closure.', level: 'Beginner', time: '2-3 hrs' },
    de: { title: 'Zarte Neugeborenen-Babyschuhe', desc: 'Federleichte Schühchen aus hypoallergener Baby-Baumwolle mit praktischem Riemchen.', level: 'Anfänger', time: '2-3 Std.' },
    ja: { title: 'オーガニックコットン ベビーブーティ', desc: '赤ちゃんの肌に優しいコットン糸で編む柔らかシューズ。ストラップボタン付き。', level: '初級', time: '2-3時間' },
    tr: { title: 'Yenidoğan Bebek Patiği', desc: 'Hassas bebek tenine uygun antialerjik pamuk iple örülen, düğmeli tatlı patik.', level: 'Başlangıç', time: '2-3 saat' },
    ru: { title: 'Нежные пинетки для новорожденного', desc: 'Мягкие пинетки из гипоаллергенного хлопка с ремешком на пуговке для самых маленьких.', level: 'Начинающий', time: '2-3 часа' },
    es: { title: 'Patucos Suaves para Recién Nacido', desc: 'Zapatitos delicados de algodón hipoalergénico con tira de cierre y botón para bebé.', level: 'Principiante', time: '2-3 horas' }
  },
  'baby-blanket': {
    ar: { title: 'بطانية أطفال غرزة الوافل', desc: 'بطانية فخمة وسميكة بغرز الأعمدة الأمامية لتوليد مربعات الوافل المجسمة فائقة الدفء.', level: 'متوسط', time: '12-15 ساعة' },
    en: { title: '3D Waffle Stitch Baby Blanket', desc: 'Luxurious textured throw with deep raised grid pockets delivering cloud-like warmth.', level: 'Intermediate', time: '12-15 hrs' },
    de: { title: '3D-Waffelmuster Babydecke', desc: 'Hochwertige Kuscheldecke mit erhabenen Reliefstäbchen, die tiefe wärmende Waben bilden.', level: 'Mittel', time: '12-15 Std.' },
    ja: { title: '立体ワッフル編み ベビーブランケット', desc: '引き上げ編みで作る凹凸ワッフル模様。空気を含んでふっくら極上の暖かさ。', level: '中級', time: '12-15時間' },
    tr: { title: '3D Waffle Dokulu Bebek Battaniyesi', desc: 'Kabartmalı trabzanlarla örülen ve derin petek dokusuyla sıcacık tutan lüks battaniye.', level: 'Orta', time: '12-15 saat' },
    ru: { title: 'Объемный детский плед "Вафельный"', desc: 'Роскошный рельефный плед с глубокой сотовой текстурой, дарящей уютное тепло.', level: 'Средний', time: '12-15 часов' },
    es: { title: 'Manta Infantil con Relieve Punto Gofre', desc: 'Manta esponjosa y mullida tejida con puntos altos en relieve formando celdas térmicas.', level: 'Intermedio', time: '12-15 horas' }
  },
  'flower-sunflower': {
    ar: { title: 'زهرة عباد الشمس المجسمة', desc: 'تطبيق زخرفي ثلاثي الأبعاد لزهرة دوار الشمس بقلب بني محبب وبتلات صفراء مدببة.', level: 'مبتدئ', time: '1-2 ساعة' },
    en: { title: '3D Blooming Sunflower Applique', desc: 'Vibrant textured blossom with rich textured brown seed center and golden pointed petals.', level: 'Beginner', time: '1-2 hrs' },
    de: { title: '3D-Sonnenblumen-Applikation', desc: 'Leuchtende Zierblume mit noppiger brauner Mitte und spitzen goldgelben Blütenblättern.', level: 'Anfänger', time: '1-2 Std.' },
    ja: { title: '立体ひまわりモチーフ（コサージュ）', desc: 'ぷっくりとした中心の種部分と鮮やかな黄色い花びらが映える立体フラワー。', level: '初級', time: '1-2時間' },
    tr: { title: '3D Ayçiçeği Dekoru', desc: 'Kabartmalı kahverengi tohum göbeği ve sivri sarı taç yapraklarıyla neşeli çiçek motifi.', level: 'Başlangıç', time: '1-2 saat' },
    ru: { title: 'Объемный подсолнух крючком', desc: 'Яркий декоративный цветок с фактурной серединкой и заостренными желтыми лепестками.', level: 'Начинающий', time: '1-2 часа' },
    es: { title: 'Girasol en Relieve 3D', desc: 'Vistosa flor decorativa con centro marrón texturizado y pétalos puntiagudos dorados.', level: 'Principiante', time: '1-2 horas' }
  },
  'flower-rose': {
    ar: { title: 'وردة جورية ثلاثية الأبعاد', desc: 'وردة رومانسية ملفوفة بطبقات بتلات متدرجة لتزيين الشالات والحقائب وأطواق الشعر.', level: 'مبتدئ', time: '1 ساعة' },
    en: { title: 'Layered 3D English Rose', desc: 'Romantic rolled petal bloom that curls effortlessly into a full rose for hats and pins.', level: 'Beginner', time: '1 hr' },
    de: { title: 'Dreidimensionale Edelrose', desc: 'Romantische gerollte Rose mit sanft geschwungenen Blütenblättern für Mützen und Broschen.', level: 'Anfänger', time: '1 Std.' },
    ja: { title: '立体巻きバラモチーフ', desc: '編んでくるくる巻くだけで完成するエレガントな薔薇。ブローチやヘアゴムに。', level: '初級', time: '1時間' },
    tr: { title: 'Katmanlı 3D Gül Motifi', desc: 'Şal ve tokaları süslemek için katmerli yapraklarıyla rulo halinde dikilen zarif gül.', level: 'Başlangıç', time: '1 saat' },
    ru: { title: 'Пышная объемная роза', desc: 'Романтичный цветок из спирально свернутой ленты лепестков для украшения одежды.', level: 'Начинающий', time: '1 час' },
    es: { title: 'Rosa Inglesa en Capas 3D', desc: 'Flor enrollada de pétalos ondeados que forma una rosa perfecta para broches y bolsos.', level: 'Principiante', time: '1 hora' }
  },
  'cushion-cover': {
    ar: { title: 'غطاء وسادة بوهو مزخرف', desc: 'غطاء وسادة صالون مربع بغرز البوب كورن البارزة وشراشيب جانبية تعطي فخامة لديكور الغرفة.', level: 'متوسط', time: '8-10 ساعات' },
    en: { title: 'Textured Boho Popcorn Cushion Cover', desc: 'Chic square sofa throw pillow cover featuring tactile popcorn clusters and side fringe.', level: 'Intermediate', time: '8-10 hrs' },
    de: { title: 'Boho-Popcorn Kissenhülle', desc: 'Stilvoller Kissenbezug fürs Sofa mit fühlbaren Popcorn-Maschen und verspielten Quasten.', level: 'Mittel', time: '8-10 Std.' },
    ja: { title: 'ポップコーン編み ボヘミアンクッションカバー', desc: '立体的なぽこぽこポップコーン編みがおしゃれなスクエアクッションカバー。', level: '中級', time: '8-10時間' },
    tr: { title: 'Bohem Popcorn Kırlent Kılıfı', desc: 'Kabartmalı fıstık ilmekleriyle salonlara sıcaklık katan püsküllü dekoratif yastık kılıfı.', level: 'Orta', time: '8-10 saat' },
    ru: { title: 'Бохо-наволочка узором "Попкорн"', desc: 'Эффектная диванная подушка с объемными шариками и бахромой для уюта в гостиной.', level: 'Средний', time: '8-10 часов' },
    es: { title: 'Funda de Cojín Boho Punto Palomita', desc: 'Elegante funda decorativa de sofá con racimos en relieve tipo popcorn y flecos laterales.', level: 'Intermedio', time: '8-10 horas' }
  },
  'advanced-sweater': {
    ar: { title: 'سويتر كروشيه كلاسيكي أنيق', desc: 'كنزة شتوية محبوكة بقطع هندسية مفصلة وياقة مثلثة، مناسبة للمحترفين الراغبين بملابس متقنة.', level: 'محترف', time: '18-22 ساعة' },
    en: { title: 'Classic Tailored Artisan Sweater', desc: 'Exquisite seamless garment crafted with fitted shoulder shaping and ribbed cuffs for master makers.', level: 'Advanced', time: '18-22 hrs' },
    de: { title: 'Klassischer Maßgeschneiderter Pullover', desc: 'Anspruchsvoller Pullover mit sauber ausgearbeiteten Armkugeln und dehnbaren Bündchen.', level: 'Fortgeschritten', time: '18-22 Std.' },
    ja: { title: '仕立ての良いクラシック・セーター', desc: '肩の減らし目やリブ袖口まで本格的に計算された、上級者向けの上質ハンドメイドセーター。', level: '上級', time: '18-22時間' },
    tr: { title: 'Klasik Zarif Kışlık Kazak', desc: 'Omuz kesimleri ve manşetleriyle kusursuz oturan, usta eller için tasarlanmış şık kazak.', level: 'İleri Düzey', time: '18-22 saat' },
    ru: { title: 'Классический свитер ручной работы', desc: 'Безупречное плечевое изделие с анатомической посадкой и эластичными манжетами для профи.', level: 'Продвинутый', time: '18-22 часа' },
    es: { title: 'Suéter Clásico de Sastrería', desc: 'Prenda artesanal de corte impecable con sisas menguadas y puños elásticos para tejedoras expertas.', level: 'Avanzado', time: '18-22 horas' }
  },
  'advanced-mandala-wall': {
    ar: { title: 'مانديلا حائطية عملاقة داخل طارة', desc: 'تحفة ديكور جدارية قطرها 60 سم مشدودة على طارة خشبية، تجمع أعقد غرز الدانتيل والريش المتدلي.', level: 'محترف', time: '14-16 ساعة' },
    en: { title: 'Giant Hoop Mandala Wall Tapestry', desc: 'Dramatic 60cm bohemian statement art stretched over a wooden hoop with trailing feathers.', level: 'Advanced', time: '14-16 hrs' },
    de: { title: 'Großer Mandala-Wandbehang im Holzreifen', desc: 'Spektakuläres 60cm Wandkunstwerk mit anspruchsvollen Spitzenmustern und Traumfänger-Quasten.', level: 'Fortgeschritten', time: '14-16 Std.' },
    ja: { title: '巨大フープ・マンダラ タペストリー', desc: '直径60cmの木製フープに張り渡す圧巻の壁飾り。複雑なレース編みとタッセルが豪華。', level: '上級', time: '14-16時間' },
    tr: { title: 'Çemberli Dev Duvar Mandalsı', desc: '60 cm çapında ahşap kasnağa gerilen, püsküllü ve en karmaşık dantel tekniklerini içeren sanat eseri.', level: 'İleri Düzey', time: '14-16 saat' },
    ru: { title: 'Гигантская настенная мандала в обруче', desc: 'Грандиозное настенное панно диаметром 60 см на обруче со сложнейшим кружевом и перьями.', level: 'Продвинутый', time: '14-16 часов' },
    es: { title: 'Mandala Gigante de Pared en Bastidor', desc: 'Impactante obra de arte textil de 60 cm montada en aro de madera con plumas y flecos colgantes.', level: 'Avanzado', time: '14-16 horas' }
  }
};
`;

const startIdx = html.indexOf('const PATTERN_I18N = {');
const endIdx = html.indexOf('};\n\nfunction renderPatternCategoryChips()');

if (startIdx !== -1 && endIdx !== -1) {
  html = html.substring(0, startIdx) + allPatternsI18n.trim() + html.substring(endIdx + 1);
  console.log('Replaced PATTERN_I18N with complete 23-pattern translations in 7 languages');
} else {
  // Try finding end of PATTERN_I18N
  const altEnd = html.indexOf('};\n\nlet currentPatternLevelFilter');
  if (altEnd !== -1) {
    html = html.substring(0, startIdx) + allPatternsI18n.trim() + html.substring(altEnd + 1);
    console.log('Replaced PATTERN_I18N using altEnd');
  } else {
    console.warn('Could not find end of PATTERN_I18N, checking by brace count');
    let depth = 0;
    let finishPos = -1;
    for (let i = startIdx; i < html.length; i++) {
      if (html[i] === '{') depth++;
      if (html[i] === '}') {
        depth--;
        if (depth === 0) {
          finishPos = i + 1;
          break;
        }
      }
    }
    if (finishPos !== -1) {
      html = html.substring(0, startIdx) + allPatternsI18n.trim() + html.substring(finishPos);
      console.log('Replaced PATTERN_I18N by depth matching');
    }
  }
}

fs.writeFileSync(p, html, 'utf8');
console.log('Saved index.html with all 23 patterns translated');
