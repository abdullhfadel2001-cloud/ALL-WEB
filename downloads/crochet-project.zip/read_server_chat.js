const fs = require('fs');
const code = fs.readFileSync('C:\\crochet_app\\server.js', 'utf8');
const lines = code.split('\n');

console.log('--- Lines 15-35 ---');
console.log(lines.slice(15, 35).join('\n'));

console.log('--- Lines 105-145 ---');
console.log(lines.slice(105, 145).join('\n'));
