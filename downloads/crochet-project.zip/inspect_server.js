const fs = require('fs');
const code = fs.readFileSync('C:\\crochet_app\\server.js', 'utf8');
console.log('Server.js length:', code.length, 'lines:', code.split('\n').length);
console.log(code.substring(0, 1000));

