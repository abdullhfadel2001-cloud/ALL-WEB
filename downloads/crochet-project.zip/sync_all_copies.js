const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const srcHtml = 'C:\\crochet_app\\index.html';
const srcServer = 'C:\\crochet_app\\server.js';

const htmlTargets = [
  'c:\\Users\\dell\\OneDrive\\Desktop\\كروشيه\\index.html',
  'C:\\Users\\dell\\OneDrive\\Desktop\\DAEM\\crochet\\index.html',
  'C:\\Users\\dell\\OneDrive\\Desktop\\Crochet_App.html',
  'C:\\Users\\dell\\OneDrive\\Desktop\\DAEM\\downloads\\Crochet_App.html'
];

console.log('--- Syncing index.html to all destinations ---');
const htmlContent = fs.readFileSync(srcHtml);
htmlTargets.forEach(dest => {
  try {
    fs.writeFileSync(dest, htmlContent);
    console.log(`✅ Synced to: ${dest} (${htmlContent.length} bytes)`);
  } catch (e) {
    console.error(`❌ Failed sync to ${dest}:`, e.message);
  }
});

console.log('--- Syncing server.js to DAEM/crochet ---');
const serverContent = fs.readFileSync(srcServer);
const daemServer = 'C:\\Users\\dell\\OneDrive\\Desktop\\DAEM\\crochet\\server.js';
fs.writeFileSync(daemServer, serverContent);
console.log(`✅ Synced server.js to: ${daemServer} (${serverContent.length} bytes)`);

// Verify that NO crochet_flutter directory exists in DAEM
const daemFlutterDir = 'C:\\Users\\dell\\OneDrive\\Desktop\\DAEM\\crochet_flutter';
if (fs.existsSync(daemFlutterDir)) {
  console.log('⚠️ Removing rogue crochet_flutter in DAEM...');
  fs.rmSync(daemFlutterDir, { recursive: true, force: true });
  console.log('✅ Removed crochet_flutter from DAEM');
} else {
  console.log('✅ DAEM has only ONE clean crochet app directory (crochet/)');
}

// Rebuild zip
const zipDest = 'C:\\Users\\dell\\OneDrive\\Desktop\\DAEM\\downloads\\crochet-project.zip';
try {
  console.log('--- Rebuilding crochet-project.zip ---');
  if (fs.existsSync(zipDest)) fs.unlinkSync(zipDest);
  execSync(`powershell -Command "Compress-Archive -Path 'C:\\crochet_app\\*' -DestinationPath '${zipDest}' -Force"`);
  console.log(`✅ Zip bundle created at: ${zipDest}`);
} catch (e) {
  console.warn('Zip rebuild warning:', e.message);
}

console.log('--- ALL FILES SYNCED CLEANLY ---');
