const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');

console.log('Includes CRLF?', html.includes('\r\n'));
const idx = html.indexOf('AI CHAT ASSISTANT (SAMAR)');
console.log('AI CHAT ASSISTANT index:', idx);
if (idx !== -1) {
  console.log(JSON.stringify(html.substring(idx - 60, idx + 40)));
}
