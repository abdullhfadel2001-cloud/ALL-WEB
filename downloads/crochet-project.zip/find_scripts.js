const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');

const regex = /<script\b[^>]*>/g;
let match;
while ((match = regex.exec(html)) !== null) {
  console.log(`Script tag at index ${match.index}: ${match[0]}`);
}

