const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');
const lines = html.split('\n');

console.log(lines.slice(2840, 2880).join('\n'));
