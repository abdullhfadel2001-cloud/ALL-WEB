const fs = require('fs');

const srcPath = 'c:/Users/dell/OneDrive/Desktop/كروشيه/index.html';
let html = fs.readFileSync(srcPath, 'utf8');

console.log('Original index.html size:', html.length);

// 1. COMPREHENSIVE RESPONSIVE MOBILE CSS ENHANCEMENTS
const mobileEnhancementsCSS = `
    /* ═══════════════════════════════════════════════════════
       RESPONSIVE MOBILE & TABLET MASTER OVERHAUL (iOS & ANDROID)
       ═══════════════════════════════════════════════════════ */
    
    /* iOS Safe Area Support */
    :root {
      --sat: env(safe-area-inset-top, 0px);
      --sab: env(safe-area-inset-bottom, 0px);
      --sal: env(safe-area-inset-left, 0px);
      --sar: env(safe-area-inset-right, 0px);
    }

    /* Fixed Header with iPhone Notch & Dynamic Island Support */
    .compact-header {
      padding-top: calc(8px + var(--sat)) !important;
      padding-left: calc(14px + var(--sal)) !important;
      padding-right: calc(14px + var(--sar)) !important;
      min-height: calc(52px + var(--sat)) !important;
    }

    /* Bottom Bar: Perfect 7-Item Proportional Grid with Zero Overflow on Any Phone */
    .mobile-bottom-bar {
      display: flex !important;
      position: fixed;
      bottom: 0; left: 0; right: 0;
      background: var(--surface-glass) !important;
      backdrop-filter: blur(20px) !important;
      -webkit-backdrop-filter: blur(20px) !important;
      border-top: 1px solid var(--border-purple);
      padding: 4px 2px calc(6px + var(--sab)) !important;
      z-index: 150;
      box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.12);
      justify-content: space-between !important;
      align-items: center;
      overflow: hidden !important;
    }
    .mobile-nav-item {
      flex: 1 1 0 !important;
      min-width: 0 !important;
      max-width: 14.28% !important;
      padding: 4px 1px !important;
      background: transparent;
      border: none;
      cursor: pointer;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 2px;
    }
    .m-icon {
      font-size: 1.15rem !important;
    }
    .m-label {
      font-size: 0.58rem !important;
      font-weight: 700;
      color: var(--text-muted);
      white-space: nowrap;
      text-overflow: ellipsis;
      overflow: hidden;
      max-width: 100%;
      text-align: center;
    }

    @media (max-width: 767px) {
      body {
        padding-bottom: calc(84px + var(--sab)) !important;
      }
    }

    /* CALCULATOR SUBTABS: VERTICAL FULL-WIDTH OPTIONS ON MOBILE */
    .calc-subtabs-nav {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 10px;
      margin-bottom: 20px;
      width: 100%;
      overflow: visible !important;
    }
    .calc-subtab-btn {
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 12px 14px;
      border-radius: var(--radius-md);
      border: 1.5px solid var(--border-purple);
      background: var(--surface);
      color: var(--text);
      font-size: 0.86rem;
      font-weight: 800;
      cursor: pointer;
      white-space: normal !important;
      text-align: center;
      transition: all 0.25s ease;
      box-shadow: var(--shadow-sm);
    }
    .calc-subtab-btn:hover {
      border-color: var(--primary);
      transform: translateY(-1px);
    }
    .calc-subtab-btn.active {
      background: var(--primary-gradient) !important;
      color: #ffffff !important;
      border-color: transparent !important;
      box-shadow: 0 4px 14px var(--primary-glow);
    }

    /* iPad / Tablet (681px - 1023px): Clean 2x2 Grid */
    @media (max-width: 1023px) and (min-width: 681px) {
      .calc-subtabs-nav {
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
      }
    }

    /* Mobile Phones (iPhone & Android <= 680px): Clean Vertical Full-Width Stack (1 Column) */
    @media (max-width: 680px) {
      .calc-subtabs-nav {
        display: flex !important;
        flex-direction: column !important;
        gap: 10px !important;
        width: 100% !important;
        margin-bottom: 18px;
      }
      .calc-subtab-btn {
        width: 100% !important;
        justify-content: flex-start !important;
        padding: 14px 18px !important;
        font-size: 0.9rem !important;
        border-radius: var(--radius-md) !important;
        text-align: right !important;
      }
      .calc-subtab-btn i {
        font-size: 1.1rem;
        width: 24px;
        text-align: center;
      }

      /* Calculator Header on Mobile */
      .calc-header-box {
        flex-direction: column !important;
        align-items: flex-start !important;
        gap: 8px !important;
      }
      .calc-currency-pill {
        align-self: flex-start !important;
      }

      /* Studio Tabs Switcher on Mobile */
      .studio-tabs-row {
        flex-direction: column !important;
        gap: 8px !important;
      }
      .studio-tab-btn {
        width: 100% !important;
        justify-content: center !important;
        padding: 12px 14px !important;
        font-size: 0.88rem !important;
      }

      /* Patterns Top Bar & Action Buttons on Mobile */
      .patterns-top-bar {
        flex-direction: column !important;
        align-items: stretch !important;
        gap: 12px !important;
      }
      .patterns-view-actions {
        display: flex !important;
        flex-direction: column !important;
        width: 100% !important;
        gap: 8px !important;
      }
      .patterns-view-actions .visibility-toggle-btn {
        width: 100% !important;
        justify-content: center !important;
        padding: 10px 14px !important;
        font-size: 0.84rem !important;
      }

      /* Level Filter Bar on Mobile */
      .level-filter-bar {
        width: 100% !important;
        justify-content: flex-start !important;
      }

      /* Stopwatch Card on Mobile */
      .stopwatch-card {
        flex-direction: column !important;
        align-items: center !important;
        text-align: center !important;
      }
      .stopwatch-btns {
        width: 100% !important;
        justify-content: center !important;
        flex-wrap: wrap !important;
      }
      .stopwatch-btns .btn-sw {
        flex: 1 1 auto !important;
        justify-content: center !important;
        padding: 10px 12px !important;
      }

      /* Voice Control Box on Mobile */
      .voice-control-box {
        padding: 14px !important;
      }

      /* Responsive Inputs in Calculator Panels */
      .calc-inputs-2cols {
        grid-template-columns: 1fr !important;
        gap: 10px !important;
      }

      /* Notes Toolbar on Mobile */
      .notes-toolbar {
        flex-direction: column !important;
        align-items: stretch !important;
        gap: 10px !important;
      }
      .btn-create-note {
        width: 100% !important;
        justify-content: center !important;
      }
    }

    /* Smooth touch table scroll container */
    .table-scroll-wrap {
      width: 100%;
      overflow-x: auto;
      -webkit-overflow-scrolling: touch;
      border-radius: var(--radius-sm);
      border: 1px solid var(--border);
      margin: 12px 0 16px;
    }
`;

// Insert the enhancements right before </style>
html = html.replace('</style>', mobileEnhancementsCSS + '\n  </style>');
console.log('✓ Injected comprehensive mobile CSS rules');

// 2. UPDATE CALCULATOR HTML TO USE CLEAN RESPONSIVE CLASSES
// Replace header wrapper
const oldCalcHeader = `<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;margin-bottom:12px;">
          <div>
            <h2 style="font-size:1.15rem;font-weight:900;color:var(--primary);margin-bottom:2px;">
              منصة الحاسبات الذكية والتسعير بالدينار العراقي (د.ع)
            </h2>
            <p style="font-size:0.82rem;color:var(--text-muted);">
              أدوات رياضية وهندسية دقيقة لتقدير الخيوط، عينة القياس، وحساب الأرباح بدقة.
            </p>
          </div>
          <span style="font-size:0.8rem;background:var(--primary-light);color:var(--primary);padding:4px 12px;border-radius:var(--radius-full);font-weight:800;">
            العملة المعتمدة: د.ع (دينار عراقي)
          </span>
        </div>`;

const newCalcHeader = `<div class="calc-header-box" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;margin-bottom:14px;gap:8px;">
          <div>
            <h2 style="font-size:1.15rem;font-weight:900;color:var(--primary);margin-bottom:2px;">
              منصة الحاسبات الذكية والتسعير بالدينار العراقي (د.ع)
            </h2>
            <p style="font-size:0.82rem;color:var(--text-muted);">
              أدوات رياضية وهندسية دقيقة لتقدير الخيوط، عينة القياس، وحساب الأرباح بدقة.
            </p>
          </div>
          <span class="calc-currency-pill" style="font-size:0.8rem;background:var(--primary-light);color:var(--primary);padding:5px 14px;border-radius:var(--radius-full);font-weight:800;display:inline-block;">
            العملة المعتمدة: د.ع (دينار عراقي)
          </span>
        </div>`;

if (html.includes(oldCalcHeader)) {
  html = html.replace(oldCalcHeader, newCalcHeader);
  console.log('✓ Updated Calculator Header Box');
}

// Update subtabs buttons text & icons for vertical clarity
const oldSubtabsNav = `<div class="calc-subtabs-nav">
          <button class="calc-subtab-btn active" onclick="switchCalcSubtab('yarn-est', this)">
            <i class="fa-solid fa-calculator"></i> تقدير كمية الخيوط
          </button>
          <button class="calc-subtab-btn" onclick="switchCalcSubtab('gauge-calc', this)">
            <i class="fa-solid fa-ruler-combined"></i> حاسبة عينة القياس (10×10)
          </button>
          <button class="calc-subtab-btn" onclick="switchCalcSubtab('leftover-calc', this)">
            <i class="fa-solid fa-scale-balanced"></i> حاسبة بقايا الخيوط (غرام/متر)
          </button>
          <button class="calc-subtab-btn" onclick="switchCalcSubtab('pricing-calc', this)">
            <i class="fa-solid fa-receipt"></i> حاسبة التسعير وبطاقة العناية (د.ع)
          </button>
        </div>`;

const newSubtabsNav = `<div class="calc-subtabs-nav">
          <button class="calc-subtab-btn active" onclick="switchCalcSubtab('yarn-est', this)">
            <i class="fa-solid fa-calculator"></i>
            <span>1. تقدير كمية الخيوط ومقاس السنارة</span>
          </button>
          <button class="calc-subtab-btn" onclick="switchCalcSubtab('gauge-calc', this)">
            <i class="fa-solid fa-ruler-combined"></i>
            <span>2. حاسبة عينة القياس (Gauge 10×10 سم)</span>
          </button>
          <button class="calc-subtab-btn" onclick="switchCalcSubtab('leftover-calc', this)">
            <i class="fa-solid fa-scale-balanced"></i>
            <span>3. حاسبة بقايا الخيوط (غرام إلى متر)</span>
          </button>
          <button class="calc-subtab-btn" onclick="switchCalcSubtab('pricing-calc', this)">
            <i class="fa-solid fa-receipt"></i>
            <span>4. حاسبة التسعير الذكي وبطاقة العناية (د.ع)</span>
          </button>
        </div>`;

if (html.includes(oldSubtabsNav)) {
  html = html.replace(oldSubtabsNav, newSubtabsNav);
  console.log('✓ Updated Calculator Subtabs Navigator for vertical phone presentation');
}

// Replace grid in gauge calculator
const oldGaugeGrid = `<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;">`;
const newGaugeGrid = `<div class="calc-inputs-2cols" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;">`;
html = html.replace(oldGaugeGrid, newGaugeGrid);

// Replace grid in leftover calculator
const oldLeftoverGrid = `<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;">`;
const newLeftoverGrid = `<div class="calc-inputs-2cols" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;">`;
html = html.replace(oldLeftoverGrid, newLeftoverGrid);

// Replace grid in pricing calculator
const oldPricingGrid1 = `<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">`;
const newPricingGrid1 = `<div class="calc-inputs-2cols" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">`;
html = html.replace(oldPricingGrid1, newPricingGrid1);

const oldPricingGrid2 = `<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;">`;
const newPricingGrid2 = `<div class="calc-inputs-2cols" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;">`;
html = html.replace(oldPricingGrid2, newPricingGrid2);

// Wrap master tables in .table-scroll-wrap
html = html.replace('<table class="master-table">', '<div class="table-scroll-wrap"><table class="master-table">');
html = html.replace('</table>\n\n        <!-- Standard Symbols Table -->', '</table></div>\n\n        <!-- Standard Symbols Table -->');
html = html.replace('</table>\n\n        <!-- Finishing & Blocking Tips -->', '</table></div>\n\n        <!-- Finishing & Blocking Tips -->');
console.log('✓ Wrapped master tables in responsive touch scroll container');

// Write updated file
fs.writeFileSync(srcPath, html, 'utf8');
console.log('Successfully upgraded mobile responsiveness! New size:', html.length);

