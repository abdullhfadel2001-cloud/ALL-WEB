// Script to inspect header and navigation in index.html
const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');
const lines = html.split('\n');

console.log('--- Key Structure Lines ---');
lines.forEach((l, i) => {
  if (l.includes('<header') || l.includes('</header>') || l.includes('class="desktop-nav"') || l.includes('class="mobile-bottom-nav"')) {
    console.log(`Line ${i + 1}: ${l.trim()}`);
  }
});
