const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');

const idx = html.indexOf("document.addEventListener('DOMContentLoaded'");
console.log(html.substring(idx, idx + 400));

