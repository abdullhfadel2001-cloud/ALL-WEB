const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');
const lines = html.split('\n');

lines.forEach((l, i) => {
  if (l.includes('<nav') || l.includes('</nav>')) {
    console.log(`Line ${i + 1}: ${l.trim()}`);
  }
});

