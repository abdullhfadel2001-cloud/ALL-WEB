const fs = require('fs');
const code = fs.readFileSync('C:\\crochet_app\\server.js', 'utf8');

const idx = code.indexOf('function getSamarInstruction');
console.log(code.substring(idx, idx + 800));
