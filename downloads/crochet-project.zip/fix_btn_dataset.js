const fs = require('fs');

const p = 'C:\\crochet_app\\index.html';
let html = fs.readFileSync(p, 'utf8');

html = html.replace(/const tab = btn\.dataset\.tab;/g, "const tab = btn.dataset?.tab || btn.getAttribute?.('data-tab');");
fs.writeFileSync(p, html, 'utf8');
console.log('Made all tab dataset reads ultra-safe');
