const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');

const idx = html.indexOf('function renderPatternsToGrid');
console.log(html.substring(idx, idx + 1800));
