const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');

console.log('crochet_app/index.html size:', html.length, 'lines:', html.split('\n').length);
console.log('Includes langDropdownContainer?', html.includes('id="langDropdownContainer"'));
console.log('Includes I18N_DICT?', html.includes('const I18N_DICT ='));
console.log('Includes setAppLanguage?', html.includes('function setAppLanguage'));
