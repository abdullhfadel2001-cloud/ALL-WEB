const fs = require('fs');

const p = 'C:\\crochet_app\\index.html';
let html = fs.readFileSync(p, 'utf8');

const missingFuncs = `
function toggleLangMenu(e) {
  if (e) e.stopPropagation();
  const menu = document.getElementById('langMenu');
  if (menu) menu.classList.toggle('show');
}

// Close menu on outside click
document.addEventListener('click', (e) => {
  const container = document.getElementById('langDropdownContainer');
  const menu = document.getElementById('langMenu');
  if (menu && container && !container.contains(e.target)) {
    menu.classList.remove('show');
  }
});

function setAppLanguage(lang) {
  if (!I18N_DICT[lang]) lang = 'ar';
  currentAppLang = lang;
  localStorage.setItem('crochet_app_lang', lang);

  const dict = I18N_DICT[lang];

  // Document attributes
  document.documentElement.lang = lang;
  document.documentElement.dir = dict.dir;

  // Header display label
  const display = document.getElementById('currentLangDisplay');
  if (display) display.textContent = dict.label;

  // Active state in dropdown
  document.querySelectorAll('.lang-opt').forEach(opt => {
    opt.classList.toggle('active', opt.dataset.lang === lang);
  });

  // Close dropdown menu
  const menu = document.getElementById('langMenu');
  if (menu) menu.classList.remove('show');

  // Apply all UI translations across entire page
  applyTranslations(lang);

  // Restart voice recognition with new language if active
  if (isVoiceListeningActive) {
    stopVoiceCounter();
    setTimeout(() => { toggleVoiceCounter(); }, 300);
  }
}
`;

if (!html.includes('function toggleLangMenu')) {
  html = html.replace('const PATTERN_I18N = {', `${missingFuncs}\nconst PATTERN_I18N = {`);
  console.log('Restored toggleLangMenu and setAppLanguage');
}

fs.writeFileSync(p, html, 'utf8');
