const fs = require('fs');

const p = 'C:\\crochet_app\\index.html';
let html = fs.readFileSync(p, 'utf8');

html = html.replace("opt.dataset.lang === lang", "(opt.dataset?.lang || opt.getAttribute?.('data-lang')) === lang");
fs.writeFileSync(p, html, 'utf8');
console.log('Made setAppLanguage dataset check ultra-safe');
