const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');

console.log('Includes patterns.js src?', html.includes('src="patterns.js"'));
console.log('STITCH_PATTERNS defined?', html.includes('const STITCH_PATTERNS ='));
console.log('STITCH_GLOSSARY defined?', html.includes('const STITCH_GLOSSARY ='));

