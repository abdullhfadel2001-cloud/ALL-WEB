const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');

const matches = html.match(/const [A-Z_0-9]+ =/g);
console.log('Constants defined:', matches ? matches.slice(0, 20) : 'none');

