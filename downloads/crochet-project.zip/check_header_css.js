const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');

const lines = html.split('\n');
console.log('--- Lines around header CSS ---');
lines.forEach((l, i) => {
  if (l.includes('.compact-header') || l.includes('.header-controls') || l.includes('.h-btn') || l.includes('lang-btn')) {
    if (i < 800) console.log(`${i+1}: ${l}`);
  }
});

console.log('--- Mobile media queries ---');
lines.forEach((l, i) => {
  if (l.includes('@media') && (l.includes('680') || l.includes('768') || l.includes('480'))) {
    console.log(`${i+1}: ${l}`);
  }
});

