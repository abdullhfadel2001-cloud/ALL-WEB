const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');

const idx = html.indexOf('function setAppLanguage');
console.log('setAppLanguage index:', idx);
console.log(html.substring(idx - 100, idx + 300));
