const fs = require('fs');

const p = 'C:\\crochet_app\\index.html';
let html = fs.readFileSync(p, 'utf8');

// 1. ADD GERMAN TO VOICE_COMMANDS_CONFIG
const oldVoiceCfg = `  es: {
    langCode: 'es-ES',
    plus: ['siguiente', 'más', 'aumentar', 'adelante', 'sumar', 'uno', 'fila'],
    minus: ['atrás', 'menos', 'disminuir', 'anterior', 'restar'],
    reset: ['reiniciar', 'cero', 'borrar', 'limpiar'],
    prompt: 'Escuchando... di: "Siguiente" o "Atrás"',
    heardAdd: '🗣️ Reconocido: "<b>Siguiente</b>" (+1 Fila)',
    heardSub: '🗣️ Reconocido: "<b>Atrás</b>" (−1 Fila)',
    heardReset: '🗣️ Reconocido: "<b>Reiniciar</b>" (Contador a cero)'
  }`;

const newVoiceCfg = `  de: {
    langCode: 'de-DE',
    plus: ['weiter', 'plus', 'reihe', 'hinzufügen', 'eins', 'vor', 'schritt'],
    minus: ['zurück', 'minus', 'abnehmen', 'weniger'],
    reset: ['zurücksetzen', 'löschen', 'null', 'neustart'],
    prompt: 'Zuhören... sagen Sie: "Weiter" oder "Zurück"',
    heardAdd: '🗣️ Erkannt: "<b>Weiter</b>" (+1 Reihe)',
    heardSub: '🗣️ Erkannt: "<b>Zurück</b>" (−1 Reihe)',
    heardReset: '🗣️ Erkannt: "<b>Zurückgesetzt</b>" (Zähler auf 0)'
  },
${oldVoiceCfg}`;

if (html.includes(oldVoiceCfg) && !html.includes('langCode: \'de-DE\'')) {
  html = html.replace(oldVoiceCfg, newVoiceCfg);
  console.log('Added German to VOICE_COMMANDS_CONFIG');
}

// 2. UPDATE renderPatternsToGrid TO FULLY LOCALIZE CARDS
const oldRenderToGrid = `function renderPatternsToGrid(items) {
  const grid = document.getElementById('patternsGridList');
  if (!grid) return;

  grid.innerHTML = items.map(p => {
    const savedSteps = JSON.parse(localStorage.getItem(LOCAL_STORAGE.PATTERN_STEP_PREFIX + p.id) || '[]');
    const doneCount = savedSteps.filter(Boolean).length;
    const totalSteps = p.steps.length;
    const pct = totalSteps ? Math.round((doneCount / totalSteps) * 100) : 0;
    const coverArt = PATTERN_COVERS[p.id] || PATTERN_COVERS['ami-bear'];

    return \`
      <div class="pattern-card-item" onclick="openPatternReaderModal('\${p.id}')">
        <div class="pattern-svg-cover">
          \${coverArt}
        </div>
        <div class="pattern-card-body">
          <div>
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
              <h3 style="margin-bottom:0;">\${p.title}</h3>
              <span class="pattern-level-tag \${p.levelTagClass || 'tag-beginner'}">\${p.levelLabel || (p.level === 'intermediate' ? 'متوسط' : p.level === 'advanced' ? 'محترف' : 'مبتدئ')}</span>
            </div>
            <p>\${p.description}</p>
            <div class="pattern-specs-chips">
              <span class="spec-chip">🪡 \${p.hook}</span>
              <span class="spec-chip">🧶 \${p.yarnBalls} شلة</span>
              <span class="spec-chip">⏱️ \${p.time}</span>
              <span class="spec-chip">📋 \${totalSteps} خطوة</span>
            </div>
          </div>
          <div>
            <div class="prog-track">
              <div class="prog-fill" style="width:\${pct}%"></div>
            </div>
            <div class="prog-labels">
              <span>الإنجاز</span>
              <span>\${doneCount}/\${totalSteps} (\${pct}%)</span>
            </div>
          </div>
        </div>
      </div>
    \`;
  }).join('');
}`;

const newRenderToGrid = `function renderPatternsToGrid(items) {
  const grid = document.getElementById('patternsGridList');
  if (!grid) return;
  const lang = currentAppLang || 'ar';
  const t = I18N_DICT[lang] || I18N_DICT.ar;

  grid.innerHTML = items.map(p => {
    const savedSteps = JSON.parse(localStorage.getItem(LOCAL_STORAGE.PATTERN_STEP_PREFIX + p.id) || '[]');
    const doneCount = savedSteps.filter(Boolean).length;
    const totalSteps = p.steps.length;
    const pct = totalSteps ? Math.round((doneCount / totalSteps) * 100) : 0;
    const coverArt = PATTERN_COVERS[p.id] || PATTERN_COVERS['ami-bear'];

    // Get localized pattern texts
    const trans = (PATTERN_I18N[p.id] && PATTERN_I18N[p.id][lang]) ? PATTERN_I18N[p.id][lang] : null;
    const title = trans ? trans.title : p.title;
    const desc = trans ? trans.desc : p.description;
    const time = trans ? trans.time : p.time;
    const levelLabel = trans ? trans.level : (p.levelLabel || (p.level === 'intermediate' ? t.patterns.levels.int : p.level === 'advanced' ? t.patterns.levels.adv : t.patterns.levels.beg));

    return \`
      <div class="pattern-card-item" onclick="openPatternReaderModal('\${p.id}')">
        <div class="pattern-svg-cover">
          \${coverArt}
        </div>
        <div class="pattern-card-body">
          <div>
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
              <h3 style="margin-bottom:0;">\${title}</h3>
              <span class="pattern-level-tag \${p.levelTagClass || 'tag-beginner'}">\${levelLabel}</span>
            </div>
            <p>\${desc}</p>
            <div class="pattern-specs-chips">
              <span class="spec-chip">🪡 \${p.hook}</span>
              <span class="spec-chip">🧶 \${p.yarnBalls} \${t.patterns.balls}</span>
              <span class="spec-chip">⏱️ \${time}</span>
              <span class="spec-chip">📋 \${totalSteps} \${t.patterns.steps}</span>
            </div>
          </div>
          <div>
            <div class="prog-track">
              <div class="prog-fill" style="width:\${pct}%"></div>
            </div>
            <div class="prog-labels">
              <span>\${t.patterns.progress}</span>
              <span>\${doneCount}/\${totalSteps} (\${pct}%)</span>
            </div>
          </div>
        </div>
      </div>
    \`;
  }).join('');
}`;
html = html.replace(oldRenderToGrid, newRenderToGrid);
console.log('Patched renderPatternsToGrid with full multi-language support');

// 3. UPDATE renderGlossaryCatalog TO FULLY LOCALIZE CARDS
const oldRenderGlossary = `function renderGlossaryCatalog(items = GLOSSARY) {
  const container = document.getElementById('glossaryGridWrap');
  if (!items.length) {
    container.innerHTML = \`<div style="text-align:center;padding:30px;color:var(--text-muted);grid-column:1/-1;">لا توجد مصطلحات مطابقة للبحث</div>\`;
    return;
  }

  container.innerHTML = items.map(g => \`
    <div class="glossary-term-card">
      <div>
        <div class="gtc-header">
          <div>
            <div class="gtc-name-ar">\${g.ar}</div>
            <div class="gtc-name-us">🇺🇸 \${g.us}</div>
          </div>
          <span class="gtc-code">\${g.code}</span>
        </div>
        <p class="gtc-desc">\${g.desc}</p>
      </div>

      <!-- Pure Crochet Visuals (Diagram + Real Texture) -->
      <div class="gtc-visual-pair">
        <div class="gtc-vis-col">
          <div class="gtc-vis-tag">📐 حركة السنارة (رسم)</div>
          <div class="gtc-vis-body">
            \${g.svg}
          </div>
        </div>
        <div class="gtc-vis-col">
          <div class="gtc-vis-tag">🧶 نسيج الخيط الحقيقي</div>
          <div class="gtc-vis-body">
            \${g.realTexture}
          </div>
        </div>
      </div>
    </div>
  \`).join('');
}`;

const newRenderGlossary = `function renderGlossaryCatalog(items = GLOSSARY) {
  const container = document.getElementById('glossaryGridWrap');
  if (!container) return;
  const lang = currentAppLang || 'ar';
  const t = I18N_DICT[lang] || I18N_DICT.ar;

  if (!items.length) {
    container.innerHTML = \`<div style="text-align:center;padding:30px;color:var(--text-muted);grid-column:1/-1;">\${t.glossary.emptySearch}</div>\`;
    return;
  }

  container.innerHTML = items.map(g => {
    const trans = (GLOSSARY_I18N[g.code] && GLOSSARY_I18N[g.code][lang]) ? GLOSSARY_I18N[g.code][lang] : null;
    const primaryName = trans ? trans.name : g.ar;
    const desc = trans ? trans.desc : g.desc;

    return \`
      <div class="glossary-term-card">
        <div>
          <div class="gtc-header">
            <div>
              <div class="gtc-name-ar">\${primaryName}</div>
              <div class="gtc-name-us">🇺🇸 \${g.us}</div>
            </div>
            <span class="gtc-code">\${g.code}</span>
          </div>
          <p class="gtc-desc">\${desc}</p>
        </div>

        <!-- Pure Crochet Visuals (Diagram + Real Texture) -->
        <div class="gtc-visual-pair">
          <div class="gtc-vis-col">
            <div class="gtc-vis-tag">\${t.glossary.tagDiagram}</div>
            <div class="gtc-vis-body">
              \${g.svg}
            </div>
          </div>
          <div class="gtc-vis-col">
            <div class="gtc-vis-tag">\${t.glossary.tagTexture}</div>
            <div class="gtc-vis-body">
              \${g.realTexture}
            </div>
          </div>
        </div>
      </div>
    \`;
  }).join('');
}`;
html = html.replace(oldRenderGlossary, newRenderGlossary);
console.log('Patched renderGlossaryCatalog with full multi-language support');

// 4. UPDATE renderNotesMasonry EMPTY STATE TO BE LOCALIZED
const oldNotesEmpty = `<p style="font-size:0.95rem;font-weight:700;">لا توجد ملاحظات مسجلة بعد</p>
        <p style="font-size:0.8rem;margin-top:4px;">اضغطي على "+ ملاحظة جديدة" لتدوين خيوطك ومشاريعك وقوائم مهامك</p>`;

const newNotesEmpty = `<p style="font-size:0.95rem;font-weight:700;">\${(I18N_DICT[currentAppLang]||I18N_DICT.ar).notes.emptyTitle}</p>
        <p style="font-size:0.8rem;margin-top:4px;">\${(I18N_DICT[currentAppLang]||I18N_DICT.ar).notes.emptyDesc}</p>`;
html = html.replace(oldNotesEmpty, newNotesEmpty);
console.log('Patched renderNotesMasonry empty state');

// 5. UPDATE applyTranslations FUNCTION TO TRANSLATE ALL DOM ELEMENTS COMPLETELY
const oldApplyTransIdx = html.indexOf('function applyTranslations(lang) {');
const oldApplyTransEnd = html.indexOf('}\n', oldApplyTransIdx);

const newApplyTranslations = `function applyTranslations(lang) {
  const t = I18N_DICT[lang] || I18N_DICT.ar;

  // Header
  const bTitle = document.getElementById('brandTitle');
  const bSub = document.getElementById('brandSubtitle');
  const sWl = document.getElementById('screenWlLabel');
  const wlAlert = document.getElementById('wlAlertBannerText');
  if (bTitle) bTitle.textContent = t.brandTitle;
  if (bSub) bSub.textContent = t.brandSubtitle;
  if (sWl) sWl.textContent = t.screenWl;
  if (wlAlert) wlAlert.textContent = t.wlBanner;

  // Desktop Navigation
  document.querySelectorAll('.desktop-nav .nav-btn').forEach(btn => {
    const tab = btn.dataset.tab;
    const span = btn.querySelector('span');
    if (span && t.nav[tab]) span.textContent = t.nav[tab];
  });

  // Mobile Bottom Bar Navigation
  document.querySelectorAll('.mobile-bottom-bar .mobile-nav-item').forEach(btn => {
    const tab = btn.dataset.tab;
    const label = btn.querySelector('.m-label');
    const shortKey = tab + 'Short';
    if (label && t.nav[shortKey]) label.textContent = t.nav[shortKey];
    else if (label && t.nav[tab]) label.textContent = t.nav[tab];
  });

  // AI Chat Section (SAMAR)
  const chatMetaH3 = document.querySelector('.ai-meta h3');
  const chatStatus = document.querySelector('.ai-status-indicator');
  const chatInput = document.getElementById('aiChatInput');
  const chatClearSpan = document.querySelector('.btn-clear-chat span');
  const chatThinking = document.querySelector('.ai-thinking-box span');

  if (chatMetaH3) chatMetaH3.textContent = t.chat.title;
  if (chatStatus) chatStatus.textContent = t.chat.status;
  if (chatInput) chatInput.placeholder = t.chat.placeholder;
  if (chatClearSpan) chatClearSpan.textContent = t.chat.clear;
  if (chatThinking) chatThinking.textContent = t.chat.thinking;

  // Update quick suggestion chips
  const chips = document.querySelectorAll('.suggestion-chip');
  if (chips && chips.length >= 4) {
    if (chips[0]) chips[0].textContent = t.chat.chips.curling;
    if (chips[1]) chips[1].textContent = t.chat.chips.ring;
    if (chips[2]) chips[2].textContent = t.chat.chips.blanket;
    if (chips[3]) chips[3].textContent = t.chat.chips.compare;
  }

  // Update initial bot welcome bubble
  const stream = document.getElementById('aiChatStream');
  if (stream) {
    const firstBotBubble = stream.querySelector('.chat-bubble.bot');
    if (firstBotBubble && stream.querySelectorAll('.chat-bubble').length <= 1) {
      firstBotBubble.innerHTML = (window.marked && marked.parse) ? marked.parse(t.chat.welcome) : t.chat.welcome.replace(/\\n/g, '<br>');
    }
  }

  // Patterns Section Header & Filters
  const patSearch = document.getElementById('patternSearchInput');
  if (patSearch) patSearch.placeholder = t.patterns.searchPh;

  document.querySelectorAll('.level-chip').forEach(btn => {
    const txt = btn.textContent;
    if (txt.includes('مبتدئ') || txt.includes('Beginner') || txt.includes('Anfänger') || txt.includes('初級') || txt.includes('Başlangıç') || txt.includes('Начинающий') || txt.includes('Principiante')) {
      btn.textContent = t.patterns.levels.beg;
    } else if (txt.includes('متوسط') || txt.includes('Intermediate') || txt.includes('Mittel') || txt.includes('中級') || txt.includes('Orta') || txt.includes('Средний') || txt.includes('Intermedio')) {
      btn.textContent = t.patterns.levels.int;
    } else if (txt.includes('محترف') || txt.includes('Advanced') || txt.includes('Fortgeschritten') || txt.includes('上級') || txt.includes('İleri') || txt.includes('Продвинутый') || txt.includes('Avanzado')) {
      btn.textContent = t.patterns.levels.adv;
    } else {
      btn.textContent = t.patterns.levels.all;
    }
  });

  // Re-render Pattern Categories & Patterns Cards
  renderPatternCategoryChips();
  renderPatternsCatalogFiltered();

  // Counter Section
  const vTitle = document.querySelector('.voice-title span');
  const vPrompt = document.querySelector('.voice-info div:nth-child(2)');
  const vBadge = document.getElementById('voiceStatusBadge');
  const mchTag = document.querySelector('.mch-tag');
  const mchLabel = document.querySelector('.mch-label');
  const swTitle = document.querySelector('.stopwatch-card div:first-child div:first-child');
  const swStartBtn = document.getElementById('swStartBtn');
  const swResetBtn = document.getElementById('swResetBtn');

  if (vTitle) vTitle.textContent = t.counter.voiceTitle;
  if (vPrompt) vPrompt.innerHTML = t.counter.voicePrompt;
  if (vBadge && !isVoiceListeningActive) vBadge.innerHTML = '<i class="fa-solid fa-circle" style="font-size:0.5rem;color:#10b981;"></i> ' + t.counter.voiceReady;
  if (mchTag) mchTag.textContent = t.counter.mchTag;
  if (mchLabel) mchLabel.textContent = t.counter.mchLabel;
  if (swTitle) swTitle.innerHTML = '<i class="fa-solid fa-stopwatch" style="color:var(--primary);"></i> ' + t.counter.stopwatchTitle;
  if (swStartBtn) swStartBtn.textContent = isStopwatchRunning ? t.counter.btnPauseSession : t.counter.btnStartSession;

  // Calculators Section
  const calcH2 = document.querySelector('.calc-header-box h2');
  const calcP = document.querySelector('.calc-header-box p');
  const calcCurr = document.querySelector('.calc-currency-pill');
  if (calcH2) calcH2.textContent = t.calc.title;
  if (calcP) calcP.textContent = t.calc.subtitle;
  if (calcCurr) calcCurr.textContent = t.calc.currency;

  const subBtns = document.querySelectorAll('.calc-subtab-btn span');
  if (subBtns.length >= 4) {
    subBtns[0].textContent = t.calc.tabs.est;
    subBtns[1].textContent = t.calc.tabs.gauge;
    subBtns[2].textContent = t.calc.tabs.rem;
    subBtns[3].textContent = t.calc.tabs.pricing;
  }

  // Studio Section
  const stH2 = document.querySelector('.studio-hero-card h2');
  const stP = document.querySelector('.studio-hero-card p');
  if (stH2) stH2.innerHTML = '<i class="fa-solid fa-palette"></i> ' + t.studio.title;
  if (stP) stP.textContent = t.studio.subtitle;

  const btnStarry = document.getElementById('btnStudioStarry');
  const btnCustom = document.getElementById('btnStudioCustom');
  if (btnStarry) btnStarry.innerHTML = '<i class="fa-solid fa-star"></i> ' + t.studio.tabStarry;
  if (btnCustom) btnCustom.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles"></i> ' + t.studio.tabCustom;

  const studioPdfBtn = document.querySelector('button[onclick="printStudioPatternPDF()"]');
  const studioNotesBtn = document.querySelector('button[onclick="saveStudioToNotes()"]');
  if (studioPdfBtn) studioPdfBtn.innerHTML = '<i class="fa-solid fa-file-pdf"></i> ' + t.studio.btnPdf;
  if (studioNotesBtn) studioNotesBtn.innerHTML = '<i class="fa-solid fa-bookmark"></i> ' + t.studio.btnNotes;

  // Studio Specs Box Labels
  const specsH3 = document.querySelector('#studioStarryView h3');
  const specsChip = document.querySelector('#studioStarryView .spec-chip');
  if (specsH3) specsH3.textContent = t.studio.specsHeader;
  if (specsChip) specsChip.textContent = t.studio.specsCost;

  // Glossary Section
  const glSearch = document.getElementById('glossarySearchInput');
  const glMasterBtn = document.querySelector('.master-size-btn');
  if (glSearch) glSearch.placeholder = t.glossary.searchPh;
  if (glMasterBtn) glMasterBtn.innerHTML = '<i class="fa-solid fa-ruler-combined"></i> ' + t.glossary.masterGuideBtn;
  renderGlossaryCatalog();

  // Notes Section
  const noteBtnSpan = document.querySelector('.btn-create-note span');
  const noteSearchField = document.getElementById('notesSearchField');
  if (noteBtnSpan) noteBtnSpan.textContent = t.notes.btnAdd;
  if (noteSearchField) noteSearchField.placeholder = t.notes.searchPh;
  renderNotesMasonry();
}`;

if (oldApplyTransIdx !== -1) {
  // Find matching closing brace
  let depth = 0;
  let endPos = -1;
  for (let i = oldApplyTransIdx; i < html.length; i++) {
    if (html[i] === '{') depth++;
    if (html[i] === '}') {
      depth--;
      if (depth === 0) {
        endPos = i + 1;
        break;
      }
    }
  }
  if (endPos !== -1) {
    html = html.substring(0, oldApplyTransIdx) + newApplyTranslations + html.substring(endPos);
    console.log('Replaced applyTranslations with complete multi-language DOM updater');
  }
}

fs.writeFileSync(p, html, 'utf8');
console.log('Successfully patched all renderers and applied complete i18n');
