const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');
const lines = html.split('\n');

lines.forEach((l, i) => {
  if (l.includes('class="mobile-bottom-nav"') || l.includes('id="mobileBottomNav"') || l.includes('switchNavTab')) {
    if (i > 3000) console.log(`Line ${i + 1}: ${l.trim().substring(0, 80)}`);
  }
});

