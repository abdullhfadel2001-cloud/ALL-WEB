const fs = require('fs');

const p = 'C:\\Users\\dell\\OneDrive\\Desktop\\DAEM\\script.js';
let js = fs.readFileSync(p, 'utf8');

js = js.replace(/demoUrl:\s*'crochet\/index\.html[^']*'/, "demoUrl: 'crochet/index.html?v=4.0'");
fs.writeFileSync(p, js, 'utf8');
console.log('Updated DAEM script.js demoUrl with cache buster v=4.0');

