const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');

console.log('File length:', html.length);

// Check PATTERNS array
const pMatch = html.match(/const PATTERNS\s*=\s*\[([\s\S]*?)\];/);
if (pMatch) {
  const pCode = pMatch[0];
  console.log('PATTERNS code found, length:', pCode.length);
}

// Check GLOSSARY array
const gMatch = html.match(/const GLOSSARY\s*=\s*\[([\s\S]*?)\];/);
if (gMatch) {
  const gCode = gMatch[0];
  console.log('GLOSSARY code found, length:', gCode.length);
}

// Check renderPatternsCatalog
const idxRpc = html.indexOf('function renderPatternsCatalog');
console.log('renderPatternsCatalog snippet:');
console.log(html.substring(idxRpc, idxRpc + 1200));
