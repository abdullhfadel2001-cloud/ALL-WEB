const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');

const regex = /id:\s*['"]([a-zA-Z0-9_-]+)['"],\s*title:\s*['"]([^'"]+)['"]/g;
let m;
const patterns = [];
while ((m = regex.exec(html)) !== null) {
  patterns.push({ id: m[1], title: m[2] });
}
console.log(`Found ${patterns.length} patterns:`);
patterns.forEach(p => console.log(`- ${p.id}: ${p.title}`));
