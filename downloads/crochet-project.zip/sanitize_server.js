const fs = require('fs');

const p1 = 'C:\\crochet_app\\server.js';
const p2 = 'C:\\Users\\dell\\OneDrive\\Desktop\\DAEM\\crochet\\server.js';

[p1, p2].forEach(p => {
  let s = fs.readFileSync(p, 'utf8');
  s = s.replace(/const GEMINI_API_KEY = process\.env\.GEMINI_API_KEY \|\| "[^"]+";/, 'const GEMINI_API_KEY = process.env.GEMINI_API_KEY || "";');
  fs.writeFileSync(p, s, 'utf8');
  console.log('Sanitized:', p);
});

