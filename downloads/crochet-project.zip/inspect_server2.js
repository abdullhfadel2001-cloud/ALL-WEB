const fs = require('fs');
const code = fs.readFileSync('C:\\crochet_app\\server.js', 'utf8');
const lines = code.split('\n');
console.log(lines.slice(40, 180).join('\n'));
