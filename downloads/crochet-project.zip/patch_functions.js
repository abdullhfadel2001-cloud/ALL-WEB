const fs = require('fs');

const indexPath = 'C:\\crochet_app\\index.html';
let html = fs.readFileSync(indexPath, 'utf8');

// 1. Update DOMContentLoaded to initialize i18n
const oldDom = "document.addEventListener('DOMContentLoaded', () => {";
const newDom = `document.addEventListener('DOMContentLoaded', () => {
  setAppLanguage(currentAppLang);`;
html = html.replace(oldDom, newDom);
console.log('Patched DOMContentLoaded');

// 2. Update renderPatternCategoryChips to use translated labels
const oldRenderChips = `function renderPatternCategoryChips() {
  const bar = document.getElementById('patternCategoriesBar');
  bar.innerHTML = CATEGORIES.map((cat, i) => \`
    <button class="cat-chip \${i === 0 ? 'active' : ''}" onclick="filterPatternsByCategory('\${cat.id}', this)">
      <span>\${cat.emoji}</span>
      <span>\${cat.label}</span>
    </button>
  \`).join('');
}`;

const newRenderChips = `function renderPatternCategoryChips() {
  const bar = document.getElementById('patternCategoriesBar');
  if (!bar) return;
  const t = I18N_DICT[currentAppLang] || I18N_DICT.ar;
  bar.innerHTML = CATEGORIES.map((cat, i) => {
    let label = cat.label;
    if (cat.id === 'all' && t.patterns.cats.all) label = t.patterns.cats.all;
    if (cat.id === 'amigurumi' && t.patterns.cats.ami) label = t.patterns.cats.ami;
    if (cat.id === 'shawl' && t.patterns.cats.shawls) label = t.patterns.cats.shawls;
    if (cat.id === 'home' && t.patterns.cats.home) label = t.patterns.cats.home;
    if (cat.id === 'bag' && t.patterns.cats.bags) label = t.patterns.cats.bags;
    return \`
      <button class="cat-chip \${i === 0 ? 'active' : ''}" onclick="filterPatternsByCategory('\${cat.id}', this)">
        <span>\${cat.emoji}</span>
        <span>\${label}</span>
      </button>
    \`;
  }).join('');
}`;
html = html.replace(oldRenderChips, newRenderChips);
console.log('Patched renderPatternCategoryChips');

// 3. Update startVoiceCounter
const oldStartVoice = `function startVoiceCounter(SpeechRec) {
  try {
    voiceRecognitionInstance = new SpeechRec();
    voiceRecognitionInstance.lang = 'ar-IQ'; // Arabic Iraqi / Gulf dialect
    voiceRecognitionInstance.continuous = true;
    voiceRecognitionInstance.interimResults = false;

    voiceRecognitionInstance.onstart = () => {
      isVoiceListeningActive = true;
      const btn = document.getElementById('voiceMicBtn');
      const badge = document.getElementById('voiceStatusBadge');
      if (btn) btn.classList.add('listening');
      if (badge) badge.innerHTML = '<i class="fa-solid fa-circle" style="font-size:0.5rem;color:#ef4444;animation:pulseMic 1s infinite;"></i> جاري الاستماع لأوامركِ... قولي: "زيد" أو "نقص"';
    };`;

const newStartVoice = `function startVoiceCounter(SpeechRec) {
  try {
    const vCfg = VOICE_COMMANDS_CONFIG[currentAppLang] || VOICE_COMMANDS_CONFIG.ar;
    const t = I18N_DICT[currentAppLang] || I18N_DICT.ar;
    voiceRecognitionInstance = new SpeechRec();
    voiceRecognitionInstance.lang = vCfg.langCode;
    voiceRecognitionInstance.continuous = true;
    voiceRecognitionInstance.interimResults = false;

    voiceRecognitionInstance.onstart = () => {
      isVoiceListeningActive = true;
      const btn = document.getElementById('voiceMicBtn');
      const badge = document.getElementById('voiceStatusBadge');
      if (btn) {
        btn.classList.add('listening');
        btn.innerHTML = '<i class="fa-solid fa-microphone-lines"></i> <span>' + t.counter.btnVoiceStop + '</span>';
      }
      if (badge) badge.innerHTML = '<i class="fa-solid fa-circle" style="font-size:0.5rem;color:#ef4444;animation:pulseMic 1s infinite;"></i> ' + vCfg.prompt;
    };`;
html = html.replace(oldStartVoice, newStartVoice);
console.log('Patched startVoiceCounter');

// 4. Update stopVoiceCounter to restore localized button text
const oldStopVoice = `function stopVoiceCounter() {
  isVoiceListeningActive = false;
  if (voiceRecognitionInstance) {
    try { voiceRecognitionInstance.stop(); } catch(e) {}
  }
  const btn = document.getElementById('voiceMicBtn');
  const badge = document.getElementById('voiceStatusBadge');
  if (btn) {
    btn.classList.remove('listening');
    btn.innerHTML = '<i class="fa-solid fa-microphone"></i> <span>تشغيل التحكم الصوتي 🎙️</span>';
  }
  if (badge) badge.innerHTML = '<i class="fa-solid fa-circle-check" style="font-size:0.5rem;color:var(--text-muted);"></i> انقر لتشغيل الميكروفون والعد بدون لمس الشاشة';
}`;

const newStopVoice = `function stopVoiceCounter() {
  isVoiceListeningActive = false;
  if (voiceRecognitionInstance) {
    try { voiceRecognitionInstance.stop(); } catch(e) {}
  }
  const btn = document.getElementById('voiceMicBtn');
  const badge = document.getElementById('voiceStatusBadge');
  const t = I18N_DICT[currentAppLang] || I18N_DICT.ar;
  if (btn) {
    btn.classList.remove('listening');
    btn.innerHTML = '<i class="fa-solid fa-microphone"></i> <span>' + t.counter.btnVoiceStart + '</span>';
  }
  if (badge) badge.innerHTML = '<i class="fa-solid fa-circle-check" style="font-size:0.5rem;color:var(--text-muted);"></i> ' + t.counter.btnVoiceStart;
}`;
html = html.replace(oldStopVoice, newStopVoice);
console.log('Patched stopVoiceCounter');

// 5. Update handleVoiceCommand to support all 6 languages
const oldHandleVoice = `function handleVoiceCommand(cmd) {
  const badge = document.getElementById('voiceStatusBadge');
  if (cmd.includes('زيد') || cmd.includes('زود') || cmd.includes('التالي') || cmd.includes('فوق') || cmd.includes('واحد') || cmd.includes('plus') || cmd.includes('next')) {
    stepMegaCounter(1);
    if (badge) badge.innerHTML = '🗣️ سُمع: "<b>زيد</b>" (+1 سطر)';
  } else if (cmd.includes('نقص') || cmd.includes('ارجع') || cmd.includes('السابق') || cmd.includes('تحت') || cmd.includes('minus') || cmd.includes('back')) {
    stepMegaCounter(-1);
    if (badge) badge.innerHTML = '🗣️ سُمع: "<b>نقص</b>" (−1 سطر)';
  } else if (cmd.includes('صفر') || cmd.includes('تصفير') || cmd.includes('مسح') || cmd.includes('reset') || cmd.includes('clear')) {
    resetMegaCounter();
    if (badge) badge.innerHTML = '🗣️ سُمع: "<b>تصفير</b>" (تمت إعادة الضبط)';
  } else {
    if (badge) badge.innerHTML = '🗣️ سُمع: "' + cmd + '" (جربي قول: زيد / نقص)';
  }
}`;

const newHandleVoice = `function handleVoiceCommand(cmd) {
  const badge = document.getElementById('voiceStatusBadge');
  const vCfg = VOICE_COMMANDS_CONFIG[currentAppLang] || VOICE_COMMANDS_CONFIG.ar;
  
  const isPlus = vCfg.plus.some(w => cmd.includes(w));
  const isMinus = vCfg.minus.some(w => cmd.includes(w));
  const isReset = vCfg.reset.some(w => cmd.includes(w));

  if (isPlus) {
    stepMegaCounter(1);
    if (badge) badge.innerHTML = vCfg.heardAdd;
  } else if (isMinus) {
    stepMegaCounter(-1);
    if (badge) badge.innerHTML = vCfg.heardSub;
  } else if (isReset) {
    resetMegaCounter();
    if (badge) badge.innerHTML = vCfg.heardReset;
  } else {
    if (badge) badge.innerHTML = '🗣️ "' + cmd + '"';
  }
}`;
html = html.replace(oldHandleVoice, newHandleVoice);
console.log('Patched handleVoiceCommand');

// 6. Update sendChatMessage to pass lang
const oldSendChat = `body: JSON.stringify({ message: prompt })`;
const newSendChat = `body: JSON.stringify({ message: prompt, lang: currentAppLang })`;
html = html.replace(oldSendChat, newSendChat);
console.log('Patched sendChatMessage payload');

// 7. Update getLocalKnowledgeResponse with multi-language smart answers
const oldLocalKnowledge = `function getLocalKnowledgeResponse(q) {
  const qClean = q.toLowerCase();
  if (qClean.includes('اسم') || qClean.includes('من انت') || qClean.includes('عرفين')) {
    return \`أنا **SAMAR**، خبيرتكِ ومساعدتكِ الشخصية في فنون الكروشيه والحياكة وشغل الصوف والأبر 🧶✨. اسأليني عن أي غرزة أو باترونة وسأشرحها لكِ فوراً!\`;
  }
  if (qClean.includes('التواء') || qClean.includes('تقوس') || qClean.includes('انكماش')) {
    return \`**⚠️ حل التواء وتقوس القطعة في الكروشيه:**\\n• **السبب الأول:** الشد الزائد للخيط؛ ارخي قبضة يدك قليلاً أو استبدلي السنارة بأكبر بنصف مقاس.\\n• **السبب الثاني في الدائرة:** إذا كانت تتقوس مثل الطاسة فالزيادات قليلة، وإذا كانت تتموج فالزيادات أكثر من اللازم.\\n• **الحل السريع:** مرري بخار المكواة الرقيق من بعيد (Steam Blocking) وافرديها برفق على منشفة.\`;
  }
  if (qClean.includes('دائرة سحرية') || qClean.includes('حلقة')) {
    return \`**🪄 الدائرة السحرية المحكمة 100%:**\\n1. لفي الخيط مرتين حول إصبعك السبابة.\\n2. أدخلي السنارة واسحبي خيط الشلة واعملي غرزة سلسلة لتثبيت المركز.\\n3. اشتغلي عدد الغرز المطلوب (مثلاً 6 حشو).\\n4. اسحبي الخيط القصير بقوة حتى ينغلق الثقب بالكامل دون أي فراغ!\`;
  }
  if (qClean.includes('حساب') || qClean.includes('شلة') || qClean.includes('كم خيط')) {
    return \`**🧶 تقدير عدد الشلات:**\\n• شال صغير: 2-3 شلات (100غ).\\n• بطانية أطفال: 4-5 شلات.\\n• دمية أميغورومي: 1-2 شلة قطن.\\n💡 يمكنكِ أيضاً استخدام تبويب **"حاسبة الخيوط"** في التطبيق للتقدير الفوري والدقيق!\`;
  }
  return \`أهلاً بكِ! أنا **SAMAR** خبيرتكِ في الكروشيه 🧶.\\nتفضلي بسؤالي عن أي نوع خيط، غرزة، مقاس سنارة، أو خطوة في باترونتكِ وسأساعدكِ فوراً وبكل سرور!\`;
}`;

const newLocalKnowledge = `function getLocalKnowledgeResponse(q) {
  const lang = currentAppLang || 'ar';
  const qClean = q.toLowerCase();

  if (lang === 'en') {
    if (qClean.includes('who are you') || qClean.includes('name') || qClean.includes('samar')) {
      return \`I am **SAMAR**, your personal expert crochet & knitting companion 🧶✨. Ask me about any stitch, pattern, gauge, or yarn issue!\`;
    }
    if (qClean.includes('curling') || qClean.includes('twist') || qClean.includes('curl')) {
      return \`**⚠️ How to fix curling in crochet:**\\n• **Cause 1:** High tension. Relax your grip or use a hook 0.5mm larger.\\n• **Cause 2 in circles:** If it bows like a bowl, you need more increases; if it ruffles, you have too many increases.\\n• **Quick Fix:** Gentle steam blocking on a flat towel!\`;
    }
    if (qClean.includes('magic ring') || qClean.includes('circle') || qClean.includes('loop')) {
      return \`**🪄 100% Secure Magic Ring:**\\n1. Wrap yarn twice around index finger.\\n2. Insert hook under front loop, pull working yarn, and chain 1 to secure.\\n3. Work your stitches (e.g. 6 sc).\\n4. Pull tail tightly to close the hole completely with zero gap!\`;
    }
    return \`Hello! I am **SAMAR**, your crochet companion 🧶.\\nFeel free to ask me about any yarn weight, hook size, stitch instructions, or pattern calculation!\`;
  }

  if (lang === 'ja') {
    if (qClean.includes('誰') || qClean.includes('名前') || qClean.includes('samar')) {
      return \`私は **SAMAR**、あなたのかぎ針編み＆あみぐるみ専属AIエキスパートです 🧶✨。何でも気軽にご質問ください！\`;
    }
    if (qClean.includes('丸まる') || qClean.includes('歪み') || qClean.includes('反る')) {
      return \`**⚠️ 編み地の丸まり解消法:**\\n• **原因1:** 糸の引き締めすぎ。手の力を抜くか、針を0.5mm太いものに変更してください。\\n• **円編みの歪み:** お椀型に反る時は増やし目が不足、フリル状に波打つ時は増やし目が多すぎます。\\n• **対策:** スチームアイロンを少し離して当て、当て布の上で形を整える（ブロッキング）と綺麗に伸びます。\`;
    }
    if (qClean.includes('わ') || qClean.includes('マジックリング') || qClean.includes('作り目')) {
      return \`**🪄 解けない「わ」の作り目（マジックリング）:**\\n1. 人差し指に糸を2回巻きつけます。\\n2. 針を入れて糸を引き出し、立ち上がりの鎖編みを1目編みます。\\n3. 指定の目数（例: 細編み6目）を編み入れます。\\n4. 糸端をゆっくり引き、中心の穴を隙間なくきつく締めます！\`;
    }
    return \`こんにちは！かぎ針編みアシスタントの **SAMAR** です 🧶。\\n編み方、針の号数、糸の選び方など、何でもお尋ねください！\`;
  }

  if (lang === 'tr') {
    if (qClean.includes('kimsin') || qClean.includes('adın') || qClean.includes('samar')) {
      return \`Ben **SAMAR**, tığ işi ve örgü sanatındaki kişisel uzman asistanınızım 🧶✨. Bana herhangi bir ilmek veya şablonu sorabilirsiniz!\`;
    }
    if (qClean.includes('kıvrılma') || qClean.includes('bükülme') || qClean.includes('dönme')) {
      return \`**⚠️ Tığ işinde kıvrılma sorununu çözme:**\\n• **1. Sebep:** İpi çok sıkı çekmek; elinizi biraz gevşetin veya yarım numara büyük tığ kullanın.\\n• **Dairede:** Kase gibi içe bükülüyorsa artırma azdır; dalgalanıyorsa artırma fazladır.\\n• **Çözüm:** Hafif buhar verip düz bir havlu üzerinde elinizle düzeltin (Buharlı ütüleme/Blocking).\`;
    }
    if (qClean.includes('sihirli halka') || qClean.includes('halka')) {
      return \`**🪄 %100 Sağlam Sihirli Halka:**\\n1. İpi işaret parmağınıza 2 kez dolayın.\\n2. Tığı alttan geçirip ilmeği çekin ve 1 zincirle sabitleyin.\\n3. İstenen ilmek sayısını yapın (ör: 6 sık iğne).\\n4. Kısa ipi sıkıca çekerek deliği tamamen kapatın!\`;
    }
    return \`Merhaba! Ben **SAMAR**, tığ işi asistanınızım 🧶.\\nİlmekler, ip çeşitleri veya şablonlar hakkında her zaman sorabilirsiniz!\`;
  }

  if (lang === 'ru') {
    if (qClean.includes('кто ты') || qClean.includes('имя') || qClean.includes('samar')) {
      return \`Я **SAMAR**, ваш персональный эксперт по вязанию крючком и пряже 🧶✨. Спрашивайте меня о любых петлях и схемах!\`;
    }
    if (qClean.includes('скручиван') || qClean.includes('заворач') || qClean.includes('тянет')) {
      return \`**⚠️ Как устранить закручивание полотна:**\\n• **Причина 1:** Слишком сильное натяжение нити; расслабьте руку или возьмите крючок на 0.5 мм больше.\\n• **В круге:** Если сворачивается в чашу — не хватает прибавок; если идет волнами — прибавок слишком много.\\n• **Решение:** Легкое отпаривание утюгом на расстоянии и блокировка на полотенце.\`;
    }
    if (qClean.includes('кольцо') || qClean.includes('амигуруми') || qClean.includes('магическ')) {
      return \`**🪄 Идеальное волшебное кольцо амигуруми:**\\n1. Оберните нить вокруг указательного пальца дважды.\\n2. Введите крючок, вытяните петлю и закрепите одной воздушной петлей.\\n3. Свяжите нужное количество столбиков (напр. 6 сбн).\\n4. Потяните за короткий конец, чтобы стянуть отверстие без малейшего зазора!\`;
    }
    return \`Здравствуйте! Я **SAMAR**, ваш помощник по вязанию 🧶.\\nЗадайте любой вопрос по узорам, крючкам, пряже или расчетам!\`;
  }

  if (lang === 'es') {
    if (qClean.includes('quién eres') || qClean.includes('nombre') || qClean.includes('samar')) {
      return \`¡Soy **SAMAR**, tu experta y compañera personal en el arte del crochet y tejido 🧶✨. ¡Pregúntame cualquier duda!\`;
    }
    if (qClean.includes('enrolla') || qClean.includes('curva') || qClean.includes('tensión')) {
      return \`**⚠️ Cómo evitar que el tejido se enrolle:**\\n• **Causa 1:** Tensión muy apretada; afloja la mano o sube 0.5 mm el número de ganchillo.\\n• **En círculos:** Si se hace cuenco faltan aumentos; si ondea como volante sobran aumentos.\\n• **Solución rápida:** Bloqueo suave con vapor sobre una toalla plana.\`;
    }
    if (qClean.includes('anillo mágico') || qClean.includes('circulo magico')) {
      return \`**🪄 Anillo Mágico 100% seguro:**\\n1. Da dos vueltas con el hilo a tu dedo índice.\\n2. Introduce el ganchillo, saca hebra y haz 1 cadeneta para fijar.\\n3. Teje los puntos necesarios (ej: 6 puntos bajos).\\n4. Tira firmemente del cabo corto para cerrar el hueco por completo sin dejar espacio.\`;
    }
    return \`¡Hola! Soy **SAMAR**, tu compañera de crochet 🧶.\\n¡Pregúntame lo que necesites sobre puntos, tipos de hilo o cálculos de tu labor!\`;
  }

  // Default Arabic
  if (qClean.includes('اسم') || qClean.includes('من انت') || qClean.includes('عرفين')) {
    return \`أنا **SAMAR**، خبيرتكِ ومساعدتكِ الشخصية في فنون الكروشيه والحياكة وشغل الصوف والأبر 🧶✨. اسأليني عن أي غرزة أو باترونة وسأشرحها لكِ فوراً!\`;
  }
  if (qClean.includes('التواء') || qClean.includes('تقوس') || qClean.includes('انكماش')) {
    return \`**⚠️ حل التواء وتقوس القطعة في الكروشيه:**\\n• **السبب الأول:** الشد الزائد للخيط؛ ارخي قبضة يدك قليلاً أو استبدلي السنارة بأكبر بنصف مقاس.\\n• **السبب الثاني في الدائرة:** إذا كانت تتقوس مثل الطاسة فالزيادات قليلة، وإذا كانت تتموج فالزيادات أكثر من اللازم.\\n• **الحل السريع:** مرري بخار المكواة الرقيق من بعيد (Steam Blocking) وافرديها برفق على منشفة.\`;
  }
  if (qClean.includes('دائرة سحرية') || qClean.includes('حلقة')) {
    return \`**🪄 الدائرة السحرية المحكمة 100%:**\\n1. لفي الخيط مرتين حول إصبعك السبابة.\\n2. أدخلي السنارة واسحبي خيط الشلة واعملي غرزة سلسلة لتثبيت المركز.\\n3. اشتغلي عدد الغرز المطلوب (مثلاً 6 حشو).\\n4. اسحبي الخيط القصير بقوة حتى ينغلق الثقب بالكامل دون أي فراغ!\`;
  }
  if (qClean.includes('حساب') || qClean.includes('شلة') || qClean.includes('كم خيط')) {
    return \`**🧶 تقدير عدد الشلات:**\\n• شال صغير: 2-3 شلات (100غ).\\n• بطانية أطفال: 4-5 شلات.\\n• دمية أميغورومي: 1-2 شلة قطن.\\n💡 يمكنكِ أيضاً استخدام تبويب **"حاسبة الخيوط"** في التطبيق للتقدير الفوري والدقيق!\`;
  }
  return \`أهلاً بكِ! أنا **SAMAR** خبيرتكِ في الكروشيه 🧶.\\nتفضلي بسؤالي عن أي نوع خيط، غرزة، مقاس سنارة، أو خطوة في باترونتكِ وسأساعدكِ فوراً وبكل سرور!\`;
}`;
html = html.replace(oldLocalKnowledge, newLocalKnowledge);
console.log('Patched getLocalKnowledgeResponse');

fs.writeFileSync(indexPath, html, 'utf8');
console.log('All functions patched successfully');
