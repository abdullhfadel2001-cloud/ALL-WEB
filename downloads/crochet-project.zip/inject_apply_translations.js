const fs = require('fs');

const p = 'C:\\crochet_app\\index.html';
let html = fs.readFileSync(p, 'utf8');

const applyTransFn = `
function applyTranslations(lang) {
  const t = I18N_DICT[lang] || I18N_DICT.ar;

  // Header
  const bTitle = document.getElementById('brandTitle');
  const bSub = document.getElementById('brandSubtitle');
  const sWl = document.getElementById('screenWlLabel');
  const wlAlert = document.getElementById('wlAlertBannerText');
  if (bTitle) bTitle.textContent = t.brandTitle;
  if (bSub) bSub.textContent = t.brandSubtitle;
  if (sWl) sWl.textContent = t.screenWl;
  if (wlAlert) wlAlert.textContent = t.wlBanner;

  // Desktop Navigation
  document.querySelectorAll('.desktop-nav .nav-btn').forEach(btn => {
    const tab = btn.dataset.tab;
    const span = btn.querySelector('span');
    if (span && t.nav[tab]) span.textContent = t.nav[tab];
  });

  // Mobile Bottom Bar Navigation
  document.querySelectorAll('.mobile-bottom-bar .mobile-nav-item').forEach(btn => {
    const tab = btn.dataset.tab;
    const label = btn.querySelector('.m-label');
    const shortKey = tab + 'Short';
    if (label && t.nav[shortKey]) label.textContent = t.nav[shortKey];
    else if (label && t.nav[tab]) label.textContent = t.nav[tab];
  });

  // AI Chat Section (SAMAR)
  const chatMetaH3 = document.querySelector('.ai-meta h3');
  const chatStatus = document.querySelector('.ai-status-indicator');
  const chatInput = document.getElementById('aiChatInput');
  const chatClearSpan = document.querySelector('.btn-clear-chat span');
  const chatThinking = document.querySelector('.ai-thinking-box span');

  if (chatMetaH3) chatMetaH3.textContent = t.chat.title;
  if (chatStatus) chatStatus.textContent = t.chat.status;
  if (chatInput) chatInput.placeholder = t.chat.placeholder;
  if (chatClearSpan) chatClearSpan.textContent = t.chat.clear;
  if (chatThinking) chatThinking.textContent = t.chat.thinking;

  // Update quick suggestion chips
  const chips = document.querySelectorAll('.suggestion-chip');
  if (chips && chips.length >= 4) {
    if (chips[0]) chips[0].textContent = t.chat.chips.curling;
    if (chips[1]) chips[1].textContent = t.chat.chips.ring;
    if (chips[2]) chips[2].textContent = t.chat.chips.blanket;
    if (chips[3]) chips[3].textContent = t.chat.chips.compare;
  }

  // Update initial bot welcome bubble
  const stream = document.getElementById('aiChatStream');
  if (stream) {
    const firstBotBubble = stream.querySelector('.chat-bubble.bot');
    if (firstBotBubble && stream.querySelectorAll('.chat-bubble').length <= 1) {
      firstBotBubble.innerHTML = (window.marked && marked.parse) ? marked.parse(t.chat.welcome) : t.chat.welcome.replace(/\\n/g, '<br>');
    }
  }

  // Patterns Section Header & Filters
  const patSearch = document.getElementById('patternSearchInput');
  if (patSearch) patSearch.placeholder = t.patterns.searchPh;

  document.querySelectorAll('.level-chip').forEach(btn => {
    const txt = btn.textContent;
    if (txt.includes('مبتدئ') || txt.includes('Beginner') || txt.includes('Anfänger') || txt.includes('初級') || txt.includes('Başlangıç') || txt.includes('Начинающий') || txt.includes('Principiante')) {
      btn.textContent = t.patterns.levels.beg;
    } else if (txt.includes('متوسط') || txt.includes('Intermediate') || txt.includes('Mittel') || txt.includes('中級') || txt.includes('Orta') || txt.includes('Средний') || txt.includes('Intermedio')) {
      btn.textContent = t.patterns.levels.int;
    } else if (txt.includes('محترف') || txt.includes('Advanced') || txt.includes('Fortgeschritten') || txt.includes('上級') || txt.includes('İleri') || txt.includes('Продвинутый') || txt.includes('Avanzado')) {
      btn.textContent = t.patterns.levels.adv;
    } else {
      btn.textContent = t.patterns.levels.all;
    }
  });

  // Re-render Pattern Categories & Patterns Cards
  renderPatternCategoryChips();
  renderPatternsCatalogFiltered();

  // Counter Section
  const vTitle = document.querySelector('.voice-title span');
  const vPrompt = document.querySelector('.voice-info div:nth-child(2)');
  const vBadge = document.getElementById('voiceStatusBadge');
  const mchTag = document.querySelector('.mch-tag');
  const mchLabel = document.querySelector('.mch-label');
  const swTitle = document.querySelector('.stopwatch-card div:first-child div:first-child');
  const swStartBtn = document.getElementById('swStartBtn');

  if (vTitle) vTitle.textContent = t.counter.voiceTitle;
  if (vPrompt) vPrompt.innerHTML = t.counter.voicePrompt;
  if (vBadge && !isVoiceListeningActive) vBadge.innerHTML = '<i class="fa-solid fa-circle" style="font-size:0.5rem;color:#10b981;"></i> ' + t.counter.voiceReady;
  if (mchTag) mchTag.textContent = t.counter.mchTag;
  if (mchLabel) mchLabel.textContent = t.counter.mchLabel;
  if (swTitle) swTitle.innerHTML = '<i class="fa-solid fa-stopwatch" style="color:var(--primary);"></i> ' + t.counter.stopwatchTitle;
  if (swStartBtn) swStartBtn.textContent = isStopwatchRunning ? t.counter.btnPauseSession : t.counter.btnStartSession;

  // Calculators Section
  const calcH2 = document.querySelector('.calc-header-box h2');
  const calcP = document.querySelector('.calc-header-box p');
  const calcCurr = document.querySelector('.calc-currency-pill');
  if (calcH2) calcH2.textContent = t.calc.title;
  if (calcP) calcP.textContent = t.calc.subtitle;
  if (calcCurr) calcCurr.textContent = t.calc.currency;

  const subBtns = document.querySelectorAll('.calc-subtab-btn span');
  if (subBtns.length >= 4) {
    subBtns[0].textContent = t.calc.tabs.est;
    subBtns[1].textContent = t.calc.tabs.gauge;
    subBtns[2].textContent = t.calc.tabs.rem;
    subBtns[3].textContent = t.calc.tabs.pricing;
  }

  // Studio Section
  const stH2 = document.querySelector('.studio-hero-card h2');
  const stP = document.querySelector('.studio-hero-card p');
  if (stH2) stH2.innerHTML = '<i class="fa-solid fa-palette"></i> ' + t.studio.title;
  if (stP) stP.textContent = t.studio.subtitle;

  const btnStarry = document.getElementById('btnStudioStarry');
  const btnCustom = document.getElementById('btnStudioCustom');
  if (btnStarry) btnStarry.innerHTML = '<i class="fa-solid fa-star"></i> ' + t.studio.tabStarry;
  if (btnCustom) btnCustom.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles"></i> ' + t.studio.tabCustom;

  const studioPdfBtn = document.querySelector('button[onclick="printStudioPatternPDF()"]');
  const studioNotesBtn = document.querySelector('button[onclick="saveStudioToNotes()"]');
  if (studioPdfBtn) studioPdfBtn.innerHTML = '<i class="fa-solid fa-file-pdf"></i> ' + t.studio.btnPdf;
  if (studioNotesBtn) studioNotesBtn.innerHTML = '<i class="fa-solid fa-bookmark"></i> ' + t.studio.btnNotes;

  // Studio Specs Box Labels
  const specsH3 = document.querySelector('#studioStarryView h3');
  const specsChip = document.querySelector('#studioStarryView .spec-chip');
  if (specsH3) specsH3.textContent = t.studio.specsHeader;
  if (specsChip) specsChip.textContent = t.studio.specsCost;

  // Glossary Section
  const glSearch = document.getElementById('glossarySearchInput');
  const glMasterBtn = document.querySelector('.master-size-btn');
  if (glSearch) glSearch.placeholder = t.glossary.searchPh;
  if (glMasterBtn) glMasterBtn.innerHTML = '<i class="fa-solid fa-ruler-combined"></i> ' + t.glossary.masterGuideBtn;
  renderGlossaryCatalog();

  // Notes Section
  const noteBtnSpan = document.querySelector('.btn-create-note span');
  const noteSearchField = document.getElementById('notesSearchField');
  if (noteBtnSpan) noteBtnSpan.textContent = t.notes.btnAdd;
  if (noteSearchField) noteSearchField.placeholder = t.notes.searchPh;
  renderNotesMasonry();
}
`;

// Insert applyTransFn right after setAppLanguage definition ends
const targetStr = `  if (isVoiceListeningActive) {
    stopVoiceCounter();
    setTimeout(() => { toggleVoiceCounter(); }, 300);
  }
}`;

if (html.includes(targetStr)) {
  html = html.replace(targetStr, `${targetStr}\n${applyTransFn}`);
  console.log('Inserted applyTranslations right below setAppLanguage');
} else {
  console.error('Target string not found');
}

fs.writeFileSync(p, html, 'utf8');
