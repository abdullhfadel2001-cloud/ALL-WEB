const fs = require('fs');

const indexPath = 'C:\\crochet_app\\index.html';
let html = fs.readFileSync(indexPath, 'utf8');

// ═══════════════════════════════════════════════════════
// 1. ADD CSS FOR LANGUAGE DROPDOWN & LTR SUPPORT
// ═══════════════════════════════════════════════════════
const langCss = `
  /* ═════════ MULTI-LANGUAGE SYSTEM (i18n) STYLES ═════════ */
  .lang-dropdown-container {
    position: relative;
    display: inline-block;
  }
  .lang-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px !important;
    border-radius: 9999px !important;
    font-size: 0.8rem !important;
    font-weight: 700 !important;
    cursor: pointer;
    background: var(--bg-card);
    border: 1px solid var(--border-color);
    color: var(--text-main);
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    transition: all 0.2s ease;
  }
  .lang-btn:hover {
    border-color: var(--primary-accent);
    color: var(--primary-accent);
    transform: translateY(-1px);
  }
  .lang-btn i.fa-globe {
    font-size: 0.95rem;
    color: var(--primary-accent);
  }
  .lang-menu {
    position: absolute;
    top: calc(100% + 8px);
    right: 0;
    min-width: 220px;
    background: var(--bg-card);
    border: 1px solid var(--border-color);
    border-radius: 14px;
    box-shadow: 0 12px 30px rgba(0,0,0,0.22);
    padding: 6px;
    display: none;
    flex-direction: column;
    gap: 4px;
    z-index: 99999;
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    animation: fadeInDown 0.2s cubic-bezier(0.16, 1, 0.3, 1);
  }
  [dir="ltr"] .lang-menu {
    right: auto;
    left: 0;
  }
  .lang-menu.show {
    display: flex;
  }
  .lang-opt {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 12px;
    border-radius: 10px;
    cursor: pointer;
    transition: background 0.15s ease, transform 0.15s ease;
    user-select: none;
  }
  .lang-opt:hover {
    background: var(--bg-surface);
    transform: translateX(-2px);
  }
  [dir="ltr"] .lang-opt:hover {
    transform: translateX(2px);
  }
  .lang-opt.active {
    background: rgba(168, 85, 247, 0.15);
    border: 1px solid rgba(168, 85, 247, 0.3);
    font-weight: 700;
  }
  .lang-opt .lang-flag {
    font-size: 1.25rem;
    line-height: 1;
  }
  .lang-opt .lang-text {
    display: flex;
    flex-direction: column;
    text-align: right;
  }
  [dir="ltr"] .lang-opt .lang-text {
    text-align: left;
  }
  .lang-opt .lang-name {
    font-size: 0.85rem;
    font-weight: 700;
    color: var(--text-main);
  }
  .lang-opt .lang-country {
    font-size: 0.68rem;
    color: var(--text-muted);
  }

  /* LTR document adaptations */
  [dir="ltr"] body {
    text-align: left;
    font-family: 'Poppins', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  }
  [dir="ltr"] .compact-header {
    flex-direction: row;
  }
  [dir="ltr"] .desktop-nav-list {
    flex-direction: row;
  }
  [dir="ltr"] .chat-bubble.user {
    align-self: flex-end;
    border-bottom-right-radius: 4px;
    border-bottom-left-radius: 18px;
  }
  [dir="ltr"] .chat-bubble.bot {
    align-self: flex-start;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 18px;
  }
  [dir="ltr"] .reader-back-btn i {
    transform: rotate(180deg);
  }
  @keyframes fadeInDown {
    from { opacity: 0; transform: translateY(-8px); }
    to { opacity: 1; transform: translateY(0); }
  }
`;

// Insert lang CSS into <style>
if (!html.includes('MULTI-LANGUAGE SYSTEM (i18n) STYLES')) {
  html = html.replace('</style>', `${langCss}\n</style>`);
  console.log('Injected multi-language CSS');
}

// ═══════════════════════════════════════════════════════
// 2. INJECT LANGUAGE DROPDOWN INTO HEADER
// ═══════════════════════════════════════════════════════
const langDropdownHtml = `
      <!-- Multi-Language Selector (6 Core Crochet Nations) -->
      <div class="lang-dropdown-container" id="langDropdownContainer">
        <button class="h-btn lang-btn" onclick="toggleLangMenu(event)" id="langToggleBtn" title="تغيير اللغة | Change Language">
          <i class="fa-solid fa-globe"></i>
          <span id="currentLangDisplay">العربية</span>
          <i class="fa-solid fa-chevron-down" style="font-size:0.55rem;opacity:0.75;"></i>
        </button>
        <div class="lang-menu" id="langMenu">
          <div class="lang-opt active" data-lang="ar" onclick="setAppLanguage('ar')">
            <span class="lang-flag">🇮🇶</span>
            <div class="lang-text">
              <span class="lang-name">العربية</span>
              <span class="lang-country">العراق والعالم العربي</span>
            </div>
          </div>
          <div class="lang-opt" data-lang="en" onclick="setAppLanguage('en')">
            <span class="lang-flag">🇬🇧</span>
            <div class="lang-text">
              <span class="lang-name">English</span>
              <span class="lang-country">Ireland / US / UK</span>
            </div>
          </div>
          <div class="lang-opt" data-lang="ja" onclick="setAppLanguage('ja')">
            <span class="lang-flag">🇯🇵</span>
            <div class="lang-text">
              <span class="lang-name">日本語</span>
              <span class="lang-country">Japan / あみぐるみ</span>
            </div>
          </div>
          <div class="lang-opt" data-lang="tr" onclick="setAppLanguage('tr')">
            <span class="lang-flag">🇹🇷</span>
            <div class="lang-text">
              <span class="lang-name">Türkçe</span>
              <span class="lang-country">Türkiye / Tığ İşi</span>
            </div>
          </div>
          <div class="lang-opt" data-lang="ru" onclick="setAppLanguage('ru')">
            <span class="lang-flag">🇷🇺</span>
            <div class="lang-text">
              <span class="lang-name">Русский</span>
              <span class="lang-country">Россия / Вязание</span>
            </div>
          </div>
          <div class="lang-opt" data-lang="es" onclick="setAppLanguage('es')">
            <span class="lang-flag">🇪🇸</span>
            <div class="lang-text">
              <span class="lang-name">Español</span>
              <span class="lang-country">Latinoamérica / España</span>
            </div>
          </div>
        </div>
      </div>
`;

if (!html.includes('id="langDropdownContainer"')) {
  html = html.replace('<div class="header-controls">', `<div class="header-controls">\n${langDropdownHtml}`);
  console.log('Injected language dropdown markup into header');
}

// ═══════════════════════════════════════════════════════
// 3. ADD IDENTIFIERS (ids/classes) TO KEY STATIC ELEMENTS FOR FAST TRANSLATION
// ═══════════════════════════════════════════════════════
// Brand Title & Subtitle
html = html.replace('<h1>خيوط وغرز</h1>', '<h1 id="brandTitle">خيوط وغرز</h1>');
html = html.replace('<p>الرفيق الذكي للكروشيه</p>', '<p id="brandSubtitle">الرفيق الذكي للكروشيه</p>');

// Wake lock banner
html = html.replace(
  '<span>خاصية عدم إطفاء الشاشة قيد التشغيل (لن تنطفئ شاشتك أثناء قراءة الباترون)</span>',
  '<span id="wlAlertBannerText">خاصية عدم إطفاء الشاشة قيد التشغيل (لن تنطفئ شاشتك أثناء قراءة الباترون)</span>'
);

// Write updated HTML back to index.html
fs.writeFileSync(indexPath, html, 'utf8');
console.log('Header and CSS updated successfully');
