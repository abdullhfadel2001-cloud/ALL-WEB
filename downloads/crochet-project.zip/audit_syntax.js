const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');

// Extract inline scripts (without src attribute)
const scriptRegex = /<script(?![^>]*\bsrc\b)[^>]*>([\s\S]*?)<\/script>/gi;
let match;
let count = 0;

while ((match = scriptRegex.exec(html)) !== null) {
  count++;
  const js = match[1];
  console.log(`Auditing Script Block ${count} (length: ${js.length} chars)...`);
  try {
    new vm.Script(js);
    console.log(`✅ Script Block ${count}: SYNTAX VALID`);
  } catch (err) {
    console.error(`❌ Script Block ${count} SYNTAX ERROR:`, err.message);
    const lineNum = err.stack.match(/<anonymous>:(\d+):(\d+)/);
    if (lineNum) {
      const l = parseInt(lineNum[1]);
      const lines = js.split('\n');
      console.log('Error context:');
      for (let i = Math.max(0, l - 5); i < Math.min(lines.length, l + 5); i++) {
        console.log(`${i + 1}: ${lines[i]}`);
      }
    }
    process.exit(1);
  }
}

console.log(`All ${count} inline script blocks passed syntax check!`);

