const fs = require('fs');

const p = 'C:\\crochet_app\\index.html';
let html = fs.readFileSync(p, 'utf8');

// Add cache control meta tags right after <head>
if (!html.includes('Cache-Control')) {
  html = html.replace('<head>', '<head>\n  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">\n  <meta http-equiv="Pragma" content="no-cache">\n  <meta http-equiv="Expires" content="0">');
  console.log('Added cache control meta tags');
}

fs.writeFileSync(p, html, 'utf8');

