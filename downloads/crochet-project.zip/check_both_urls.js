const https = require('https');

function checkUrl(url) {
  return new Promise((resolve) => {
    https.get(url, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        resolve({ url, status: res.statusCode, size: data.length });
      });
    }).on('error', (err) => resolve({ url, error: err.message }));
  });
}

async function run() {
  const r1 = await checkUrl('https://abdullhfadel2001-cloud.github.io/ALL-WEB/index.html');
  const r2 = await checkUrl('https://abdullhfadel2001-cloud.github.io/ALL-WEB/crochet/index.html');
  console.log('DAEM Main Platform:', r1.status, 'Size:', r1.size);
  console.log('Crochet App on Platform:', r2.status, 'Size:', r2.size);
}

run();

