const fs = require('fs');

const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');

// Match all onclick="..." attributes
const onclickRegex = /onclick=["']([^"']+)["']/g;
const handlers = new Set();
let m;
while ((m = onclickRegex.exec(html)) !== null) {
  const code = m[1].trim();
  const fnMatch = code.match(/^([a-zA-Z0-9_$]+)\s*\(/);
  if (fnMatch) {
    handlers.add(fnMatch[1]);
  }
}

console.log(`Found ${handlers.size} unique onclick handlers.`);
let missing = 0;
handlers.forEach(fn => {
  const pattern = new RegExp(`function\\s+${fn}\\b|const\\s+${fn}\\s*=|let\\s+${fn}\\s*=|var\\s+${fn}\\s*=`);
  if (!pattern.test(html)) {
    console.error(`❌ Handler "${fn}" is NOT defined in script!`);
    missing++;
  } else {
    // console.log(`✅ ${fn} OK`);
  }
});

if (missing === 0) {
  console.log(`✅ All ${handlers.size} onclick handlers are properly defined!`);
} else {
  console.error(`❌ ${missing} handlers missing!`);
  process.exit(1);
}
