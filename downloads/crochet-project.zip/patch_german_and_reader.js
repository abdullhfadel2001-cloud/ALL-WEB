const fs = require('fs');

// 1. UPDATE SERVER.JS WITH GERMAN
const serverPath = 'C:\\crochet_app\\server.js';
let sCode = fs.readFileSync(serverPath, 'utf8');

const oldLangMap = `        en: 'English with standard US and UK crochet terminology and encouraging tone',`;
const newLangMap = `        en: 'English with standard US and UK crochet terminology and encouraging tone',
        de: 'German (Deutsch) with warm, patient, and expert artisan tone and standard Häkeln & Stricken terminology',`;

if (!sCode.includes("de: 'German (Deutsch)")) {
  sCode = sCode.replace(oldLangMap, newLangMap);
  fs.writeFileSync(serverPath, sCode, 'utf8');
  console.log('Added German to server.js');
}

// 2. UPDATE INDEX.HTML: openPatternReaderModal and getLocalKnowledgeResponse
const indexPath = 'C:\\crochet_app\\index.html';
let html = fs.readFileSync(indexPath, 'utf8');

// Patch openPatternReaderModal
const oldOpenReader = `function openPatternReaderModal(patternId) {
  const p = PATTERNS.find(item => item.id === patternId);
  if (!p) return;

  activePattern = p;
  document.getElementById('readerCoverEmoji').textContent = p.emoji;
  document.getElementById('readerTitleText').textContent = p.title;
  document.getElementById('readerDescText').textContent = \`\${p.description} • الخيط المقترح: \${p.yarn}\`;

  const savedRow = parseInt(localStorage.getItem(LOCAL_STORAGE.PATTERN_ROW_PREFIX + p.id) || '0');
  document.getElementById('readerRowCount').textContent = savedRow;

  // Inject Header Level Chip and Specs
  const levelText = p.levelLabel || (p.level === 'intermediate' ? 'متوسط 🟡' : p.level === 'advanced' ? 'محترف 🟣' : 'مبتدئ 🟢');
  document.getElementById('readerTitleText').innerHTML = \`\${p.title} <span class="pattern-level-tag \${p.levelTagClass || 'tag-beginner'}" style="font-size:0.75rem;vertical-align:middle;margin-right:8px;">\${levelText}</span>\`;

  // Render Symbols Key Table and Finishing Tips if available
  const extraContainer = document.getElementById('readerExtraInfoContainer');
  if (extraContainer) {
    let extraHtml = '';

    // Symbols Table
    if (p.symbolsTable && p.symbolsTable.length) {
      extraHtml += \`
        <div style="background:var(--surface);border:1px solid var(--border-purple);border-radius:var(--radius-md);padding:12px;margin:12px 0;">
          <h4 style="font-size:0.86rem;font-weight:900;color:var(--primary);margin-bottom:8px;">
            <i class="fa-solid fa-list-check"></i> جدول الرموز والاختصارات المعتمدة في هذا الباترون
          </h4>
          <table class="symbols-key-table">
            <thead>
              <tr><th>الرمز</th><th>اسم الغرزة</th><th>المصطلح الإنجليزي</th></tr>
            </thead>
            <tbody>
              \${p.symbolsTable.map(s => \`<tr><td><span class="symbol-char">\${s.sym}</span></td><td><b>\${s.name}</b></td><td>\${s.en}</td></tr>\`).join('')}
            </tbody>
          </table>
        </div>
      \`;
    }

    // Finishing Tips
    if (p.finishingTips) {
      extraHtml += \`
        <div class="finishing-tips-box">
          <h4 style="font-size:0.86rem;font-weight:900;color:#059669;margin-bottom:6px;">
            <i class="fa-solid fa-wand-magic-sparkles"></i> نصائح احترافية للتشطيب والتنظيف (Finishing & Cleaning)
          </h4>
          <p style="font-size:0.82rem;color:var(--text);line-height:1.6;">\${p.finishingTips}</p>
        </div>
      \`;
    }

    extraContainer.innerHTML = extraHtml;
  }

  renderPatternReaderSteps(p);

  const modal = document.getElementById('patternReaderModal');
  modal.classList.add('open');
  modal.scrollTop = 0;
  document.body.style.overflow = 'hidden';
}`;

const newOpenReader = `function openPatternReaderModal(patternId) {
  const p = PATTERNS.find(item => item.id === patternId);
  if (!p) return;

  activePattern = p;
  const lang = currentAppLang || 'ar';
  const t = I18N_DICT[lang] || I18N_DICT.ar;
  const trans = (PATTERN_I18N[p.id] && PATTERN_I18N[p.id][lang]) ? PATTERN_I18N[p.id][lang] : null;

  const title = trans ? trans.title : p.title;
  const desc = trans ? trans.desc : p.description;
  const levelText = trans ? trans.level : (p.levelLabel || (p.level === 'intermediate' ? t.patterns.levels.int : p.level === 'advanced' ? t.patterns.levels.adv : t.patterns.levels.beg));

  document.getElementById('readerCoverEmoji').textContent = p.emoji;
  document.getElementById('readerTitleText').textContent = title;
  document.getElementById('readerDescText').textContent = \`\${desc} • \${t.patterns.hook}: \${p.hook}\`;

  const savedRow = parseInt(localStorage.getItem(LOCAL_STORAGE.PATTERN_ROW_PREFIX + p.id) || '0');
  document.getElementById('readerRowCount').textContent = savedRow;

  document.getElementById('readerTitleText').innerHTML = \`\${title} <span class="pattern-level-tag \${p.levelTagClass || 'tag-beginner'}" style="font-size:0.75rem;vertical-align:middle;margin-right:8px;">\${levelText}</span>\`;

  // Render Symbols Key Table and Finishing Tips with localized headers
  const extraContainer = document.getElementById('readerExtraInfoContainer');
  if (extraContainer) {
    let extraHtml = '';

    if (p.symbolsTable && p.symbolsTable.length) {
      extraHtml += \`
        <div style="background:var(--surface);border:1px solid var(--border-purple);border-radius:var(--radius-md);padding:12px;margin:12px 0;">
          <h4 style="font-size:0.86rem;font-weight:900;color:var(--primary);margin-bottom:8px;">
            <i class="fa-solid fa-list-check"></i> \${t.patterns.secSymbols}
          </h4>
          <table class="symbols-key-table">
            <thead>
              <tr><th>\${t.patterns.symColSym}</th><th>\${t.patterns.symColName}</th><th>\${t.patterns.symColEn}</th></tr>
            </thead>
            <tbody>
              \${p.symbolsTable.map(s => \`<tr><td><span class="symbol-char">\${s.sym}</span></td><td><b>\${s.name}</b></td><td>\${s.en}</td></tr>\`).join('')}
            </tbody>
          </table>
        </div>
      \`;
    }

    if (p.finishingTips) {
      extraHtml += \`
        <div class="finishing-tips-box">
          <h4 style="font-size:0.86rem;font-weight:900;color:#059669;margin-bottom:6px;">
            <i class="fa-solid fa-wand-magic-sparkles"></i> \${t.patterns.secTips}
          </h4>
          <p style="font-size:0.82rem;color:var(--text);line-height:1.6;">\${p.finishingTips}</p>
        </div>
      \`;
    }

    extraContainer.innerHTML = extraHtml;
  }

  renderPatternReaderSteps(p);

  const modal = document.getElementById('patternReaderModal');
  modal.classList.add('open');
  modal.scrollTop = 0;
  document.body.style.overflow = 'hidden';
}`;
html = html.replace(oldOpenReader, newOpenReader);
console.log('Patched openPatternReaderModal with full multi-language headers');

// Patch getLocalKnowledgeResponse to add German
const germanKnowledge = `  if (lang === 'de') {
    if (qClean.includes('wer bist') || qClean.includes('name') || qClean.includes('samar')) {
      return \`Ich bin **SAMAR**, deine persönliche Expertin für Häkeln, Stricken und Garne 🧶✨. Frage mich nach jeder Masche oder Anleitung!\`;
    }
    if (qClean.includes('einrollen') || qClean.includes('krümmen') || qClean.includes('spannung')) {
      return \`**⚠️ So verhinderst du das Einrollen des Häkelstücks:**\\n• **Ursache 1:** Zu feste Fadenspannung; lockere deine Handhaltung oder wähle eine Nadelstärke um 0,5 mm größer.\\n• **In Runden:** Wölbt es sich wie eine Schale, fehlen Zunahmen; wellt es sich, sind es zu viele Zunahmen.\\n• **Schnelle Lösung:** Sanftes Dämpfen mit dem Bügeleisen aus der Distanz und Spannen auf einer Unterlage.\`;
    }
    if (qClean.includes('fadenring') || qClean.includes('magic ring') || qClean.includes('maschenring')) {
      return \`**🪄 Der 100% sichere Fadenring (Magic Ring):**\\n1. Wickle das Garn zweimal um deinen Zeigefinger.\\n2. Führe die Nadel hindurch, hole den Arbeitsfaden und schlage 1 Luftmasche an.\\n3. Häkle die gewünschte Maschenzahl hinein (z. B. 6 feste Maschen).\\n4. Ziehe fest am kurzen Fadenende, bis die Öffnung vollständig geschlossen ist!\`;
    }
    return \`Hallo! Ich bin **SAMAR**, deine Häkel-Assistentin 🧶.\\nFrage mich gerne nach Garnstärken, Nadelstärken, Maschenarten oder Anleitungsberechnungen!\`;
  }
`;

if (!html.includes("lang === 'de'")) {
  html = html.replace("if (lang === 'en') {", `${germanKnowledge}\n  if (lang === 'en') {`);
  console.log('Added German knowledge base to getLocalKnowledgeResponse');
}

fs.writeFileSync(indexPath, html, 'utf8');
console.log('All patches saved to index.html');
