const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');

console.log('Includes function applyTranslations?', html.includes('function applyTranslations'));
const idx = html.indexOf('applyTranslations');
console.log('applyTranslations index:', idx);
