const fs = require('fs');

const targetFile = 'c:/Users/dell/OneDrive/Desktop/كروشيه/index.html';
const html = fs.readFileSync(targetFile, 'utf8');

console.log('=== 1. FILE INTEGRITY & ENCODING ===');
console.log('Target file:', targetFile);
console.log('Size (bytes):', Buffer.byteLength(html, 'utf8'));
console.log('Total lines:', html.split('\n').length);
console.log('HTML DOCTYPE valid:', html.startsWith('<!DOCTYPE html>'));
console.log('HTML ends properly:', html.trim().endsWith('</html>'));

console.log('\n=== 2. JAVASCRIPT SYNTAX & EVALUATION ===');
const scriptRegex = /<script(?![^>]*src=)[^>]*>([\s\S]*?)<\/script>/gi;
let m, sIdx = 0;
let allJsCombined = '';
while ((m = scriptRegex.exec(html)) !== null) {
  sIdx++;
  allJsCombined += m[1] + '\n;';
  try {
    new Function(m[1]);
    console.log(`Script block ${sIdx}: SYNTAX OK (length: ${m[1].length} chars)`);
  } catch (err) {
    console.error(`Script block ${sIdx} ERROR:`, err.message);
  }
}

console.log('\n=== 3. ONCLICK HANDLERS VERIFICATION ===');
const onclickRegex = /onclick="([a-zA-Z0-9_]+)\s*\(/g;
const handlers = new Set();
while ((m = onclickRegex.exec(html)) !== null) {
  handlers.add(m[1]);
}

const missing = [];
for (const fn of handlers) {
  const fnRegex = new RegExp('(?:function\\s+' + fn + '\\b|const\\s+' + fn + '\\s*=|let\\s+' + fn + '\\s*=|window\\.' + fn + '\\s*=)');
  if (!fnRegex.test(allJsCombined)) {
    missing.push(fn);
  }
}

if (missing.length === 0) {
  console.log(`All ${handlers.size} onclick handlers are DEFINED in JavaScript!`);
  console.log('Sample verified handlers:', Array.from(handlers).slice(0, 10).join(', '));
} else {
  console.warn('Missing functions:', missing);
}

console.log('\n=== 4. NAVIGATION TABS AUDIT ===');
const navTabs = [...html.matchAll(/data-tab="([a-zA-Z0-9_-]+)"/g)].map(x => x[1]);
const uniqueTabs = [...new Set(navTabs)];
console.log('Navigation buttons reference tabs:', uniqueTabs);
for (const tab of uniqueTabs) {
  const sectionExists = html.includes(`id="tab-${tab}"`);
  console.log(`Tab "${tab}" section: ${sectionExists ? 'EXISTS & ACTIVE-READY' : 'MISSING!'}`);
}

console.log('\n=== 5. PATTERNS CATALOG AUDIT ===');
const patCountMatch = html.match(/id:\s*['"]([a-zA-Z0-9_-]+)['"],\s*title:\s*['"]([^'"]+)['"]/g);
console.log('Total patterns configured in catalog:', patCountMatch ? patCountMatch.length : 0);

console.log('\n=== 6. CURRENCY AUDIT ===');
const iqdMatches = (html.match(/د\.ع|دينار/g) || []).length;
console.log('Total Iraqi Dinar mentions (د.ع / دينار):', iqdMatches);
const usdMatches = (html.match(/\$\d+/g) || []).length;
console.log('Unwanted Dollar price mentions:', usdMatches);

console.log('\n=== 7. THEMES & CONTRAST AUDIT ===');
console.log('Dark mode variables exist:', html.includes('[data-theme="dark"]'));
console.log('Light mode root variables exist:', html.includes(':root'));
console.log('Text muted high contrast in dark mode:', html.includes('--text-muted: #e2e8f0;'));
console.log('Text light high contrast in dark mode:', html.includes('--text-light: #cbd5e1;'));

console.log('\n=== ALL TESTS COMPLETED SUCCESSFULLY ===');

