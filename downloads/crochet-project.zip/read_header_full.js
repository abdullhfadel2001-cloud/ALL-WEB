const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');

const match = html.match(/<header[\s\S]*?<\/header>/);
console.log(match ? match[0] : 'not found');

