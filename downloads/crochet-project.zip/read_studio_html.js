const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');

const idx = html.indexOf('id="tab-studio"');
const endIdx = html.indexOf('</section>', idx);
console.log('tab-studio length:', endIdx - idx);
console.log(html.substring(idx, idx + 2500));
