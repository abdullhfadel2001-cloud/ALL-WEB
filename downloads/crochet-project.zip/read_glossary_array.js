const fs = require('fs');
const html = fs.readFileSync('C:\\crochet_app\\index.html', 'utf8');

const idx = html.indexOf('const GLOSSARY =');
const endIdx = html.indexOf('];', idx);
console.log(html.substring(idx, endIdx + 2));
